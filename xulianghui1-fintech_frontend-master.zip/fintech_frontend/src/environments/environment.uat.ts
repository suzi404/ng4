import {addressBookUrlConstant} from '../app/shared/constants/address-book-url.constant';

export const environment = {
  production: true,
  adminApiEndPoint: 'http://fintech-cf-proxy.paasuat.cmbchina.cn/',
  businessApiEndPoinst: 'http://:fintech-service-proxy.paasuat.cmbchina.cn/',
  addressBookApiEndPoint: addressBookUrlConstant.dev,
};
