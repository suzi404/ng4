import {addressBookUrlConstant} from '../app/shared/constants/address-book-url.constant';

export const environment = {
  production: true,
  adminApiEndPoint: 'http://fintech-cf-proxy.paasst.cmbchina.cn/',
  businessApiEndPoinst: 'http://fintech-service-proxy.paasst.cmbchina.cn/',
  addressBookApiEndPoint: addressBookUrlConstant.dev,
};
