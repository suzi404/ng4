import {addressBookUrlConstant} from '../app/shared/constants/address-book-url.constant';

export const environment = {
  production: false,
  adminApiEndPoint: 'http://fintech-cf-proxy-dev.paas.cmbchina.cn/',
  businessApiEndPoinst: 'http://fintech-service-proxy-dev.paas.cmbchina.cn/',
  addressBookApiEndPoint: addressBookUrlConstant.dev,
};
