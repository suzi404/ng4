import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LOCALE_ID } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { HomeModule } from './components/home/home.module';
import { ProjectsPageModule } from './components/projects-page/projects-page.module';
import { SharedModule } from './shared/shared.module';
import { QuestionnaireModule } from './components/questionnaire/questionnaire.module';
import { ProjectApplicationModule } from './components/project-application/project-application.module';
import { ResourcesPageModule } from './components/resources-page/resources-page.module';

import { AppComponent } from './app.component';
import { NoContentComponent } from './components/no-content/no-content.component';
import { FakeLoginComponent } from './components/fake-login/fake-login.component';
import { LoginComponent } from './components/login/login.component';

import { AlertService } from 'app/shared/services/alert.service';

@NgModule({
  declarations: [
    AppComponent,
    NoContentComponent,
    FakeLoginComponent,
    LoginComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HomeModule,
    ProjectsPageModule,
    SharedModule.forRoot(),
    QuestionnaireModule,
    ProjectApplicationModule,
    ResourcesPageModule,
    FormsModule,
    HttpModule,
    BrowserAnimationsModule
  ],
  providers: [
    { provide: LOCALE_ID, useValue: 'zh-cn' },
    AlertService,
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
