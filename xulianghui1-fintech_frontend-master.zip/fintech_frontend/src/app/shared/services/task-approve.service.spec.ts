import { ActivatedRoute } from '@angular/router';
import { ConnectionBackend, RequestOptions, HttpModule } from '@angular/http';
import { HttpInterceptorService } from './http-interceptor.service';
import { AuthenticationService } from './authentication.service';
import { TestBed, inject } from '@angular/core/testing';
import { AlertService } from 'app/shared/services/alert.service';

import { TaskApproveService } from './task-approve.service';

describe('TaskApproveService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpModule,
      ],
      providers: [
        { provide: ActivatedRoute },
        TaskApproveService,
        AuthenticationService,
        HttpInterceptorService,
        ConnectionBackend,
        AlertService
      ]
    });
  });

  it('should be created', inject([TaskApproveService], (service: TaskApproveService) => {
    expect(service).toBeTruthy();
  }));
});
