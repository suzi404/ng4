import { TestBed, inject } from '@angular/core/testing';

import { HttpModule, ConnectionBackend } from '@angular/http';
import { HttpInterceptorService } from './http-interceptor.service';
import { AlertService } from 'app/shared/services/alert.service';

import { CourseService } from './course.service';

describe('CourseService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpModule,
      ],
      providers: [
        HttpInterceptorService,
        ConnectionBackend,
        CourseService,
        AlertService,
      ]
    });
  });

  it('should be created', inject([CourseService], (service: CourseService) => {
    expect(service).toBeTruthy();
  }));
});
