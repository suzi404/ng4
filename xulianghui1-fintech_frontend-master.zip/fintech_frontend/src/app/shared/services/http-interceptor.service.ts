import { codeConstant } from './../constants/code.constant';
import { Injectable } from '@angular/core';
import {
  Http,
  ConnectionBackend,
  RequestOptions,
  RequestOptionsArgs,
  Response,
  Headers,
  Request
} from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/mergeMap';
import { Subject } from 'rxjs/Subject';
import { AlertService } from './alert.service';

@Injectable()
export class HttpInterceptorService extends Http {
  subject = new Subject<any>();
  keepAfterRouteChange: boolean = false;
  alertService: AlertService;

  constructor(
    backend: ConnectionBackend,
    options: RequestOptions,
    alertService: AlertService
  ) {
    super(backend, options);
    this.alertService = alertService;
  }

  request(
    url: string | Request,
    options?: RequestOptionsArgs
  ): Observable<Response> {
    let token = sessionStorage.getItem('jwt');
    if (typeof url === 'string') {
      // meaning we have to add the token to the options, not in url
      if (!options) {
        options = { headers: new Headers() };
      }
      options.headers.set('Authorization', `Bearer ${token}`);
    } else {
      url.headers.set('Authorization', `Bearer ${token}`);
    }
    this.beforeRequest();
    return super
      .request(url, options)
      .map(res => {
        let jsonResult = res.json();
        if (jsonResult.code !== codeConstant.SUCCESS) {
          // common error alert from network request, can be overrided in each components.
          if (codeConstant.WARNING.findIndex(e => e === jsonResult.code) >= 0) {
            this.alertService.warning(
              `提示，${jsonResult.message}, 状态码:${jsonResult.code}`
            );
          } else {
            this.alertService.error(
              `服务器返回值异常，${jsonResult.message}, 错误码:${jsonResult.code}`
            );
          }
          throw jsonResult;
        }
        return res;
      })
      .catch(this.catchAuthError(this))
      .finally(() => {
        this.afterRequest();
      });
  }

  beforeRequest(): void {
    this.showLoadingBar();
  }

  afterRequest(): void {
    this.hideLoadingBar();
  }

  catchAuthError(self: HttpInterceptorService) {
    return (res: Response) => {
      switch (res.status) {
        case 0:
          this.alertService.error(`服务器请求被拒，状态码：${res.status}`);
          break;
        case 401:
          this.alertService.commonModal('您未登录或登录已过期，请重新登录');
          break;
        case 403:
          this.alertService.error(`服务器请求失败，状态码：${res.status}`);
          break;
        case 404:
          this.alertService.error(`找不到服务器资源，状态码：${res.status}`);
          break;
        case 500:
          this.alertService.error(`服务器内部错误，状态码：${res.status}`);
          break;
        default:
          break;
      }

      return Observable.throw(res);
    };
  }

  getLoadingBar(): Observable<any> {
    return this.subject.asObservable();
  }

  showLoadingBar(keepAfterRouteChange = false) {
    this.keepAfterRouteChange = keepAfterRouteChange;
    this.subject.next(true);
  }

  hideLoadingBar(keepAfterRouteChange = false) {
    this.keepAfterRouteChange = keepAfterRouteChange;
    this.subject.next(false);
  }
}
