import { TestBed, inject } from '@angular/core/testing';
import { HttpModule, ConnectionBackend } from '@angular/http';
import { ActivatedRoute } from '@angular/router';
import { Jsonp } from '@angular/http';

import { UserSelectorService } from './user-selector.service';

describe('UserSelectorService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpModule
      ],
      providers: [
        Jsonp,
        UserSelectorService,
        ConnectionBackend,
        { provide: ActivatedRoute, useValue: { params: [ {'Data': '1', 'Token': '2'} ] } }
      ]
    });
  });

  it('should be created', inject([UserSelectorService], (service: UserSelectorService) => {
    expect(service).toBeTruthy();
  }));
});
