import { Injectable } from '@angular/core';
import { URLSearchParams } from '@angular/http';
import { apiConstant } from '../constants/api.constant';
import { HttpInterceptorService } from './http-interceptor.service';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class CourseService {

  constructor(
    private http: HttpInterceptorService,
  ) { }

  getCourses(type): Observable<any> {
    let me = this;
    let params = new URLSearchParams();
    params.append('courseType', type);
    return me.http
      .get(apiConstant.courses, { search: params })
      .map(response => response.json());
  }

}
