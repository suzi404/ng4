import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { apiConstant } from '../constants/api.constant';
import { AuthenticationService } from './authentication.service';
import { HttpInterceptorService } from './http-interceptor.service';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class EmailService {

  constructor(
    private http: HttpInterceptorService,
    private authenticationService: AuthenticationService
  ) { }

  sendEmail(email): Observable<any> {
    let me = this;
    return me.http.post(apiConstant.email, email)
      .map(response => response.json());
  }
}
