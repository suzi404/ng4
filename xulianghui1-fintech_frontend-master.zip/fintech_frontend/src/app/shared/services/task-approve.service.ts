import { apiConstant } from './../constants/api.constant';
import { Observable } from 'rxjs/Rx';
import { URLSearchParams } from '@angular/http';
import { HttpInterceptorService } from './http-interceptor.service';
import { Injectable } from '@angular/core';

@Injectable()
export class TaskApproveService {

  constructor(private http: HttpInterceptorService) { }

  departmentLeaderApprove(taskId: string, opinion: boolean, applyId: string, leaderComment?: string): Observable<any> {
    let params = new URLSearchParams();
    params.set('taskId', taskId);
    params.set('agree', String(opinion));
    params.set('applyId', applyId);
    params.set('leaderComment', leaderComment);
    return this.http.post(apiConstant.departmentLeaderTask + `?${params.toString()}`, {}).map(response => response.json());
  }

  checkAssignee(taskId: string) {
    let params = new URLSearchParams();
    params.set('taskId', taskId);
    return this.http.get(apiConstant.checkAssignee + `?${params.toString()}`).map(response => response.json());
  }
}
