import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';

import { Subject } from 'rxjs/Subject';
import { Alert, AlertType, CommonModal } from '../models/alert.model';

@Injectable()
export class AlertService {
  subject = new Subject<Alert>();
  keepAfterRouteChange: boolean = false;
  modalSubject = new Subject<CommonModal>();

  constructor() { }

  getAlert(): Observable<Alert> {
    return this.subject.asObservable();
  }

  success(message: string, keepAfterRouteChange = false) {
    this.alert(AlertType.Success, message, keepAfterRouteChange);
  }

  error(message: string, keepAfterRouteChange = false) {
    this.alert(AlertType.Error, message, keepAfterRouteChange);
  }

  warning(message: string, keepAfterRouteChange = false) {
    this.alert(AlertType.Warning, message, keepAfterRouteChange);
  }

  alert(type, message: string, keepAfterRouteChange = false) {
    this.keepAfterRouteChange = keepAfterRouteChange;
    this.subject.next(<Alert>{ type: type, message: message });
  }

  getModal(): Observable<CommonModal> {
    return this.modalSubject.asObservable();
  }

  commonModal(message: string) {
    this.modalSubject.next(<CommonModal>{ message: message });
  }

}
