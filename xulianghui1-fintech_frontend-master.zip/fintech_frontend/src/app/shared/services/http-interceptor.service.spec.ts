import { async, TestBed, inject } from '@angular/core/testing';
import {
  HttpModule,
  ConnectionBackend,
  RequestOptions,
  RequestOptionsArgs,
  Response,
  Headers,
  Request
} from '@angular/http';
import { HttpInterceptorService } from './http-interceptor.service';
import { AlertService } from 'app/shared/services/alert.service';

describe('HttpInterceptorService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpModule,
      ],
      providers: [
        ConnectionBackend,
        HttpInterceptorService,
        AlertService
      ]
    });
  });

  it('should be created', inject([HttpInterceptorService], (service: HttpInterceptorService) => {
    expect(service).toBeTruthy();
  }));
});
