import { Injectable } from '@angular/core';
import { apiConstant } from '../constants/api.constant';
import { HttpInterceptorService } from './http-interceptor.service';
import { Observable } from 'rxjs/Observable';
import { codeConstant } from '../constants/code.constant';
import { permissionsConstant } from '../models/user.model';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class UserService {
  userPermissions = {};
  userPermissionsChange = new Subject<any>();
  userPermissionsChangeEmitted$ = this.userPermissionsChange.asObservable();

  constructor(private http: HttpInterceptorService) {}

  getPermissions(): Observable<any> {
    let me = this;
    return me.http
      .get(apiConstant.permissions)
      .map(response => response.json());
  }

  getUserPermissons(): void {
    let me = this;
    let permissons = me.getPermissions().subscribe(
      res => {
        console.debug('get permissons success');
        if (res.code === codeConstant.SUCCESS && res.data) {
          me.userPermissions = res.data;
          me.userPermissionsChange.next();
        }
      },
      error => {
        console.debug('get permissions failure', error);
      }
    );
  }

  // both "CAN_SUSPEND_PROJECT" and '600111' work in this function
  hasOneDefined(permissions): boolean {
    return Object.keys(this.userPermissions).some(x =>
      permissions.some(y => x === y || x === permissionsConstant[y])
    );
  }
}
