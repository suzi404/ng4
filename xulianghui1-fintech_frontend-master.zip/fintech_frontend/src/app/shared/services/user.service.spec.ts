import { TestBed, inject } from '@angular/core/testing';
import { HttpModule, ConnectionBackend } from '@angular/http';
import { ActivatedRoute } from '@angular/router';

import { HttpInterceptorService } from './http-interceptor.service';
import { UserService } from './user.service';
import { AlertService } from 'app/shared/services/alert.service';

describe('UserService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpModule
      ],
      providers: [
        { provide: ActivatedRoute },
        HttpInterceptorService,
        UserService,
        ConnectionBackend,
        AlertService
      ]
    });
  });

  it('should be created', inject([UserService], (service: UserService) => {
    expect(service).toBeTruthy();
  }));
});
