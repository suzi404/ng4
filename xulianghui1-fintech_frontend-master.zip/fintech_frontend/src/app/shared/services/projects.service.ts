import { Injectable } from '@angular/core';
import { URLSearchParams } from '@angular/http';
import { apiConstant } from '../constants/api.constant';
import { HttpInterceptorService } from './http-interceptor.service';
import { AuthenticationService } from './authentication.service';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class ProjectsService {
  constructor(
    private http: HttpInterceptorService,
    private authenticationService: AuthenticationService
  ) {}

  getProjectList(
    listType?: string,
    projectStatus?: string,
    projectAction?: string
  ): Observable<any> {
    let me = this;
    let params = new URLSearchParams();
    params.append('listType', listType);
    params.append('status', projectStatus);
    params.append('action', projectAction);
    return me.http
      .get(apiConstant.projects, { search: params })
      .map(response => response.json());
  }

  suspendProjects(
    projectApplyIds: Array<string>,
    message?: string
  ): Observable<any> {
    let me = this;
    let requestBody = {
      projectIds: projectApplyIds,
      message: message
    };
    return me.http
      .post(apiConstant.suspendProjects, requestBody)
      .map(response => response.json());
  }

  rejectProjects(
    projectApplyIds: Array<string>,
    message?: string
  ): Observable<any> {
    let me = this;
    let requestBody = {
      projectIds: projectApplyIds,
      message: message
    };
    return me.http
      .post(apiConstant.prjApplyManagerReject, requestBody)
      .map(response => response.json());
  }

  approveProjects(projecctApplyIds) {
    return this.http
      .post(apiConstant.proApplyManagerPass, projecctApplyIds)
      .map(response => response.json());
  }

  insertPersons(persons: any): Observable<any> {
    return this.http
      .post(apiConstant.insertPersons, persons)
      .map(response => response.json());
  }

  changeAssessors(projectApplyIds: Array<string>): Observable<any> {
    let me = this;
    let requestBody = projectApplyIds;
    return me.http
      .post(apiConstant.changeProjectsAssessors, requestBody)
      .map(response => response.json());
  }

  markProject(projectApplyId: Array<string>, mark: string): Observable<any> {
    let me = this;
    let params = new URLSearchParams();
    params.append('mark', mark);
    return me.http
      .get(apiConstant.projects + `/${projectApplyId}/mark`, { search: params })
      .map(response => response.json());
  }

  getProjectDetail(projectApplyId: string) {
    return this.http
      .get(apiConstant.projects + `/${projectApplyId}`)
      .map(response => response.json());
  }

  postReassignSupervisor(projectApplyId: string, leaderId: string) {
    return this.http
      .post(
        apiConstant.projects +
          `/leader/update?applyId=${projectApplyId}&leaderId=${leaderId}`,
        null
      )
      .map(response => response.json());
  }

  fetchLatestProjectStatus(projectApplyId: string) {
    return this.http
      .get(apiConstant.actions + `/${projectApplyId}/top`)
      .map(response => response.json());
  }

  fetchProjectMaterials(projectApplyId: string) {
    return this.http
      .get(apiConstant.actions + `/${projectApplyId}/allmaterial`)
      .map(response => response.json());
  }
}
