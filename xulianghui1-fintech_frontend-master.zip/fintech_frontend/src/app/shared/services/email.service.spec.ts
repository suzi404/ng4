import { TestBed, inject, async } from '@angular/core/testing';
import { HttpModule, ConnectionBackend } from '@angular/http';
import { ActivatedRoute } from '@angular/router';

import { EmailService } from './email.service';
import { AuthenticationService } from './authentication.service';
import { HttpInterceptorService } from './http-interceptor.service';
import { AlertService } from 'app/shared/services/alert.service';

describe('EmailService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpModule
      ],
      providers: [
        { provide: ActivatedRoute },
        EmailService,
        AuthenticationService,
        HttpInterceptorService,
        ConnectionBackend,
        AlertService
      ]
    });
  });

  it('should be created', inject([EmailService], (service: EmailService) => {
    expect(service).toBeTruthy();
  }));
});
