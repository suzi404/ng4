import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import { ActivatedRoute } from '@angular/router';
import { Jsonp, URLSearchParams, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Rx';

import { environment } from '../../../environments/environment';
const REMOTE_ADDRESS_BOOK_URL = environment.addressBookApiEndPoint;

// TODO: wired: If I remove Observable.of([]), will get error .finally is not a function
const demo = Observable.of([]);

@Injectable()
export class UserSelectorService {

  constructor(private jsonp: Jsonp) {
  }

  getInstitutionUser(orgId: string, hasRoot: string): Observable<any> {
    let params = new URLSearchParams();
    params.append('funcName', 'GetOrgUserOfOrgGroup');
    params.append('hasRoot', hasRoot);
    params.append('orgId', orgId);
    params.append('format', 'json');
    params.append('callback', 'JSONP_CALLBACK');

    return this.jsonp.request(REMOTE_ADDRESS_BOOK_URL, {search: params}).map(res => res.json());
  }

  searchInstitutionUser(orgId: string, key: string, type: string): Observable<any> {
    let params = new URLSearchParams();
    params.append('funcName', 'SearchCMBUserByKey');
    params.append('key', encodeURIComponent(key));
    params.append('type', type);
    params.append('orgId', orgId);
    params.append('format', 'json');
    params.append('callback', 'JSONP_CALLBACK');

    return this.jsonp.request(REMOTE_ADDRESS_BOOK_URL, {search: params}).map(res => res.json());
  }
}
