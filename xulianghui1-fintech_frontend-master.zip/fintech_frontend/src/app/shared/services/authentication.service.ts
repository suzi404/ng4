import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import { Subject } from 'rxjs/Subject';
import { apiConstant } from '../constants/api.constant';

@Injectable()
export class AuthenticationService {

  emitUserLogined = new Subject<any>();
  userLoginedEmitted$ = this.emitUserLogined.asObservable();

  constructor(
    private http: Http,
  ) { }

  jwt(): string {
    return sessionStorage.getItem('jwt');
  }

  username(): string {
    return sessionStorage.getItem('username');
  }

  isUserAuthenticated(): boolean {
    return sessionStorage.jwt;
  }

  requestOptions(): RequestOptions {
    let me = this;
    let headers = new Headers({ 'Authorization': 'Bearer ' + me.jwt() });
    return new RequestOptions({ headers: headers });
  }

  authenticate(data, token): Promise<any> {
    let me = this;
    let queryParameters = `Data=${data}&Token=${token}`;
    return me.http.get(apiConstant.authenticate + '?' + queryParameters, me.requestOptions())
      .toPromise()
      .then(response => response.json());
  }

  setUserLoginData(userLoginData): void {
    let me = this;
    sessionStorage.setItem('jwt', userLoginData['jwt'] ? userLoginData['jwt']['access_token'] : '');
    sessionStorage.setItem('username', userLoginData['userName']);
    me.emitUserChange();
  }

  emitUserChange(): void {
    this.emitUserLogined.next();
  }

  fakeLogin(userId): Promise<any> {
    let me = this;
    return me.http.get(apiConstant.fakeLogin + '/' + userId)
      .toPromise()
      .then(response => response.json());
  }
}
