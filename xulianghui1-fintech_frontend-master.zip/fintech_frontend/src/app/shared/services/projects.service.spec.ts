import { TestBed, inject } from '@angular/core/testing';
import { HttpModule, ConnectionBackend } from '@angular/http';
import { ActivatedRoute } from '@angular/router';

import { HttpInterceptorService } from './http-interceptor.service';
import { ProjectsService } from './projects.service';
import { AuthenticationService } from './authentication.service';
import { AlertService } from 'app/shared/services/alert.service';

describe('ProjectsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpModule,
      ],
      providers: [
        { provide: ActivatedRoute },
        ProjectsService,
        AuthenticationService,
        HttpInterceptorService,
        ConnectionBackend,
        AlertService
      ]
    });
  });

  it('should be created', inject([ProjectsService], (service: ProjectsService) => {
    expect(service).toBeTruthy();
  }));
});
