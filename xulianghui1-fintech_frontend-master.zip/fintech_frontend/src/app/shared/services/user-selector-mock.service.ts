import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import { ActivatedRoute } from '@angular/router';
import { Jsonp, URLSearchParams, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Rx';

const rootResponse = [
  {
    'id': '100001',
    'text': '招商银行/100001',
    'state': 'open',
    'attributes': 'CANSELECT=Y',
    'iconCls': null,
    'children': [
      {
        'id': '100003',
        'text': '总行/100003',
        'state': 'closed',
        'attributes': 'TEXT=总行/100003:ORGID=100003:GPID=0100000000:NAME=总行:GPNM=总行:PATH=总行:EMAIL=@cmbchina.com',
        'iconCls': 'tree-folder',
        'children': []
      },
      {
        'id': '100314',
        'text': '北京分行/100314',
        'state': 'closed',
        'attributes': 'TEXT=北京分行/100314:ORGID=100314:GPID=0201000000:NAME=北京分行:GPNM=北京分行:PATH=北京分行:EMAIL=@cmbchina.com',
        'iconCls': 'tree-folder',
        'children': []
      },
      {
        'id': '103324',
        'text': '长春分行/103324',
        'state': 'closed',
        'attributes': 'TEXT=长春分行/103324:ORGID=103324:GPID=0243100000:NAME=长春分行:GPNM=长春分行:PATH=长春分行:EMAIL=@cmbchina.com',
        'iconCls': 'tree-folder',
        'children': []
      },
      {
        'id': '100003',
        'text': '总行/100003',
        'state': 'closed',
        'attributes': 'TEXT=总行/100003:ORGID=100003:GPID=0100000000:NAME=总行:GPNM=总行:PATH=总行:EMAIL=@cmbchina.com',
        'iconCls': 'tree-folder',
        'children': []
      },
      {
        'id': '100314',
        'text': '北京分行/100314',
        'state': 'closed',
        'attributes': 'TEXT=北京分行/100314:ORGID=100314:GPID=0201000000:NAME=北京分行:GPNM=北京分行:PATH=北京分行:EMAIL=@cmbchina.com',
        'iconCls': 'tree-folder',
        'children': []
      },
      {
        'id': '103324',
        'text': '长春分行/103324',
        'state': 'closed',
        'attributes': 'TEXT=长春分行/103324:ORGID=103324:GPID=0243100000:NAME=长春分行:GPNM=长春分行:PATH=长春分行:EMAIL=@cmbchina.com',
        'iconCls': 'tree-folder',
        'children': []
      }
    ]
  }
];

const RESPONSE_OF_100003 = [
  {
    'id': '109177',
    'text': '海口分行/109177',
    'state': 'closed',
    'attributes': 'TEXT=海口分行/109177:ORGID=109177:GPID=0289800000:NAME=海口分行:GPNM=海口分行:PATH=海口分行:EMAIL=@cmbchina.com',
    'iconCls': 'tree-folder',
    'children': []
  },
];

const RESPONSE_OF_109177 = [
  {
    'id': '100593',
    'text': '广州分行/100593',
    'state': 'closed',
    'attributes': 'TEXT=广州分行/100593:ORGID=100593:GPID=0202000000:NAME=广州分行:GPNM=广州分行:PATH=广州分行:EMAIL=@cmbchina.com',
    'iconCls': 'tree-folder',
    'children': []
  }
];

const RESPONSE_OF_100593 = [
  {
    'id': '097578',
    'text': '汪建中/097578',
    'state': 'open',
    'attributes': 'TEXT=汪建中/00750103:USID=097578:ORGID=100315:NAME=汪建中:SAPID=00750103:PATH=北京分行/行长室:EMAIL=wjz@cmbchina.com:POSI=分行行长',
    'iconCls': 'tree-file',
    'children': []
  }
];

const USER_RESPONSE_FOR_QUERY = [
  {
    'id': '123456',
    'text': '宋承宪/123456',
    'state': 'open',
    'attributes': 'TEXT=我的名字/00750103:USID=097578:ORGID=100315:NAME=汪建中:SAPID=00750103:PATH=北京分行/行长室2:EMAIL=wjz@cmbchina.com:POSI=分行行长',
    'iconCls': 'tree-file',
    'children': []
  },
  {
    'id': '123456',
    'text': '宋承宪/123456',
    'state': 'open',
    'attributes': 'TEXT=我的名字/00750103:USID=097578:ORGID=100315:NAME=汪建中:SAPID=00750103:PATH=北京分行/行长室2:EMAIL=wjz@cmbchina.com:POSI=分行行长',
    'iconCls': 'tree-file',
    'children': []
  }
];

@Injectable()
export class UserSelectorService {

  constructor(private jsonp: Jsonp) {
  }

  getInstitutionUser(orgId: string, hasRoot: string): Observable<any> {
    let me = this;
    if (hasRoot === 'N') {
      return Observable.of(rootResponse);
    }

    switch (orgId) {
      case '100003':
        return Observable.of(RESPONSE_OF_100003);
      case '109177':
        return Observable.of(RESPONSE_OF_109177);
      case '100593':
        return Observable.of(RESPONSE_OF_100593);
      default:
        return Observable.of([]);
    }
  }

  searchInstitutionUser(orgId: string, key: string, type: string): Observable<any> {
    return Observable.of(USER_RESPONSE_FOR_QUERY);
  }
}
