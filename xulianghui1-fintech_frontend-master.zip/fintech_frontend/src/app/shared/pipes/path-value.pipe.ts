import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'pathValue'
})

export class PathValuePipe implements PipeTransform {

  transform(value: string) {
    let rst;
    let pattern = new RegExp('PATH=(.*?):');
    if (pattern.test(value)) {
      rst = RegExp.$1;
    }
    return rst;
  }
}
