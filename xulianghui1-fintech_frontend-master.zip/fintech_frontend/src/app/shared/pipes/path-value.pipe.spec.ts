import { PathValuePipe } from './path-value.pipe';

describe('PathValuePipe', () => {
  it('create an instance', () => {
    const pipe = new PathValuePipe();
    expect(pipe).toBeTruthy();
  });
});
