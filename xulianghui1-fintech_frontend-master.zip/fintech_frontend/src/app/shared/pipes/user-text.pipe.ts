import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'userText'
})
export class UserTextPipe implements PipeTransform {

  transform(value: string): string {
    const matches = value.split('/');
    return `${matches[0]}（${matches[1]}）`;
  }
}
