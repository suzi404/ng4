import { UserTextPipe } from './user-text.pipe';

describe('UserTextPipe', () => {
  it('create an instance', () => {
    const pipe = new UserTextPipe();
    expect(pipe).toBeTruthy();
  });
});
