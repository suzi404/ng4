import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { HttpModule, RequestOptions, XHRBackend } from '@angular/http';

import { GlobalHeaderComponent } from './components/global-header/global-header.component';
import { GlobalFooterComponent } from './components/global-footer/global-footer.component';
import { AlertComponent } from './components/alert/alert.component';
import { IndicatorComponent } from './components/indicator/indicator.component';
import { IndicatorUnitComponent } from './components/indicator-unit/indicator-unit.component';
import { NoDataComponent } from './components/no-data/no-data.component';
import { PathValuePipe } from './pipes/path-value.pipe';
import { UserSelectorTreeComponent } from './components/user-selector/user-selector-tree/user-selector-tree.component';
import { UserSelectListComponent } from './components/user-selector/user-select-list/user-select-list.component';
import { UserSelectorComponent } from './components/user-selector/user-selector.component';
import { LoadingComponent } from './components/loading/loading.component';
import { LoadingBarComponent } from './components/loading-bar/loading-bar.component';
import { ConfirmModalComponent } from './components/confirm-modal/confirm-modal.component';
import { CommonModalComponent } from './modals/common-modal/common-modal.component';

import { AuthenticationService } from './services/authentication.service';
import { UserSelectorService } from './services/user-selector.service';
import { EmailService } from './services/email.service';
import { AlertService } from './services/alert.service';
import { HttpInterceptorService } from './services/http-interceptor.service';
import { CourseService } from './services/course.service';

import { UserTextPipe } from './pipes/user-text.pipe';
import { UserService } from './services/user.service';
import { HasPermissionDirective } from './directives/has-permission.directive';
import { NeedConfirmDirective } from './directives/need-confirm.directive';

export function httpFactory(backend: XHRBackend, options: RequestOptions, alertService: AlertService) {
  return new HttpInterceptorService(backend, options, alertService);
}

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
  ],
  declarations: [
    GlobalHeaderComponent,
    GlobalFooterComponent,
    AlertComponent,
    IndicatorComponent,
    IndicatorUnitComponent,
    NoDataComponent,
    LoadingComponent,
    PathValuePipe,
    UserSelectorTreeComponent,
    UserSelectListComponent,
    UserSelectListComponent,
    UserSelectorComponent,
    UserTextPipe,
    HasPermissionDirective,
    LoadingBarComponent,
    ConfirmModalComponent,
    NeedConfirmDirective,
    CommonModalComponent,
  ],
  exports: [
    GlobalHeaderComponent,
    GlobalFooterComponent,
    AlertComponent,
    IndicatorComponent,
    IndicatorUnitComponent,
    NoDataComponent,
    LoadingComponent,
    PathValuePipe,
    UserTextPipe,
    UserSelectorTreeComponent,
    UserSelectListComponent,
    UserSelectListComponent,
    UserSelectorComponent,
    HasPermissionDirective,
    LoadingBarComponent,
    NeedConfirmDirective,
    CommonModalComponent,
  ],
  entryComponents: [
    ConfirmModalComponent,
  ],
  providers: [
    AuthenticationService,
    EmailService,
    CourseService,
  ]
})

export class SharedModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: SharedModule,
      providers: [
        AlertService,
        UserService,
        {
          provide: HttpInterceptorService,
          useFactory: httpFactory,
          deps: [XHRBackend, RequestOptions, AlertService]
        }
      ]
    };
  }
}
