export class Alert {
    type: AlertType;
    message: string;
}

export enum AlertType {
    Success,
    Error,
    Warning
}

export class CommonModal {
    message: string;
}
