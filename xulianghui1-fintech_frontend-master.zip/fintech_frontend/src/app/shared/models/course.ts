export class Course {
  curriculumId: number;
  curriculumName: string;
  curriculumDescribe: string;
  curriculumType: number;
  url: string;
  ystId: number;
  ystName: string;
  uploadTime: number;
}

