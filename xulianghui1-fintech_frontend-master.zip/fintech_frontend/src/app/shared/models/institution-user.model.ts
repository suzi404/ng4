export class InstitutionUser {
  constructor(public attributes: string,
              public children: InstitutionUser[],
              public iconCls: string,
              public id: string,
              public state: string,
              public text: string) { }
}
