export enum LabelType {
  innovationArea = 1,
  techUsed = 2,
}

export const stakeholders = {
  itManager: 'PR0007',
  sandboxSupporter: 'PR0008',
};
