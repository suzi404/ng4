export const projectTypeConstant = {
  'managed': '1',
};

export const projectStatusConstant = {
  'suspended': '-1',
  'internalChecking': '11',
  'readyForCheck': '12',
  'approved': '13',
};


export const PROJECT_STATUSES = {
  project_submission: {
    internal_auditing: {
      initial: 111,
      initial_switch_reviewer: 112,
      rejected: 113,
      switch_reviewer: 114,
      suspended: 119,
    },
    waiting_approved: {
      initial: 121,
      touched: 122,
      suspended: 129,
    },
    approved: {
      initial: 131,
      assigned: 132,
      suspended: 129,
    }
  },
  value_hypothesis: {
    workshop: {

    },
    material_submitted: {

    },
    approved: {

    }
  },
  ground_plan: {
    stage1: {

    }
  },
  sandbox_validation: {
    stage1: {

    }
  }

};

export const courseTypeConstant = {
  'courseType': '1',
};
