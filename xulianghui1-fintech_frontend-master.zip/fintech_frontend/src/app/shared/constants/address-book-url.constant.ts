export const addressBookUrlConstant = {
  dev: 'http://99.1.101.45/AddressWeb/Service/AddressJsonpProvider.aspx',
  prod: 'https://ab.office.cmbchina.com/addressbook/web/Service/AddressJsonpProvider.aspx'
};
