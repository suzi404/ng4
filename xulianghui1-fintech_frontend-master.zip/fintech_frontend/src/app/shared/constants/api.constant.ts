import { environment } from '../../../environments/environment';
const adminApi: string = environment.adminApiEndPoint;
const businessApi: string = environment.businessApiEndPoinst;

export const apiConstant = {
  'authenticate': adminApi + 'user/login',
  'permissions': adminApi + 'user/permissions',
  'fakeLogin': adminApi + 'user/fakeLogin',
  'userInfo': adminApi + 'user/ystInfo',
  'email': businessApi + 'mails/connect',
  'projects': businessApi + 'projects',
  'actions': businessApi + 'actions',
  'suspendProjects': businessApi + 'projects/suspend',
  'insertPersons': businessApi + 'persons/insert',
  'changeProjectsAssessors': businessApi + 'projects/leaders/update',
  'questions': businessApi + 'questions',
  'answers': businessApi + 'answers',
  'fintechWorkflow': businessApi + 'fintechWorkflow',
  'labels': businessApi + 'labels',
  'departmentLeaderTask': businessApi + 'task/deptLeaderComplete',
  'prjApplyManagerReject': businessApi + 'task/prjApplyManagerReject',
  'proApplyManagerPass': businessApi + 'task/prjApplyManagerPass',
  'checkAssignee': businessApi + 'task/checkAssignee',
  'courses': businessApi + 'courses',
};
