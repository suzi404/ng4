export const codeConstant = {
  'SUCCESS': '0',
  'WARNING': ['051001', '051012', '051013']
};

export const exceptionCodeConstant = {
  suspend_half_success: '010108',
  change_assessor_partial_success: '010110',
  reject_half_success: '051014',
  approve_half_success: '051015'
};
