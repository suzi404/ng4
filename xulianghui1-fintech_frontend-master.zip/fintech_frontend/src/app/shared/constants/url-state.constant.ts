export const urlStateConstant = {
  'department-leader': 'task-approve/department-leader',
};
