import { NeedConfirmDirective } from './need-confirm.directive';

describe('NeedConfirmDirective', () => {
  // it('should create an instance', () => {
  //   const directive = new NeedConfirmDirective();
  //   expect(directive).toBeTruthy();
  // });
});
