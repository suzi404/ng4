import { Directive, OnInit, Input, ElementRef } from '@angular/core';
import { UserService } from '../services/user.service';

@Directive({
  selector: '[appHasPermission]'
})

export class HasPermissionDirective implements OnInit {
  @Input('appHasPermission') permissions: Array<string>;

  context = {
    scopeElem: null,
    scopeUserService: null,
  };

  constructor(
    private elem: ElementRef,
    private userService: UserService
  ) {
    this.context.scopeElem = elem;
    this.context.scopeUserService = userService;
  }

  ngOnInit() {
    this.context.scopeElem.nativeElement.style.display = 'none';
    if (this.context.scopeUserService.userPermissions) {
      this.applyPermission();
    }
    this.context.scopeUserService.userPermissionsChangeEmitted$
      .subscribe(() => {
        this.applyPermission();
      });
  }

  applyPermission(): void {
    let me = this;
    let hasDefined = this.context.scopeUserService.hasOneDefined(this.permissions);
    if (!hasDefined) {
      me.elem.nativeElement.style.display = 'none';
    } else {
      me.elem.nativeElement.style.display = 'inherit';
    }
  }

}
