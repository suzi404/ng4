import { Component } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpModule, ConnectionBackend } from '@angular/http';
import { By } from '@angular/platform-browser';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';

import { HasPermissionDirective } from './has-permission.directive';
import { HttpInterceptorService } from '../services/http-interceptor.service';
import { UserService } from '../services/user.service';
import { AlertService } from '../services/alert.service';

const mockPermissionList = require('mockServer/resources/userPermissions');

@Component({
  template: `
    <a [appHasPermission]="['CAN_TEST']">指派IT负责人</a>
  `
})
class TestComponent { }

describe('HasPermissionDirective', () => {
  let fixture: ComponentFixture<TestComponent>;
  let userService: UserService;
  let elements;

  beforeEach(async(() => {
    fixture = TestBed.configureTestingModule({
      imports: [ HttpModule ],
      declarations: [ HasPermissionDirective, TestComponent ],
      providers: [
        HttpInterceptorService,
        ConnectionBackend,
        UserService,
        AlertService,
      ]
    })
    .createComponent(TestComponent);
  }));

  beforeEach(() => {
    userService = fixture.debugElement.injector.get(UserService);
    spyOn(userService, 'getUserPermissons').and.returnValue(Observable.of(mockPermissionList));

    elements = fixture.debugElement.queryAll(By.directive(HasPermissionDirective));
    fixture.detectChanges();
  });

  it('should have 1 element with appHasPermission directive', () => {
    userService.userPermissionsChange.next();
    fixture.detectChanges();
    expect(elements.length).toBe(1);
  });

  it('should not display none when has permission', () => {
    spyOn(userService, 'hasOneDefined').and.returnValue(true);
    userService.userPermissionsChange.next();
    expect(elements[0].nativeElement.style.display).not.toEqual('none');
  });

  it('should display none when does not have permission', () => {
    spyOn(userService, 'hasOneDefined').and.returnValue(false);
    userService.userPermissionsChange.next();
    expect(elements[0].nativeElement.style.display).toEqual('none');
  });

});
