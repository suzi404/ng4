import { Directive, Input, ElementRef, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ConfirmModalComponent } from '../components/confirm-modal/confirm-modal.component';

@Directive({
  selector: '[appNeedConfirmCallback]'
})
export class NeedConfirmDirective implements OnInit {
  @Input('appNeedConfirmCallback') confirmCallBackFunction: Function;
  @Input('appNeedConfirmCallbackArgs') confirmCallBackFunctionArgs: any;

  constructor(
    private elem: ElementRef,
    private modalService: NgbModal
  ) { }

  ngOnInit() {
    this.elem.nativeElement.onclick = this.openConfirmDialog.bind(this);
  }

  openConfirmDialog() {
    let me = this;
    const modalRef = me.modalService.open(ConfirmModalComponent, {size: 'sm'});
    modalRef.result
      .then(() => {
        if (me.confirmCallBackFunctionArgs) {
          me.confirmCallBackFunction(me.confirmCallBackFunctionArgs);
        } else {
          me.confirmCallBackFunction();
        }
      })
      .catch(() => {});
  }
}
