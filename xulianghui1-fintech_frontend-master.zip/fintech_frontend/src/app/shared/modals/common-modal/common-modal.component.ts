import { Component, OnInit } from '@angular/core';
import { AlertService } from '../../services/alert.service';
import { CommonModal } from '../../models/alert.model';

@Component({
  selector: 'app-common-modal',
  templateUrl: './common-modal.component.html',
  styleUrls: ['./common-modal.component.scss']
})
export class CommonModalComponent implements OnInit {
  showModal: boolean = false;
  commonModal: CommonModal;

  constructor(
    private alertService: AlertService,
  ) { }

  ngOnInit() {
    this.addModal();
  }

  addModal(): void {
    let me = this;
    me.alertService.getModal().subscribe((commonModal: CommonModal) => {
      me.showModal = true;
      me.commonModal = commonModal;
    });
  }
}
