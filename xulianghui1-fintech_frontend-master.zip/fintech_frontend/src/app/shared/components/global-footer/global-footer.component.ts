import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-global-footer',
  templateUrl: './global-footer.component.html',
  styleUrls: ['./global-footer.component.scss']
})
export class GlobalFooterComponent implements OnInit {
  menu = [
    {'category': '首页', 'subMenu': [{
      'title': '创新模式',
      'link': '#incubation-model'
    }, {
      'title': '创新领域',
      'link': '#innovation-area'
    }, {
      'title': '创新流程',
      'link': '#incubation-workflow'
    }, {
      'title': '常见问题',
      'link': '#popular-questions'
    }]},
    {'category': '项目', 'subMenu': [{
      'title': '申请项目',
      'link': '/questionnaire'
    }, {
      'title': '我的项目',
      'link': '/projects/applied'
    }]},
    {'category': '资源', 'subMenu': [{
      'title': '视频教学',
      'link': '/resources/lean-courses'
    }, {
      'title': '书籍推荐',
      'link': '/resources/lean-courses'
    }]},
    {'category': '帮助', 'subMenu': [{
      'title': '常见问题',
      'link': '#popular-questions'
    }]}
  ];

  constructor() { }

  ngOnInit() {
  }

}
