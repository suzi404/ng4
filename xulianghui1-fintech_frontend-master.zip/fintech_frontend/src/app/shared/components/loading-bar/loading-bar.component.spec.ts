import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpModule, ConnectionBackend } from '@angular/http';

import { LoadingBarComponent } from './loading-bar.component';
import { LoadingComponent } from '../loading/loading.component';
import { HttpInterceptorService } from '../../services/http-interceptor.service';
import { AlertService } from 'app/shared/services/alert.service';

describe('LoadingBarComponent', () => {
  let component: LoadingBarComponent;
  let fixture: ComponentFixture<LoadingBarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpModule,
      ],
      declarations: [
        LoadingComponent,
        LoadingBarComponent,
      ],
      providers: [
        HttpInterceptorService,
        ConnectionBackend,
        AlertService
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoadingBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
