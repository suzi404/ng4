import { Component, OnInit, ViewEncapsulation } from '@angular/core';

import { HttpInterceptorService } from '../../services/http-interceptor.service';

@Component({
  selector: 'app-loading-bar',
  templateUrl: './loading-bar.component.html',
  styleUrls: ['./loading-bar.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class LoadingBarComponent implements OnInit {
  showLoadingBar: boolean = false;

  constructor(
    private httpInterceptorService: HttpInterceptorService
  ) { }

  ngOnInit() {
    this.addLoadingBar();
  }

  addLoadingBar(): void {
    let me = this;
    me.httpInterceptorService.getLoadingBar()
      .subscribe(
        (isShow) => {
          isShow ? me.show() : me.hide();
        }
      );
  }

  show(): void {
    this.showLoadingBar = true;
  }

  hide(): void {
    this.showLoadingBar = false;
  }
}
