import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-indicator-unit',
  templateUrl: './indicator-unit.component.html',
  styleUrls: ['./indicator-unit.component.scss']
})
export class IndicatorUnitComponent implements OnInit {
  constructor() {}

  @Input() isActived = false;
  @Input() progress = 0;
  @Input() stepNumber = 0;
  @Input() stepDesc = '';

  ngOnInit() {}
}
