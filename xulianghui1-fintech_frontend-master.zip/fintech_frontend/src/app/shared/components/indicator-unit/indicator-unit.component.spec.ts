import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IndicatorUnitComponent } from './indicator-unit.component';

describe('IndicatorUnitComponent', () => {
  let component: IndicatorUnitComponent;
  let fixture: ComponentFixture<IndicatorUnitComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IndicatorUnitComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IndicatorUnitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
