import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-indicator',
  templateUrl: './indicator.component.html',
  styleUrls: ['./indicator.component.scss']
})
export class IndicatorComponent implements OnInit {
  @Input() currStep = 0;
  @Input() currStepProgress = 0;
  stepsInfo = [
    { number: '1', desc: '自学问卷' },
    { number: '2', desc: '项目申请表' },
    { number: '3', desc: '等待审核' },
    { number: '4', desc: '申报成功' }
  ];

  constructor() {}

  ngOnInit() {
    this.stepsInfo = this.stepsInfo.map((step, index) => {
      let isActived = index < this.currStep;

      let progress = isActived ? 100 : 0;
      if (index === this.currStep - 1) {
        progress = this.currStepProgress;
      }

      return {
        ...step,
        isActived,
        progress
      };
    });
  }
}
