import { async, ComponentFixture, TestBed, tick, fakeAsync } from '@angular/core/testing';

import { AlertComponent } from './alert.component';
import { AlertService } from '../../services/alert.service';
import { Alert, AlertType } from '../../models/alert.model';

describe('AlertComponent', () => {
  let component: AlertComponent;
  let fixture: ComponentFixture<AlertComponent>;
  let alertService: AlertService;
  let stubAlert1: Alert = {
      type: AlertType.Success,
      message: '成功',
  };
  let stubAlert2: Alert = {
      type: AlertType.Error,
      message: '失败',
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        AlertComponent
      ],
      providers: [
        AlertService
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AlertComponent);
    component = fixture.componentInstance;
    alertService = fixture.debugElement.injector.get(AlertService);

    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should subscribe alert', () => {
    expect(component.alerts).toEqual([]);
    alertService.subject.next(stubAlert1);
    fixture.detectChanges();
    expect(component.alerts).toEqual([stubAlert1]);

    alertService.subject.next();
    fixture.detectChanges();
    expect(component.alerts).toEqual([]);
  });

  it('should remove alert', () => {
    component.alerts = [stubAlert1, stubAlert2];
    component.removeAlert(stubAlert1);
    fixture.detectChanges();
    expect(component.alerts).toEqual([stubAlert2]);
  });

  it('should remove alert automatically', <any>fakeAsync((): void => {
    component.alerts = [stubAlert1, stubAlert2];
    component.removeAlertAutomatically(stubAlert1);
    fixture.detectChanges();
    expect(component.alerts).toEqual([stubAlert1, stubAlert2]);
    tick(component.alertDispalyTime + 1);
    expect(component.alerts).toEqual([stubAlert2]);
  }));

});
