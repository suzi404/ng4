import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpModule, ConnectionBackend } from '@angular/http';
import { ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpInterceptorService } from '../../services/http-interceptor.service';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';

import { GlobalHeaderComponent } from './global-header.component';
import { AuthenticationService } from '../../services/authentication.service';
import { UserService } from '../../services/user.service';
import { HasPermissionDirective } from '../../directives/has-permission.directive';
import { AlertService } from 'app/shared/services/alert.service';

describe('GlobalHeaderComponent', () => {
  let component: GlobalHeaderComponent;
  let authenticationService: AuthenticationService;
  let userService: UserService;
  let fixture: ComponentFixture<GlobalHeaderComponent>;

  let stubAuthenticateResponse = {
    'code': '0',
    'message': 'authentication success',
    'data': {
      'jwt': 'abcdefg',
      'userName': '张海东'
   }
 };
 let stubPermissionsResponse = { 'code': '0', 'message': '成功' };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        GlobalHeaderComponent,
        HasPermissionDirective,
      ],
      imports: [
        HttpModule,
        RouterTestingModule,
      ],
      providers: [
        HttpInterceptorService,
        ConnectionBackend,
        AlertService,
        AuthenticationService,
        UserService,
        { provide: ActivatedRoute, useValue: { params: [ {'Data': '1', 'Token': '2'} ] } }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GlobalHeaderComponent);
    component = fixture.componentInstance;
    authenticationService = fixture.debugElement.injector.get(AuthenticationService);
    userService = fixture.debugElement.injector.get(UserService);
    spyOn(authenticationService, 'authenticate').and.returnValue(Promise.resolve(stubAuthenticateResponse));
    spyOn(userService, 'getPermissions').and.returnValue(Observable.of(stubPermissionsResponse));

    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
