import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../../services/authentication.service';
import { UserService } from '../../services/user.service';
import { codeConstant } from '../../constants/code.constant';
import { Router } from '@angular/router';
import { UserRole } from '../../models/user.model';

@Component({
  selector: 'app-global-header',
  templateUrl: './global-header.component.html',
  styleUrls: ['./global-header.component.scss']
})
export class GlobalHeaderComponent implements OnInit {
  user = {
    username: '未登陆',
    role: UserRole.Applicant
  };
  userRole = UserRole;

  constructor(
    private router: Router,
    private userService: UserService,
    private authenticationService: AuthenticationService
  ) { }

  ngOnInit() {
    this.checkAuthentication();
  }

  checkAuthentication(): void {
    let me = this;
    me.subscribeUserLogin();
    if (me.authenticationService.isUserAuthenticated()) {
      me.setUser();
      me.getUserPermissons();
    }
  }

  subscribeUserLogin(): void {
    let me = this;
    me.authenticationService.userLoginedEmitted$
      .subscribe(
        () => {
          me.setUser();
        });
  }

  setUser(): void {
    this.user['username'] = this.authenticationService.username();
  }

  getUserPermissons(): void {
    let me = this;
    me.userService.getUserPermissons();
  }

}
