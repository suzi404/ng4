import { Component, OnInit, Input, Output, EventEmitter, Pipe, PipeTransform } from '@angular/core';
import _ from 'lodash';

import { AlertService } from '../../services/alert.service';
import { UserSelectorService } from '../../services/user-selector.service';
import { InstitutionUser } from '../../models/institution-user.model';

@Component({
  selector: 'app-user-selector',
  templateUrl: './user-selector.component.html',
  styleUrls: [ './user-selector.component.scss' ],
})

export class UserSelectorComponent implements OnInit {
  @Input() submitText: string;
  @Input() mutilSelect: boolean;
  @Output() userSelectedEvent: EventEmitter<InstitutionUser[]> = new EventEmitter<InstitutionUser[]>();

  message = 'Loading';
  loading = true;
  searchKey = '';
  isSearch = false;
  searchResult: InstitutionUser[];
  topOrgId = '100001';
  topInstitutionUser: InstitutionUser;
  userList: InstitutionUser[] = [];

  constructor(
    private userSelectorService: UserSelectorService,
    private alertService: AlertService,
  ) {}

  ngOnInit() {
    this.userSelectorService.getInstitutionUser(this.topOrgId, 'N')
      .finally(() => this.loading = false)
      .subscribe(
        data => {
          this.topInstitutionUser = data[0];
        },
        error => console.log(error)
      );
  }

  addToUserList(user: InstitutionUser) {
    if (this.userList.indexOf(user) >= 0) {
      this.alertService.warning('当前用户已被添加!');
      return;
    }
    if (!this.mutilSelect && this.userList.length >= 1) {
      this.alertService.warning('只能选择一项!');
      return;
    }
    this.userList.push(user);
  }

  delUserFromUserList(user: InstitutionUser) {
    let index = this.userList.indexOf(user);
    if (index < 0) {
      return;
    }
    this.userList.splice(index, 1);
  }

  submit() {
    this.userSelectedEvent.emit(this.userList);
  }

  setSearchKey(val: string) {
    this.searchKey = val;
  }

  searchInstitutionUser(key: string) {
    if (!key || key === '') {
      this.alertService.warning('请输入关键字！');
      return;
    }
    this.loading = true;
    this.message = 'Loading';
    this.isSearch = true;
    this.setSearchKey(key);
    this.userSelectorService.searchInstitutionUser(this.topOrgId, this.searchKey, '0')
      .finally(() => this.loading = false)
      .subscribe(
        data => {
          console.log(data);
          this.searchResult = data;
          if (this.searchResult.length === 0) {
            this.loading = true;
            this.message = '未发现记录';
          }
        },
        error => console.log(error)
      );

  }

  clearSearchItems() {
    this.searchKey = '';
    this.isSearch = false;
    this.loading = false;
  }

  checkIfEmpty(value) {
    if (!this.searchKey) {
      this.isSearch = false;
      this.loading = false;
    }
  }
}
