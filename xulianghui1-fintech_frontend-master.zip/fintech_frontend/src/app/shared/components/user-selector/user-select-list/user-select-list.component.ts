import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { InstitutionUser } from '../../../models/institution-user.model';

@Component({
  selector: 'app-user-select-list',
  templateUrl: './user-select-list.component.html',
  styleUrls: [ './user-select-list.component.scss' ]
})

export class UserSelectListComponent {
  @Input() isSearchResult: boolean;
  @Input() userList: InstitutionUser[];
  @Output() removeUserEvent: EventEmitter<InstitutionUser> = new EventEmitter<InstitutionUser>();
  @Output() userSelectEvent: EventEmitter<InstitutionUser> = new EventEmitter<InstitutionUser>();

  removeUser(user: InstitutionUser) {
    this.removeUserEvent.emit(user);
  }

  handleAddUser(user) {
    this.userSelectEvent.emit(user);
  }
}
