import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserSelectListComponent } from './user-select-list.component';
import { PathValuePipe } from '../../../pipes/path-value.pipe';
import { UserTextPipe } from '../../../pipes/user-text.pipe';

describe('UserSelectListComponent', () => {
  let component: UserSelectListComponent;
  let fixture: ComponentFixture<UserSelectListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        UserSelectListComponent,
        PathValuePipe,
        UserTextPipe,
      ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserSelectListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
