import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { HttpModule, ConnectionBackend } from '@angular/http';
import { Jsonp } from '@angular/http';

import { UserSelectorService } from '../../../services/user-selector.service';
import { UserTextPipe } from '../../../pipes/user-text.pipe';
import { UserSelectorTreeComponent } from './user-selector-tree.component';
import { LoadingComponent } from '../../loading/loading.component';

describe('UserSelectorTreeComponent', () => {
  let component: UserSelectorTreeComponent;
  let fixture: ComponentFixture<UserSelectorTreeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpModule,
        FormsModule,
      ],
      declarations: [
        UserSelectorTreeComponent,
        UserTextPipe,
        LoadingComponent,
      ],
      providers: [
        UserSelectorService,
        Jsonp,
        ConnectionBackend,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserSelectorTreeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
