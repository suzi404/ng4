import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { UserSelectorService } from '../../../services/user-selector.service';
import { InstitutionUser } from '../../../models/institution-user.model';

@Component({
  selector: 'app-user-selector-tree',
  templateUrl: './user-selector-tree.component.html',
  styleUrls: [ './user-selector-tree.component.scss' ]
})

export class UserSelectorTreeComponent implements OnInit {
  @Input() isRoot: boolean;
  @Input() institutionUser: InstitutionUser;
  // children: InstitutionUser[];
  isExpand: boolean = false;
  loading: boolean = false;


  @Output() userSelectEvent: EventEmitter<InstitutionUser> = new EventEmitter<InstitutionUser>();
  @Output() removeUserEvent: EventEmitter<InstitutionUser> = new EventEmitter<InstitutionUser>();

  constructor(private userSelectorService: UserSelectorService) {
  }

  ngOnInit() {
    if (this.isRoot) {
      this.isExpand = true;
    }
  }

  toggleOrg() {
    this.isExpand = !this.isExpand;
    if (this.institutionUser.children.length > 0) {
      return;
    } else {
      this.loading = true;
      this.userSelectorService.getInstitutionUser(this.institutionUser.id, 'Y')
        .finally(() => this.loading = false)
        .subscribe(
          data => this.institutionUser.children = data,
          error => console.log(error)
        );
    }
  }

  handleSelectUser(user: InstitutionUser) {
    this.userSelectEvent.emit(user);
  }

  handleRemoveUser(user: InstitutionUser) {
    this.removeUserEvent.emit(user);
  }

  get expandable() {
    return this.institutionUser &&
      (this.institutionUser.state === 'closed' || (this.institutionUser.state === 'open' && this.institutionUser.children.length > 0));
  }

  get unexpandable() {
    return this.institutionUser && this.institutionUser.state === 'open' && this.institutionUser.children.length === 0;
  }
}

