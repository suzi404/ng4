import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './components/home/home.component';
import { ResourcesPageComponent } from './components/resources-page/resources-page.component';
import { NoContentComponent } from './components/no-content/no-content.component';
import { FakeLoginComponent } from './components/fake-login/fake-login.component';
import { LoginComponent } from './components/login/login.component';

export const ROUTES: Routes = [
    { path: '', redirectTo: 'home', pathMatch: 'full'},
    { path: 'login', component: LoginComponent },
    { path: 'home', loadChildren: './components/home/home.module#HomeModule' },
    { path: 'fake-login', component: FakeLoginComponent },
    { path: 'resources', loadChildren: './components/resources-page/resources-page.module#ResourcesPageModule' },
    { path: 'projects', loadChildren: './components/projects-page/projects-page.module#ProjectsPageModule' },
    { path: 'questionnaire', loadChildren: './components/questionnaire/questionnaire.module#QuestionnaireModule' },
    { path: 'project-application', loadChildren: './components/project-application/project-application.module#ProjectApplicationModule' },
    { path: 'task-approve', loadChildren: './components/task-approve/task-approve.module#TaskApproveModule' },
    { path: '**', component: NoContentComponent }
];

@NgModule({
    imports: [ RouterModule.forRoot(ROUTES) ],
    exports: [ RouterModule ]
})
export class AppRoutingModule {}
