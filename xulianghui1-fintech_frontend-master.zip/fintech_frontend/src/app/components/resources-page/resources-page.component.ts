import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-resources-page',
  templateUrl: './resources-page.component.html',
  styleUrls: ['./resources-page.component.scss']
})
export class ResourcesPageComponent implements OnInit {
  isFisrtTimeApplyProject: boolean = true;

  constructor(
    private router: Router,
  ) { }

  ngOnInit() {
  }

  goToApplyProjectPage(): void {
    let me = this;
    if (me.isFisrtTimeApplyProject) {
      me.router.navigate(['/questionnaire']);
    } else {
      me.router.navigate(['/project-application']);
    }
  }
}
