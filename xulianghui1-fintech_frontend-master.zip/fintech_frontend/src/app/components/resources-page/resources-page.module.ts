import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ResourcesPageRoutingModule } from './resources-page-routing.module';

import { SharedModule } from '../../shared/shared.module';

import { ResourcesPageComponent } from './resources-page.component';
import { LeanCoursesComponent } from './lean-courses/lean-courses.component';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    ResourcesPageRoutingModule,
  ],
  declarations: [
    ResourcesPageComponent,
    LeanCoursesComponent,
  ]
})
export class ResourcesPageModule { }
