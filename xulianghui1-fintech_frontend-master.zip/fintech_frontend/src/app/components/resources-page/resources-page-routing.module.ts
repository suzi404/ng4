import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ResourcesPageComponent } from './resources-page.component';
import { LeanCoursesComponent } from './lean-courses/lean-courses.component';

export const ROUTES: Routes = [
    { path: '', component: ResourcesPageComponent },
    { path: 'lean-courses', component: LeanCoursesComponent }
];

@NgModule({
    imports: [ RouterModule.forChild(ROUTES) ],
    exports: [ RouterModule ]
})
export class ResourcesPageRoutingModule {}
