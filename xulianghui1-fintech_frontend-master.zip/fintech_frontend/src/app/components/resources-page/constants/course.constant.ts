export const exampleTemplateConstant = [
  {
    'title': '用户画像范例',
    'image': '1.jpg'
  },
  {
    'title': '精益画布模板',
    'image': '2.jpg'
  },
  {
    'title': '精益画布详解 01',
    'image': '3.jpg'
  },
  {
    'title': '精益画布详解 02',
    'image': '4.jpg'
  },
  {
    'title': '精益画布详解 03',
    'image': '5.jpg'
  },
  {
    'title': '精益画布详解 04',
    'image': '6.jpg'
  },
  {
    'title': '草图素材 01',
    'image': '7.jpg'
  },
  {
    'title': '草图素材 02',
    'image': '8.jpg'
  },
  {
    'title': '草图素材 03',
    'image': '9.jpg'
  },
  {
    'title': '草图素材 04',
    'image': '7.jpg'
  },
  {
    'title': '故事板 01',
    'image': '8.jpg'
  },
  {
    'title': '故事板 02',
    'image': '9.jpg'
  },
];

export const leanBooksConstant = [
  {
    'title': '精益企业',
    'author': 'Jez Humble / Jonna Molesky / Barry O\'Reilly',
    'translator': '姚安峰 / 韩锴',
    'link': 'https://book.douban.com/subject/26702829/',
    'image': '1.png',
  },
  {
    'title': '精益创业实战',
    'author': 'Ash Maurya',
    'translator': '张玳',
    'link': 'https://book.douban.com/subject/20505765/',
    'image': '2.png'
  },
  {
    'title': '精益设计',
    'author': 'Jeff Gothelf',
    'translator': '张玳',
    'link': 'https://book.douban.com/subject/24896848/',
    'image': '3.png'
  },
  {
    'title': '体验设计白皮书',
    'author': '张玳',
    'link': 'https://book.douban.com/subject/26857698/',
    'image': '4.png'
  },
];
