import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpModule, ConnectionBackend } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';

import { LeanCoursesComponent } from './lean-courses.component';

import { HttpInterceptorService } from '../../../shared/services/http-interceptor.service';
import { AlertService } from '../../../shared/services/alert.service';
import { CourseService } from '../../../shared/services/course.service';

describe('LeanCoursesComponent', () => {
  let component: LeanCoursesComponent;
  let fixture: ComponentFixture<LeanCoursesComponent>;
  let courseService: CourseService;
  let stubVideoCourseResponse = { 'code': '0', 'message': '成功', 'data': {
    'pageIndex': 0,
    'pageSize': 1,
    'total': 2,
    'data': [
      {
        'curriculumName': 'HTML+CSS基础课程',
        'url': 'http://www.imooc.com/learn/9',
      },
      {
        'curriculumName': 'HTML+CSS基础课程',
        'url': 'http://www.imooc.com/learn/9',
      }
    ]
  }};

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpModule,
      ],
      declarations: [
        LeanCoursesComponent,
      ],
      providers: [
        HttpInterceptorService,
        ConnectionBackend,
        CourseService,
        AlertService,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LeanCoursesComponent);
    component = fixture.componentInstance;

    courseService = fixture.debugElement.injector.get(CourseService);
    spyOn(courseService, 'getCourses').and.returnValue(Observable.of(stubVideoCourseResponse));

    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
