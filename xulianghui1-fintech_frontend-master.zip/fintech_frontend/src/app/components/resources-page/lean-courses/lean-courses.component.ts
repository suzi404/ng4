import { Component, OnInit } from '@angular/core';
import { exampleTemplateConstant, leanBooksConstant } from '../constants/course.constant';
import { CourseService } from '../../../shared/services/course.service';

@Component({
  selector: 'app-lean-courses',
  templateUrl: './lean-courses.component.html',
  styleUrls: ['./lean-courses.component.scss']
})
export class LeanCoursesComponent implements OnInit {
  videoCourses: Array<any>;
  examples: Array<any> = exampleTemplateConstant;
  books: Array<any> = leanBooksConstant;
  showPreview: boolean = false;
  previewImage: string = '';

  constructor(
    private courseService: CourseService,
  ) { }

  ngOnInit() {
    this.getVideoCourses();
  }

  getVideoCourses(): void {
    let me = this;
    let courseType = '1';
    me.courseService.getCourses(courseType)
      .subscribe(
        res => {
          me.videoCourses = res.data.data;
        }
      );
  }

  showPreviewModal(example): void {
    this.previewImage = 'assets/images/resources/templetes/' + example.image;
    this.showPreview = true;
  }

}
