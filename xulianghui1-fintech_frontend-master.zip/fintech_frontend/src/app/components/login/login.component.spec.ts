import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpModule, ConnectionBackend } from '@angular/http';
import { RouterTestingModule } from '@angular/router/testing';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';

import { LoginComponent } from './login.component';
import { HttpInterceptorService } from '../../shared/services/http-interceptor.service';
import { AuthenticationService } from '../../shared/services/authentication.service';
import { AlertService } from '../../shared/services/alert.service';
import { UserService } from '../../shared/services/user.service';
import { urlStateConstant } from '../../shared/constants/url-state.constant';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let userService: UserService;
  let authenticationService: AuthenticationService;
  let stubPermissionsResponse = { 'code': '0', 'message': '成功' };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpModule,
        RouterTestingModule,
      ],
      providers: [
        AuthenticationService,
        ConnectionBackend,
        AlertService,
        UserService,
        HttpInterceptorService,
      ],
      declarations: [ LoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;

    userService = fixture.debugElement.injector.get(UserService);
    authenticationService = fixture.debugElement.injector.get(AuthenticationService);
    spyOn(userService, 'getPermissions').and.returnValue(Observable.of(stubPermissionsResponse));
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should login failure when Token is empty', () => {
    spyOn(authenticationService, 'isUserAuthenticated').and.returnValue(false);
    let stubParams = {
      'Data': '123',
      'Token': '',
    };
    component.urlState = 'department-leader';
    component.checkLoginState(stubParams);
    fixture.detectChanges();
    console.log('===', authenticationService.isUserAuthenticated());
    expect(component.loginMessage).toContain('您的Data或Token信息为空或过期，请您通过一事通登录。');
  });

  it('should login failure when Data is empty', () => {
    spyOn(authenticationService, 'isUserAuthenticated').and.returnValue(false);
    let stubParams = {
      'Data': '',
      'Token': 'abc',
    };
    component.checkLoginState(stubParams);
    fixture.detectChanges();
    expect(component.loginMessage).toContain('您的Data或Token信息为空或过期，请您通过一事通登录。');
  });

  it('should Data and Token be valid', () => {
    let stubParams = {
      'Data': 123,
      'Token': 'abc',
    };
    expect(component.isLoginParamsValid(stubParams['Data'], stubParams['Token'])).toBeTruthy();
    expect(component.isLoginParamsValid('', stubParams['Token'])).toBeFalsy();
    expect(component.isLoginParamsValid(stubParams['Data'], '')).toBeFalsy();
  });
});
