import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { AuthenticationService } from '../../shared/services/authentication.service';
import { codeConstant } from '../../shared/constants/code.constant';
import { urlStateConstant } from '../../shared/constants/url-state.constant';
import { AlertService } from '../../shared/services/alert.service';
import { UserService } from '../../shared/services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginMessage: string = '登录中，请稍后...';
  urlState: string;
  stateParams: string;

  constructor(
    private router: Router,
    private alertService: AlertService,
    private userService: UserService,
    private authenticationService: AuthenticationService,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.login();
  }

  login(): void {
    let me = this;
    me.route.queryParams
      .subscribe(params => me.checkLoginState(params));
  }

  checkLoginState(params): void {
    let me = this;
    if (me.isLogined(params)) {
      me.navigateToState();
      return;
    }

    let data, token;
    data = encodeURIComponent(params['Data']);
    token = encodeURIComponent(params['Token']);
    if (me.isLoginParamsValid(data, token)) {
      me.authenticate(data, token);
    } else {
      me.loginMessage = '您的Data或Token信息为空或过期，请您通过一事通登录。';
    }
  }

  isLogined(params): boolean {
    let me = this;
    me.urlState = params['State'];
    me.stateParams = params['Params'];

    if (me.authenticationService.isUserAuthenticated()) {
      return true;
    }
    return false;
  }

  authenticate(data, token): void {
    let me = this;
    me.authenticationService.authenticate(data, token)
      .then(res => {
        if (res.code === codeConstant.SUCCESS && res.data) {
          me.alertService.success('登录成功！');
          me.authenticationService.setUserLoginData(res.data);
          me.userService.getUserPermissons();
          me.navigateToState();
        } else {
          me.alertService.error('登录失败，请重试');
        }
      })
      .catch(error => {
        me.alertService.error('登录失败，请重试');
      });
  }

  navigateToState(): void {
    let me = this;
    if (me.urlState) {
      let params = me.stateParams ? `?${me.stateParams}` : '';
      me.router.navigateByUrl(urlStateConstant[me.urlState] + params);
    } else {
      me.router.navigate(['/']);
    }
  }

  isLoginParamsValid(data, token): boolean {
    if (!data || !token) {
      return false;
    }
    return true;
  }
}
