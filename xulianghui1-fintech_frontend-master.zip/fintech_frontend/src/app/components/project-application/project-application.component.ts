import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { ProjectApplicationService } from './project-application.service';
import { QuestionnaireService } from '../questionnaire/questionnaire.service';

import { ProjectsService } from '../../shared/services/projects.service';
import { codeConstant } from '../../shared/constants/code.constant';

@Component({
  selector: 'app-project-application',
  templateUrl: './project-application.component.html',
  styleUrls: ['./project-application.component.scss']
})
export class ProjectApplicationComponent implements OnInit {
  constructor(
    private projectApplicationService: ProjectApplicationService,
    private questionnaireService: QuestionnaireService,
    private router: Router,
    private route: ActivatedRoute,
    private projectsService: ProjectsService
  ) {}
  applyId: any;
  isStarted = false;
  isEnded = false;
  currIndex = 0;
  progress = 0;
  stepKeys = [
    'basicInfo',
    'ownerInfo',
    'targetUser',
    'marketInfo',
    'productAnalysis',
    'projectValue',
    'informSupervisor'
  ];

  ngOnInit() {
    this.questionnaireService.checkIfAlreadyAnswerd().subscribe(res => {
      // redirect to questionnaire page if not answered yet.
      if (res.data !== true) {
        this.router.navigate(['/questionnaire']);
      }
    });
    // edit the project
    this.route.params.subscribe(params => {
      this.applyId = (params[ 'applyId' ] || '').toString();
      if (this.applyId) {
        this.getProjectByApplyId(this.applyId);
      } else{
        this.projectApplicationService.initAppliedProjectInfo();
        this.projectApplicationService.model.projectInfo.applyId = '';
      }                
    });    
    this.updateCurrentProgress();           
  }

  getProjectByApplyId(applyId) {
    this.projectsService.getProjectDetail(this.applyId)
      .subscribe(
        res => {
          if (res.code === codeConstant.SUCCESS && res.data) {
            this.projectApplicationService.model = res.data;  
            this.projectApplicationService.initAppliedProjectInfo();
            console.log(res.data);               
          }
        },
        error => console.debug('get project detail failure', error)
      );

  }

  start() {
    this.isStarted = true;
  }

  updateCurrentProgress() {
    this.progress = (this.currIndex + 1) / this.stepKeys.length * 100;
    this.isEnded = this.currIndex + 1 === this.stepKeys.length;
  }

  toPreviousStep() {
    this.currIndex--;
    this.updateCurrentProgress();
  }

  toNextStep() {
    if (this.currIndex < this.stepKeys.length) {
      this.currIndex++;
    }
    this.updateCurrentProgress();
  }
}
