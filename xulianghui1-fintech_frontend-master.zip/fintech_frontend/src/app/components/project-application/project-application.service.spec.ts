import { TestBed, inject } from '@angular/core/testing';
import { HttpModule, ConnectionBackend } from '@angular/http';

import { ProjectApplicationService } from './project-application.service';
import { HttpInterceptorService } from '../../shared/services/http-interceptor.service';
import { AlertService } from 'app/shared/services/alert.service';

describe('ProjectApplicationService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpModule],
      providers: [
        ProjectApplicationService,
        HttpInterceptorService,
        ConnectionBackend,
        AlertService
      ]
    });
  });

  it(
    'should be created',
    inject(
      [ProjectApplicationService],
      (service: ProjectApplicationService) => {
        expect(service).toBeTruthy();
      }
    )
  );
});
