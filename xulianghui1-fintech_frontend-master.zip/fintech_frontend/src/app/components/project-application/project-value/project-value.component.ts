import { Component, OnInit } from '@angular/core';
import { BasePartComponent } from '../base-part.component';
import { ProjectApplicationService } from '../project-application.service';

class ProjectValue {
  uniqueValue: string;
}

@Component({
  selector: 'app-project-value',
  templateUrl: './project-value.component.html',
  styleUrls: ['./project-value.component.scss']
})
export class ProjectValueComponent extends BasePartComponent implements OnInit {
  model: ProjectValue;
  constructor(private projectApplicationService: ProjectApplicationService) {
    super();
  }

  ngOnInit() {
    this.model = this.projectApplicationService.getProjectValue();
  }

  nextStepCore() {
    this.projectApplicationService.saveProjectValue(this.model);
  }
}
