import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { HttpModule, ConnectionBackend } from '@angular/http';

import { ProjectValueComponent } from './project-value.component';
import { HttpInterceptorService } from '../../../shared/services/http-interceptor.service';
import { ProjectApplicationService } from '../project-application.service';

describe('ProjectValueComponent', () => {
  let component: ProjectValueComponent;
  let fixture: ComponentFixture<ProjectValueComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ FormsModule, HttpModule ],
      declarations: [ ProjectValueComponent ],
      providers: [
        HttpInterceptorService,
        ConnectionBackend,
        ProjectApplicationService
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectValueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it('should be created', () => {
  //   expect(component).toBeTruthy();
  // });
});
