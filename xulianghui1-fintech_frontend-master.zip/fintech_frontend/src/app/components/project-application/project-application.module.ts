import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {JsonpModule, Jsonp, Response} from '@angular/http';
import { RouterModule } from '@angular/router';

import { ProjectApplicationRoutingModule } from './project-application-routing.module';
import { SharedModule } from '../../shared/shared.module';
import { UserSelectorService } from '../../shared/services/user-selector.service';
import { ProjectApplicationService } from './project-application.service';

import { ProjectApplicationComponent } from './project-application.component';

import { BasicInfoComponent } from './basic-info/basic-info.component';
import { OwnerInfoComponent } from './owner-info/owner-info.component';
import { TargetUserComponent } from './target-user/target-user.component';
import { MarketInfoComponent } from './market-info/market-info.component';
import { ProductAnalysisComponent } from './product-analysis/product-analysis.component';
import { ProjectValueComponent } from './project-value/project-value.component';
import { InformSupervisorComponent } from './inform-supervisor/inform-supervisor.component';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    ProjectApplicationRoutingModule,
    FormsModule,
    JsonpModule,
    RouterModule
  ],
  declarations: [
    ProjectApplicationComponent,
    BasicInfoComponent,
    OwnerInfoComponent,
    TargetUserComponent,
    MarketInfoComponent,
    ProductAnalysisComponent,
    ProjectValueComponent,
    InformSupervisorComponent
  ],
  providers: [
    UserSelectorService,
    ProjectApplicationService
  ]
})
export class ProjectApplicationModule { }
