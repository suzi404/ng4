import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { ProjectApplicationComponent } from './project-application.component';

@NgModule({
  imports: [
    RouterModule.forChild([
      { path: '', component: ProjectApplicationComponent },
      { path: ':applyId', component: ProjectApplicationComponent }
    ])
  ],

  exports: [RouterModule]
})
export class ProjectApplicationRoutingModule {}
