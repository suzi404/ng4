import { Injectable } from '@angular/core';
import { HttpInterceptorService } from '../../shared/services/http-interceptor.service';
import { apiConstant } from '../../shared/constants/api.constant';

@Injectable()
export class ProjectApplicationService {
  model: any = { projectResearch: {} };  
  depLeaderId = '';
  constructor(private http: HttpInterceptorService) {
    // add this for fixing error in unit test;
    this.model.projectResearch = this.model.projectResearch || {};
    this.model.projectInfo = this.model.projectInfo || {};
    this.model.projectLabels = this.model.projectLabels || [];
  }

  initAppliedProjectInfo() {
    // to request server to get saved data later.
    // 与后端-姚亚沟通后，需要额外提交的字段如下：
    this.model.projectInfo.projectStatus = 1;
    this.model.projectInfo.projectAction = 1;
    this.model.projectInfo.mark = 0; 

    // 其余的非必填字段还有：projectId, demandId，costCenterCode，costCenterName
  }

  getYstUserInfo() {
    return this.http.get(apiConstant.userInfo).map(res => res.json());
  }

  getLabels() {
    return this.http.get(apiConstant.labels).map(res => res.json());
  }

  submitToServer() {
    this.model.projectInfo.applyTime = Date.now();

    // only post active labels to server for now, maybe changed later.
    this.model.projectLabels = this.model.projectLabels.filter(x => x.active);
    console.log(this.model);
    
     return this.http
    .post(
      `${apiConstant.fintechWorkflow}/start?depLeaderId=${this.depLeaderId}`,
      this.model
    )
    .map(response => response.json());
        
  }

  saveBasicInfo(obj) {
    this.model.projectInfo.projectName = obj.projectName;
    this.model.projectInfo.projectIntro = obj.projectIntro;
    this.model.projectLabels = obj.primaryLabelList.concat(
      obj.secondaryLabelList
    );
  }

  getBasicInfo(): any {
    return {
      projectName: this.model.projectInfo.projectName,
      projectIntro: this.model.projectInfo.projectIntro,
      projectLabels: this.model.projectLabels,
      applyId:this.model.projectInfo.applyId
    };
  }

  saveOwnerInfo(obj) {
    Object.assign(this.model.projectInfo, obj);
  }

  getOwnerInfo(): any {
    return Object.assign({}, this.model.projectInfo);
  }

  saveTargetUser(obj) {
    Object.assign(this.model.projectResearch, obj);
  }

  getTargetUser(): any {
    return {
      userGroup: this.model.projectResearch.userGroup,
      userBehaviour: this.model.projectResearch.userBehaviour,
      userPainPoint: this.model.projectResearch.userPainPoint
    };
  }

  saveMarketInfo(obj) {
    Object.assign(this.model.projectResearch, obj);
  }

  getMarketInfo(): any {
    return {
      marketEnv: this.model.projectResearch.marketEnv,
      marketSize: this.model.projectResearch.marketSize,
      industryStatus: this.model.projectResearch.industryStatus
    };
  }

  saveProductAnalysis(arr) {
    this.model.productAnalysisList = arr;
  }

  getProductAnalysis(): any {
    return this.model.productAnalysisList;
  }

  saveProjectValue(obj) {
    Object.assign(this.model.projectResearch, obj);
  }

  getProjectValue(): any {
    return {
      uniqueValue: this.model.projectResearch.uniqueValue
    };
  }

  saveInformSupervisor(leadId) {
    this.depLeaderId = leadId;
  }

  //获取上级管理者
  getLeaderName(): any {
    return this.model.projectInfo.leaderYstName;
  }
}
