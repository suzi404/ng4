import { Component, OnInit, Output, Input } from '@angular/core';
import { BasePartComponent } from '../base-part.component';
import { ProjectApplicationService } from '../project-application.service';
import { AlertService } from '../../..//shared/services/alert.service';
import { uniqWith } from 'lodash';

class BasicInfo {
  projectName: string;
  projectIntro: string;
  applyId: string;
  primaryLabelList: any[];
  secondaryLabelList: any[];
  projectLabels: any[];  
}

@Component({
  selector: 'app-basic-info',
  templateUrl: './basic-info.component.html',
  styleUrls: ['./basic-info.component.scss']
})
export class BasicInfoComponent extends BasePartComponent implements OnInit {
  @Input() model: BasicInfo;
  addingPrimaryLabelList = false;
  addingSecondaryLabelList = false; 
  applyId: string;
  listArr: any;

  constructor(
    private projectApplicationService: ProjectApplicationService,
    private alertService: AlertService
  ) {
    super();
  }

  ngOnInit() {         
    this.model = this.projectApplicationService.getBasicInfo();            
    this.projectApplicationService.getLabels().subscribe(
      res => {
        let list;
        this.listArr = res.data; 
        list = this.model.projectLabels;
        //在第一次进页面的时候需要给labels加点亮状态
        if(this.model.projectLabels.length < this.listArr.length){
          for(let i in list){
            list[i].active = true;
          }
        }        
        list = this.model.projectLabels.concat(this.listArr);        
        list = uniqWith(list,(x,y) => x.labelName == y.labelName);               
        this.model.primaryLabelList = list.filter(
          x => x.labelType === 1
        );
        this.model.secondaryLabelList = list.filter(
          x => x.labelType === 2
        ); 
      },
      err => {
        this.alertService.error('网络异常，获取业务领域标签失败');
        console.log('err:', err);
      }
    );  
  }
 
  toggleAddingStatusInPrimaryList() {
    this.addingPrimaryLabelList = !this.addingPrimaryLabelList;
  }

  togglePrimaryLabelStatus(index) {
    this.model.primaryLabelList[index].active = !this.model.primaryLabelList[
      index
    ].active;
    // set other labels active as false , because only one active label is allowed in PrimaryLabelList.
    this.model.primaryLabelList.forEach((item, i) => {
      if (i !== index) {
        item.active = false;
      }
    });
  }

  addPrimaryLabel(name) {
    if (name.trim() === '') {
      this.toggleAddingStatusInPrimaryList();
      return;
    }

    let newLabel = { labelType: 1, labelName: name };
    this.model.primaryLabelList.push(newLabel);

    // active the tag right away after added.
    this.togglePrimaryLabelStatus(this.model.primaryLabelList.length - 1);

    this.toggleAddingStatusInPrimaryList();
  }

  toggleAddingStatusInSecondaryList() {
    this.addingSecondaryLabelList = !this.addingSecondaryLabelList;
  }

  toggleSecondaryLabelStatus(index) {
    let currState = this.model.secondaryLabelList[index].active;
    console.log('currState:', currState);
    if (!currState) {
      let activedCount = this.model.secondaryLabelList.filter(x => x.active)
        .length;

      // only at most 5 secondary labels can be active.
      if (activedCount >= 5) {
        return;
      }
    }

    this.model.secondaryLabelList[index].active = !this.model
      .secondaryLabelList[index].active;
  }

  addSecondaryLabel(name) {
    if (name.trim() === '') {
      this.toggleAddingStatusInSecondaryList();
      return;
    }

    let newLabel = { labelType: 2, labelName: name};
    this.model.secondaryLabelList.push(newLabel);

    // active the tag right away after added.
    this.toggleSecondaryLabelStatus(this.model.secondaryLabelList.length - 1);
    this.toggleAddingStatusInSecondaryList();
  }

  get isPrimaryLabelSelected() {
    return (
      this.model.primaryLabelList &&
      this.model.primaryLabelList.some(x => x.active)
    );
  }

  nextStepCore() {
    this.model.projectLabels = this.model.primaryLabelList.concat(
      this.model.secondaryLabelList
    );
    this.projectApplicationService.saveBasicInfo(this.model);
    console.log(this.projectApplicationService.model);
  }
}
