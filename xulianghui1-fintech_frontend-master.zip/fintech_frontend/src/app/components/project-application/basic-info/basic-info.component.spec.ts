import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { HttpModule, ConnectionBackend, Http } from '@angular/http';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Rx';

import { BasicInfoComponent } from './basic-info.component';
import { ProjectApplicationService } from '../project-application.service';
import { ProjectApplicationModule } from '../project-application.module';
import { HttpInterceptorService } from '../../../shared/services/http-interceptor.service';
import { AlertService } from '../../..//shared/services/alert.service';

describe('BasicInfoComponent', () => {
  let component: BasicInfoComponent;
  let fixture: ComponentFixture<BasicInfoComponent>;
  let projectApplicationService: ProjectApplicationService;

  const mockedData = {
    data: [
      { labelId: 1, labelName: 'l1', labelType: 1 },
      { labelId: 2, labelName: 'l2', labelType: 2 }
    ]
  };

  beforeEach(
    async(() => {
      TestBed.configureTestingModule({
        imports: [FormsModule, HttpModule],
        declarations: [BasicInfoComponent],
        providers: [
          ProjectApplicationService,
          HttpInterceptorService,
          ConnectionBackend,
          AlertService
        ]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(BasicInfoComponent);
    component = fixture.componentInstance;
    projectApplicationService = fixture.debugElement.injector.get(
      ProjectApplicationService
    );
    spyOn(projectApplicationService, 'getLabels').and.returnValue(
      Observable.of(mockedData)
    );
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
