import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { HttpModule, ConnectionBackend } from '@angular/http';

import { MarketInfoComponent } from './market-info.component';
import { ProjectApplicationService } from '../project-application.service';
import { HttpInterceptorService } from '../../../shared/services/http-interceptor.service';
import { AlertService } from 'app/shared/services/alert.service';

describe('MarketInfoComponent', () => {
  let component: MarketInfoComponent;
  let fixture: ComponentFixture<MarketInfoComponent>;

  beforeEach(
    async(() => {
      TestBed.configureTestingModule({
        imports: [FormsModule, HttpModule],
        declarations: [MarketInfoComponent],
        providers: [
          ProjectApplicationService,
          HttpInterceptorService,
          ConnectionBackend,
          AlertService
        ]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(MarketInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
