import { Component, OnInit } from '@angular/core';
import { BasePartComponent } from '../base-part.component';
import { ProjectApplicationService } from '../project-application.service';

class MarketInfo {
  marketEnv: string;
  marketSize: string;
  industryStatus: string;
}

@Component({
  selector: 'app-market-info',
  templateUrl: './market-info.component.html',
  styleUrls: ['./market-info.component.scss']
})
export class MarketInfoComponent extends BasePartComponent implements OnInit {
  model: MarketInfo;
  constructor(private projectApplicationService: ProjectApplicationService) {
    super();
  }

  ngOnInit() {
    this.model = this.projectApplicationService.getMarketInfo();
  }

  nextStepCore() {
    this.projectApplicationService.saveMarketInfo(this.model);
  }
}
