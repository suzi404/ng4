import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { HttpModule, ConnectionBackend } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { RouterTestingModule } from '@angular/router/testing';

import { SharedModule } from '../../shared/shared.module';

import { ProjectApplicationComponent } from './project-application.component';

import { BasicInfoComponent } from './basic-info/basic-info.component';
import { OwnerInfoComponent } from './owner-info/owner-info.component';
import { TargetUserComponent } from './target-user/target-user.component';
import { MarketInfoComponent } from './market-info/market-info.component';
import { ProductAnalysisComponent } from './product-analysis/product-analysis.component';
import { ProjectValueComponent } from './project-value/project-value.component';
import { InformSupervisorComponent } from './inform-supervisor/inform-supervisor.component';
import { ProjectApplicationService } from './project-application.service';

import { HttpInterceptorService } from '../../shared/services/http-interceptor.service';
import { AlertService } from 'app/shared/services/alert.service';
import { QuestionnaireService } from '../questionnaire/questionnaire.service';
import {ProjectsService} from '../../shared/services/projects.service';

describe('ProjectApplicationComponent', () => {
  let component: ProjectApplicationComponent;
  let fixture: ComponentFixture<ProjectApplicationComponent>;
  let questionnaireService: QuestionnaireService;
  beforeEach(
    async(() => {
      TestBed.configureTestingModule({
        imports: [FormsModule, HttpModule, SharedModule, RouterTestingModule],
        declarations: [
          ProjectApplicationComponent,
          BasicInfoComponent,
          OwnerInfoComponent,
          TargetUserComponent,
          MarketInfoComponent,
          ProductAnalysisComponent,
          ProjectValueComponent,
          InformSupervisorComponent
        ],
        providers: [
          ProjectApplicationService,
          HttpInterceptorService,
          ConnectionBackend,
          AlertService,
          QuestionnaireService,
          ProjectsService,
        ]
      }).compileComponents();
    })
  );

  const mockedData = {};

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectApplicationComponent);
    component = fixture.componentInstance;
    questionnaireService = fixture.debugElement.injector.get(
      QuestionnaireService
    );
    spyOn(questionnaireService, 'checkIfAlreadyAnswerd').and.returnValue(
      Observable.of(mockedData)
    );
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
