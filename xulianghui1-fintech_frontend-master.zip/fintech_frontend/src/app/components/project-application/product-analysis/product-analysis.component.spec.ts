import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { HttpModule, ConnectionBackend } from '@angular/http';

import { ProductAnalysisComponent } from './product-analysis.component';
import { HttpInterceptorService } from '../../../shared/services/http-interceptor.service';
import { ProjectApplicationService } from '../project-application.service';
import { AlertService } from 'app/shared/services/alert.service';

describe('ProductAnalysisComponent', () => {
  let component: ProductAnalysisComponent;
  let fixture: ComponentFixture<ProductAnalysisComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ FormsModule, HttpModule ],
      declarations: [ ProductAnalysisComponent ],
      providers: [
        HttpInterceptorService,
        ConnectionBackend,
        ProjectApplicationService,
        AlertService
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductAnalysisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
