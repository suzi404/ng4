import { Component, OnInit } from '@angular/core';
import { BasePartComponent } from '../base-part.component';
import { ProjectApplicationService } from '../project-application.service';
import { isEmpty } from 'lodash';

export class ProductAnalysis {
  serialNumber: number;
  productName: string;
  productOrientation: string;
  targetUser: string;
  uniqueValue: string;
  productDisadvantage: string;
  dataCase: string;
}

@Component({
  selector: 'app-product-analysis',
  templateUrl: './product-analysis.component.html',
  styleUrls: ['./product-analysis.component.scss']
})
export class ProductAnalysisComponent extends BasePartComponent
  implements OnInit {
  model: ProductAnalysis[] = [];

  constructor(private projectApplicationService: ProjectApplicationService) {
    super();
  }

  ngOnInit() {
    this.model = this.projectApplicationService.getProductAnalysis() || [
      new ProductAnalysis()
    ];
  }

  addProduct() {
    this.model.push(new ProductAnalysis());
  }

  deleteProduct(pindex) {
    this.model.splice(pindex, 1);
  }

  nextStepCore() {
    this.model = this.model.map((item, index) => {
      return { ...item, serialNumber: index + 1 };
    });
    this.projectApplicationService.saveProductAnalysis(this.model);
  }

  // it has to use custom validation below, just because default form validation does not work with [ngModelOptions]="{standalone: true}"
  get isValid() {
    return this.model.every(
      x =>
        !isEmpty(x.productName) &&
        !isEmpty(x.productOrientation) &&
        !isEmpty(x.targetUser) &&
        !isEmpty(x.uniqueValue) &&
        !isEmpty(x.productDisadvantage)
    );
  }
}
