import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { HttpModule, ConnectionBackend } from '@angular/http';

import { TargetUserComponent } from './target-user.component';
import { HttpInterceptorService } from '../../../shared/services/http-interceptor.service';
import { ProjectApplicationService } from '../project-application.service';

describe('TargetUserComponent', () => {
  let component: TargetUserComponent;
  let fixture: ComponentFixture<TargetUserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ FormsModule, HttpModule],
      declarations: [ TargetUserComponent ],
      providers: [
        HttpInterceptorService,
        ConnectionBackend,
        ProjectApplicationService
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TargetUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it('should be created', () => {
  //   expect(component).toBeTruthy();
  // });
});
