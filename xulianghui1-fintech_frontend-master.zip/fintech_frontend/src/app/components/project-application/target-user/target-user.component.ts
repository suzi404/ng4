import { Component, OnInit } from '@angular/core';
import { BasePartComponent } from '../base-part.component';
import { ProjectApplicationService } from '../project-application.service';

class TargetUser {
  userGroup: string;
  userBehaviour: string;
  userPainPoint: string;
}

@Component({
  selector: 'app-target-user',
  templateUrl: './target-user.component.html',
  styleUrls: ['./target-user.component.scss']
})
export class TargetUserComponent extends BasePartComponent implements OnInit {
  model: TargetUser;
  constructor(private projectApplicationService: ProjectApplicationService) {
    super();
  }

  ngOnInit() {
    this.model = this.projectApplicationService.getTargetUser();
  }

  nextStepCore() {
    this.projectApplicationService.saveTargetUser(this.model);
  }
}
