import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpModule, ConnectionBackend } from '@angular/http';
import { Jsonp } from '@angular/http';
import { FormsModule } from '@angular/forms';
import { Observable } from 'rxjs/Rx';

import { SharedModule } from '../../../shared/shared.module';
import { InformSupervisorComponent } from './inform-supervisor.component';
import { AlertService } from '../../../shared/services/alert.service';
import { ProjectApplicationService } from '../project-application.service';
import { HttpInterceptorService } from '../../../shared/services/http-interceptor.service';
import { UserSelectorService } from '../../../shared/services/user-selector.service';

const topRemoteResponse = [
  {
    'id': '100001',
    'text': '招商银行/100001',
    'state': 'open',
    'attributes': 'CANSELECT=Y',
    'iconCls': null,
    'children': [
      {
        'id': '100003',
        'text': '总行/100003',
        'state': 'closed',
        'attributes': 'TEXT=总行/100003:ORGID=100003:GPID=0100000000:NAME=总行:GPNM=总行:PATH=总行:EMAIL=@cmbchina.com',
        'iconCls': 'tree-folder',
        'children': []
      },
      {
        'id': '100314',
        'text': '北京分行/100314',
        'state': 'closed',
        'attributes': 'TEXT=北京分行/100314:ORGID=100314:GPID=0201000000:NAME=北京分行:GPNM=北京分行:PATH=北京分行:EMAIL=@cmbchina.com',
        'iconCls': 'tree-folder',
        'children': []
      }
    ]
  }
];

describe('InformSupervisorComponent', () => {
  let component: InformSupervisorComponent;
  let fixture: ComponentFixture<InformSupervisorComponent>;
  let userSelectorService: UserSelectorService;

  beforeEach(
    async(() => {
      TestBed.configureTestingModule({
        imports: [HttpModule, SharedModule, FormsModule],
        providers: [
          AlertService,
          Jsonp,
          ConnectionBackend,
          ProjectApplicationService,
          HttpInterceptorService,
          UserSelectorService
        ],
        declarations: [InformSupervisorComponent]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(InformSupervisorComponent);
    component = fixture.componentInstance;
    // TODO: why I had to spyOn service which called in sub component
    userSelectorService = fixture.debugElement.injector.get(UserSelectorService);
    spyOn(userSelectorService, 'getInstitutionUser').and.returnValue(Observable.of(topRemoteResponse));
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
