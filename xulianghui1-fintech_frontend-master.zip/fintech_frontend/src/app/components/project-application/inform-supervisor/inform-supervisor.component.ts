import { Component, OnInit } from '@angular/core';
import { BasePartComponent } from '../base-part.component';
import { ProjectApplicationService } from '../project-application.service';
import { AlertService } from '../../../shared/services/alert.service';

@Component({
  selector: 'app-inform-supervisor',
  templateUrl: './inform-supervisor.component.html',
  styleUrls: ['./inform-supervisor.component.scss']
})
export class InformSupervisorComponent extends BasePartComponent
  implements OnInit {
    leaderYstName: string;
    applyId: string;
  constructor(
    private projectApplicationService: ProjectApplicationService,
    private alertService: AlertService
  ) {
    super();
  }

  ngOnInit() {
    this.leaderYstName = this.projectApplicationService.getLeaderName();
    this.applyId = this.projectApplicationService.getBasicInfo().applyId;
  }

  nextStepCore(): void {
    // placeholder here.
  }

  handleNext($event) {
    // get leaderid from data structure of app-user-selector component
    if(!this.applyId){
      let leadId = $event[0].id;
      this.projectApplicationService.saveInformSupervisor(leadId);
    }    
    this.projectApplicationService.submitToServer().subscribe(res => {
      this.alertService.success('申请信息提交成功');
      let appliedId = res.data;
      window.location.href = `/projects/applied/status/${appliedId}`;
    });
  }
}
