import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { HttpModule, ConnectionBackend } from '@angular/http';
import { Observable } from 'rxjs/Rx';

import { OwnerInfoComponent } from './owner-info.component';
import { HttpInterceptorService } from '../../../shared/services/http-interceptor.service';
import { ProjectApplicationService } from '../project-application.service';
import { AlertService } from '../../..//shared/services/alert.service';

describe('OwnerInfoComponent', () => {
  let component: OwnerInfoComponent;
  let fixture: ComponentFixture<OwnerInfoComponent>;
  let projectApplicationService: ProjectApplicationService;

  const mockedData = {
    data: {
      orgInfo: {}
    }
  };

  beforeEach(
    async(() => {
      TestBed.configureTestingModule({
        imports: [FormsModule, HttpModule],
        declarations: [OwnerInfoComponent],
        providers: [
          HttpInterceptorService,
          ConnectionBackend,
          ProjectApplicationService,
          AlertService
        ]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(OwnerInfoComponent);
    component = fixture.componentInstance;
    projectApplicationService = fixture.debugElement.injector.get(
      ProjectApplicationService
    );
    spyOn(projectApplicationService, 'getYstUserInfo').and.returnValue(
      Observable.of(mockedData)
    );
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
