import { Component, OnInit } from '@angular/core';
import { BasePartComponent } from '../base-part.component';
import { ProjectApplicationService } from '../project-application.service';
import { AlertService } from '../../..//shared/services/alert.service';

class OwnerInfo {
  constructor(
    public ystId = 0,
    public ystName = '',
    public ystOrgName = '',
    public ystJob = '',
    public ystOrgId = '',
    public projectMember = ''
  ) {}
}

@Component({
  selector: 'app-owner-info',
  templateUrl: './owner-info.component.html',
  styleUrls: ['./owner-info.component.scss']
})
export class OwnerInfoComponent extends BasePartComponent implements OnInit {
  model: OwnerInfo;
  constructor(
    private projectApplicationService: ProjectApplicationService,
    private alertService: AlertService
  ) {
    super();
  }

  ngOnInit() {
    this.model = this.projectApplicationService.getOwnerInfo();
    this.projectApplicationService.getYstUserInfo().subscribe(
      res => {
        this.model.ystName = res.data.userName;
        this.model.ystId = res.data.userId;
        this.model.ystOrgName = res.data.orgInfo.groupName;
        this.model.ystJob = res.data.position;
        this.model.ystOrgId = res.data.orgId;
      },
      err => {
        this.alertService.error('网络异常，获取当前申请人信息失败');
      }
    );
  }

  nextStepCore() {
    this.projectApplicationService.saveOwnerInfo(this.model);
  }
}
