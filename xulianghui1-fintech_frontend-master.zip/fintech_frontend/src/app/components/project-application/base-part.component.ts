import { Component, OnInit, EventEmitter, Output } from '@angular/core';

export abstract class BasePartComponent {
  @Output() afterNextClick = new EventEmitter<any>();

  @Output() afterPreviousClick = new EventEmitter<any>();

  public nextStep(): void {
    console.log('-------- submit');
    this.nextStepCore();
    this.afterNextClick.emit();
  }

  abstract nextStepCore(): void;

  public previousStep(): void {
    this.afterPreviousClick.emit();
  }
}
