import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../shared/services/authentication.service';
import { codeConstant } from '../../shared/constants/code.constant';
import { AlertService } from '../../shared/services/alert.service';
import { UserService } from '../../shared/services/user.service';

@Component({
  selector: 'app-fake-login',
  templateUrl: './fake-login.component.html',
  styleUrls: ['./fake-login.component.scss']
})
export class FakeLoginComponent implements OnInit {
  ystAccount: string;
  submitted: boolean = false;
  submitting: boolean = false;

  constructor(
    private router: Router,
    private userService: UserService,
    private authenticationService: AuthenticationService,
    private alertService: AlertService
  ) {}

  ngOnInit() {}

  onSubmit(): void {
    let me = this;
    me.submitted = true;
    me.submitting = true;

    me.authenticationService
      .fakeLogin(me.ystAccount)
      .then(res => {
        console.debug('fake login success', res);
        me.submitting = false;

        if (res.code === codeConstant.SUCCESS && res.data) {
          me.alertService.success('登录成功！');
          me.authenticationService.setUserLoginData(res.data);
          me.userService.getUserPermissons();
          me.router.navigate(['/']);
        } else {
          me.alertService.error('登录失败，请重试');
        }
      })
      .catch(error => {
        console.debug('fake login failure', error);
        me.submitting = false;
        me.alertService.error('登录失败，请重试');
      });
  }
}
