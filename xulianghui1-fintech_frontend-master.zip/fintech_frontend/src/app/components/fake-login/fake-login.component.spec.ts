import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpModule, ConnectionBackend } from '@angular/http';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import { RouterTestingModule } from '@angular/router/testing';

import { FakeLoginComponent } from './fake-login.component';
import { HttpInterceptorService } from '../../shared/services/http-interceptor.service';
import { AuthenticationService } from '../../shared/services/authentication.service';
import { AlertService } from '../../shared/services/alert.service';
import { UserService } from '../../shared/services/user.service';

describe('FakeLoginComponent', () => {
  let component: FakeLoginComponent;
  let fixture: ComponentFixture<FakeLoginComponent>;
  let userService: UserService;
  let stubPermissionsResponse = { 'code': '0', 'message': '成功' };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpModule,
        FormsModule,
        RouterTestingModule
      ],
      providers: [
        AuthenticationService,
        ConnectionBackend,
        AlertService,
        UserService,
        HttpInterceptorService,
      ],
      declarations: [ FakeLoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FakeLoginComponent);
    component = fixture.componentInstance;
    userService = fixture.debugElement.injector.get(UserService);
    spyOn(userService, 'getPermissions').and.returnValue(Observable.of(stubPermissionsResponse));

    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
