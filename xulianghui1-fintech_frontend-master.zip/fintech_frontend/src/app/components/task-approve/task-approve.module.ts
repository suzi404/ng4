import { FormsModule } from '@angular/forms';
import { LeaderDisagreeComponent } from './department-leader/leader-disagree/leader-disagree.component';
import { TaskApproveService } from './../../shared/services/task-approve.service';
import { SharedModule } from './../../shared/shared.module';
import { ProjectsService } from './../../shared/services/projects.service';
import { ProjectsPageModule } from './../projects-page/projects-page.module';
import { TaskApproveRoutingModule } from './task-approve-routing.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DepartmentLeaderComponent } from './department-leader/department-leader.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  imports: [
    CommonModule,
    TaskApproveRoutingModule,
    ProjectsPageModule,
    SharedModule,
    FormsModule,
    NgbModule.forRoot(),
  ],
  declarations: [
    DepartmentLeaderComponent,
    LeaderDisagreeComponent
  ],
  entryComponents: [
    LeaderDisagreeComponent
  ],
  providers: [
    ProjectsService,
    TaskApproveService
  ]
})
export class TaskApproveModule { }
