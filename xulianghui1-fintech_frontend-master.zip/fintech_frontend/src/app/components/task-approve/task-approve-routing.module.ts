import { DepartmentLeaderComponent } from './department-leader/department-leader.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

export const ROUTES: Routes = [
    { path: 'department-leader', component: DepartmentLeaderComponent }
];

@NgModule({
    imports: [ RouterModule.forChild(ROUTES) ],
    exports: [ RouterModule ]
})
export class TaskApproveRoutingModule {}
