import { codeConstant } from './../../../../shared/constants/code.constant';
import { TaskApproveService } from './../../../../shared/services/task-approve.service';
import { AlertService } from './../../../../shared/services/alert.service';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-leader-disagree',
  templateUrl: './leader-disagree.component.html',
  styleUrls: ['./leader-disagree.component.scss']
})
export class LeaderDisagreeComponent implements OnInit {
  disagreeMessage: string = '';
  projectId: string;
  taskId: string;

  constructor(
    public activeModal: NgbActiveModal,
    private alertService: AlertService,
    private taskApproveService: TaskApproveService
  ) { }

  ngOnInit() {

  }

  disagree(): void {
    this.taskApproveService.departmentLeaderApprove(this.taskId, false, this.projectId, this.disagreeMessage)
      .subscribe(res => {
        if (res.code === codeConstant.SUCCESS) {
          this.alertService.success('任务审批成功');
          this.disagreeMessage = '';
          this.activeModal.close();
        } else {
          this.alertService.error('任务审批失败，请重试！');
        }
      }, err => {
        console.debug('task approve failure', err);
        this.alertService.error('任务审批失败，请重试！');
      });
  }

}
