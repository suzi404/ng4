import { ActivatedRoute } from '@angular/router';
import { AuthenticationService } from './../../../../shared/services/authentication.service';
import { ConnectionBackend, RequestOptions, HttpModule } from '@angular/http';
import { HttpInterceptorService } from './../../../../shared/services/http-interceptor.service';
import { TaskApproveService } from './../../../../shared/services/task-approve.service';
import { AlertService } from './../../../../shared/services/alert.service';
import { NgbModule, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LeaderDisagreeComponent } from './leader-disagree.component';

describe('LeaderDisagreeComponent', () => {
  let component: LeaderDisagreeComponent;
  let fixture: ComponentFixture<LeaderDisagreeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [FormsModule,
        HttpModule,
        FormsModule,
      ],
      declarations: [LeaderDisagreeComponent],
      providers: [
        TaskApproveService,
        { provide: ActivatedRoute },
        NgbActiveModal,
        AuthenticationService,
        HttpInterceptorService,
        ConnectionBackend,
        AlertService,
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LeaderDisagreeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
