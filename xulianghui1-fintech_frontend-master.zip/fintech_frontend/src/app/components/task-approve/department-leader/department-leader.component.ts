import { LeaderDisagreeComponent } from './leader-disagree/leader-disagree.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TaskApproveService } from './../../../shared/services/task-approve.service';
import { codeConstant } from './../../../shared/constants/code.constant';
import { AlertService } from './../../../shared/services/alert.service';
import { ProjectsService } from './../../../shared/services/projects.service';
import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-department-leader',
  templateUrl: './department-leader.component.html',
  styleUrls: ['./department-leader.component.scss']
})
export class DepartmentLeaderComponent implements OnInit {
  projectId: string;
  taskId: string;
  projectInfo: any;
  buttonDisabled = true;

  constructor(
    private route: ActivatedRoute,
    private projectsService: ProjectsService,
    private alertService: AlertService,
    private taskApproveService: TaskApproveService,
    private modalService: NgbModal
  ) { }

  ngOnInit() {
    this.init();
    this.agree = this.agree.bind(this);
  }

  init() {
    this.route.queryParams.subscribe(params => {
      this.projectId = params['projectId'];
      this.taskId = params['taskId'];
      console.debug('projectId:', this.projectId, '  taskId:', this.taskId);
      if (!this.taskId) {
        this.alertService.error('未传入任务编号，请重试！');
        this.buttonDisabled = true;
      } else {
        this.canApprove(this.taskId);
      }

      if (!this.projectId) {
        this.alertService.error('项目申请编号不存在，请重试！');
        this.buttonDisabled = true;
      } else {
        this.loadProjectDetail(this.projectId);
      }
    });
  }

  canApprove(taskId: string) {
    this.taskApproveService.checkAssignee(taskId)
      .subscribe(
        res => {
          if (res.code === codeConstant.SUCCESS) {
            this.buttonDisabled = false;
          }
        },
        err => {
          this.buttonDisabled = true;
        }
      );
  }

  loadProjectDetail(projectId: string) {
    this.projectsService.getProjectDetail(projectId)
      .subscribe(
      res => {
        if (res.code === codeConstant.SUCCESS) {
          this.projectInfo = res.data;
        } else {
          this.alertService.error('获取项目信息失败，请重试！');
          this.buttonDisabled = true;
        }
      },
      err => {
        this.alertService.error('获取项目信息失败，请重试！');
      });
  }

  agree() {
    if (this.isTaskExist()) {
      this.taskApproveService.departmentLeaderApprove(this.taskId, true, this.projectId)
        .subscribe(res => {
          if (res.code === codeConstant.SUCCESS) {
            console.debug('approve success');
            this.alertService.success('任务审批成功');
            this.buttonDisabled = true;
          }
        });
    }
  }
  openLeaderDisagreeModal() {
    const modalRef = this.modalService.open(LeaderDisagreeComponent);
    modalRef.componentInstance.projectId = this.projectId;
    modalRef.componentInstance.taskId = this.taskId;
    modalRef.result
      .then(() => {
        this.buttonDisabled = true;
      })
      .catch(() => { });
  }

  private isTaskExist(): boolean {
    if (!this.taskId) {
      this.alertService.error('未传入任务编号，请重试！');
      return false;
    }
    return true;
  }
}
