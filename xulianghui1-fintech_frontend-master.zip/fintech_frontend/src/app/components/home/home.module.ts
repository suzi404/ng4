import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { HomeComponent } from './home.component';
import { HomeRoutingModule } from './home-routing.module';

import { HomeBannerComponent } from './home-banner/home-banner.component';
import { HighlightComponent } from './highlight/highlight.component';
import { StrategyDeclarationComponent } from './strategy-declaration/strategy-declaration.component';
import { IncubationModelComponent } from './incubation-model/incubation-model.component';
import { InnovationAreaComponent } from './innovation-area/innovation-area.component';
import { IncubationWorkflowComponent } from './incubation-workflow/incubation-workflow.component';
import { PopularQuestionsComponent } from './popular-questions/popular-questions.component';
import { ContactUsComponent } from './contact-us/contact-us.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    HomeRoutingModule,
  ],
  declarations: [
    HomeComponent,
    HomeBannerComponent,
    HighlightComponent,
    IncubationModelComponent,
    InnovationAreaComponent,
    StrategyDeclarationComponent,
    IncubationWorkflowComponent,
    PopularQuestionsComponent,
    ContactUsComponent,
  ]
})
export class HomeModule { }
