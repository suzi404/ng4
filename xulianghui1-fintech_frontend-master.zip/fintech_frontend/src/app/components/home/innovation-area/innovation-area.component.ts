import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-innovation-area',
  templateUrl: './innovation-area.component.html',
  styleUrls: ['./innovation-area.component.scss']
})
export class InnovationAreaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
