import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IncubationWorkflowComponent } from './incubation-workflow.component';

describe('IncubationWorkflowComponent', () => {
  let component: IncubationWorkflowComponent;
  let fixture: ComponentFixture<IncubationWorkflowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IncubationWorkflowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IncubationWorkflowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should change slide', () => {
    const slideLabel = fixture.debugElement.nativeElement.querySelectorAll('.workflow-slide li')[2];
    let event = new Event('mouseenter');
    slideLabel.dispatchEvent(event);
    fixture.detectChanges();
    const slideContent = fixture.debugElement.nativeElement.querySelector('.workflow-content li');
    expect(slideContent.textContent).toContain('价值假说');
  });
});
