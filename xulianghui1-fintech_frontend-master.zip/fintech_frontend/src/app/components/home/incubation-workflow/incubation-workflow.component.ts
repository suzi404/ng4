import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-incubation-workflow',
  templateUrl: './incubation-workflow.component.html',
  styleUrls: ['./incubation-workflow.component.scss']
})
export class IncubationWorkflowComponent implements OnInit {
  steps = [
    {'index': '1', 'title': '学习方法论'},
    {'index': '2', 'title': '申报项目'},
    {'index': '3', 'title': '价值假说'},
    {'index': '4', 'title': '落地规划'},
    {'index': '5', 'title': '沙盒验证'}
  ];
  currentStepIndex: number = 1;

  constructor() { }

  ngOnInit() {
  }

  changeSlide(index): void {
    let me = this;
    me.currentStepIndex = index;
  }
}
