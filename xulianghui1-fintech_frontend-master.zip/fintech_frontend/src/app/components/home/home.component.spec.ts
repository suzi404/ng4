import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpModule, ConnectionBackend } from '@angular/http';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

import { SharedModule } from '../../shared/shared.module';

import { HomeComponent } from './home.component';
import { HomeBannerComponent } from './home-banner/home-banner.component';
import { HighlightComponent } from './highlight/highlight.component';
import { StrategyDeclarationComponent } from './strategy-declaration/strategy-declaration.component';
import { IncubationModelComponent } from './incubation-model/incubation-model.component';
import { InnovationAreaComponent } from './innovation-area/innovation-area.component';
import { IncubationWorkflowComponent } from './incubation-workflow/incubation-workflow.component';
import { PopularQuestionsComponent } from './popular-questions/popular-questions.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { AlertService } from '../../shared/services/alert.service';
import { HttpInterceptorService } from '../../shared/services/http-interceptor.service';

describe('HomeComponent', () => {
  let component: HomeComponent;
  let fixture: ComponentFixture<HomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        HomeComponent,
        HomeBannerComponent,
        HighlightComponent,
        StrategyDeclarationComponent,
        IncubationModelComponent,
        InnovationAreaComponent,
        IncubationWorkflowComponent,
        PopularQuestionsComponent,
        ContactUsComponent
      ],
      imports: [
        HttpModule,
        FormsModule,
        SharedModule,
      ],
      providers: [
        AlertService,
        { provide: ActivatedRoute, useValue: { params: [ {'Data': '1', 'Token': '2'} ] } },
        ConnectionBackend,
        HttpInterceptorService,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
