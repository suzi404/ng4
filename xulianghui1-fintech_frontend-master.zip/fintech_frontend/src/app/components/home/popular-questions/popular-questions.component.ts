import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-popular-questions',
  templateUrl: './popular-questions.component.html',
  styleUrls: ['./popular-questions.component.scss']
})
export class PopularQuestionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
