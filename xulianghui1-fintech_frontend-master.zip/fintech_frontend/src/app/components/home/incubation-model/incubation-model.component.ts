import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-incubation-model',
  templateUrl: './incubation-model.component.html',
  styleUrls: ['./incubation-model.component.scss']
})
export class IncubationModelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
