import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IncubationModelComponent } from './incubation-model.component';

describe('IncubationModelComponent', () => {
  let component: IncubationModelComponent;
  let fixture: ComponentFixture<IncubationModelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IncubationModelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IncubationModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
