import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-strategy-declaration',
  templateUrl: './strategy-declaration.component.html',
  styleUrls: ['./strategy-declaration.component.scss']
})
export class StrategyDeclarationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
