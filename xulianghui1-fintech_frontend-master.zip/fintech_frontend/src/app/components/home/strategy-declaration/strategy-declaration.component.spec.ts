import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StrategyDeclarationComponent } from './strategy-declaration.component';

describe('StrategyDeclarationComponent', () => {
  let component: StrategyDeclarationComponent;
  let fixture: ComponentFixture<StrategyDeclarationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StrategyDeclarationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StrategyDeclarationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
