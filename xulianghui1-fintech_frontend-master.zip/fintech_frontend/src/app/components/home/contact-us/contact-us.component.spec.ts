import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpModule, ConnectionBackend } from '@angular/http';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';

import { ContactUsComponent } from './contact-us.component';
import { EmailService } from '../../../shared/services/email.service';
import { AlertService } from '../../../shared/services/alert.service';
import { AuthenticationService } from '../../../shared/services/authentication.service';
import { HttpInterceptorService } from '../../../shared/services/http-interceptor.service';

describe('ContactUsComponent', () => {
  let component: ContactUsComponent;
  let fixture: ComponentFixture<ContactUsComponent>;
  let emailService: EmailService;
  let stubSendEmailSuccessResponse = { 'code': '0', 'message': '新增成功' };
  let stubSendEmailFailureResponse = { 'code': '1', 'message': '新增失败' };

  let subject: string = '邮件主题';
  let body: string = '邮件内容';

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        ContactUsComponent
      ],
      imports: [
        HttpModule,
        FormsModule
      ],
      providers: [
        { provide: ActivatedRoute },
        EmailService,
        AlertService,
        AuthenticationService,
        HttpInterceptorService,
        ConnectionBackend,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContactUsComponent);
    component = fixture.componentInstance;
    component.subject = subject;
    component.body = body;
    emailService = fixture.debugElement.injector.get(EmailService);
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should send email success', () => {
    spyOn(emailService, 'sendEmail').and.returnValue(Observable.of(stubSendEmailSuccessResponse));
    component.onSubmit();

    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(component.subject).toEqual('');
      expect(component.body).toEqual('');
    });
  });

  it('should send email failure', () => {
    spyOn(emailService, 'sendEmail').and.returnValue(Observable.of(stubSendEmailFailureResponse));
    component.onSubmit();

    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(component.subject).not.toEqual('');
      expect(component.body).not.toEqual('');
    });
  });
});
