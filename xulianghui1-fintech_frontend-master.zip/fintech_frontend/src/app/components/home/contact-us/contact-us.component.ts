import { Component, OnInit } from '@angular/core';
import { EmailService } from '../../../shared/services/email.service';
import { codeConstant } from '../../../shared/constants/code.constant';
import { AlertService } from '../../../shared/services/alert.service';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.scss']
})
export class ContactUsComponent implements OnInit {
  submitted: boolean = false;
  submitting: boolean = false;
  subject: string;
  body: string;

  constructor(
    private emailService: EmailService,
    private alertService: AlertService
  ) { }

  ngOnInit() {
  }

  onSubmit(): void {
    let me = this;
    let question = {
      'subject': me.subject,
      'body': me.body
    };
    me.submitted = true;
    me.submitting = true;

    me.emailService.sendEmail(question)
      .subscribe(
        res => {
          console.debug('send email success', res);
          me.submitting = false;
          if (res.code === codeConstant.SUCCESS) {
            me.alertService.success('发送成功！');
            me.clearEmailForm();
          } else {
            me.alertService.error('发送失败，请重试');
          }
        },
        err => {
          console.debug('send email failure', err);
          me.submitting = false;
          me.alertService.error('发送失败，请重试');
        }
      );
  }

  clearEmailForm(): void {
    this.subject = '';
    this.body = '';
  }
}
