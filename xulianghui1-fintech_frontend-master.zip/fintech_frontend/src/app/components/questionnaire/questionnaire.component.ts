import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { QuestionnaireService } from './questionnaire.service';
import { AlertService } from '../../shared/services/alert.service';

@Component({
  selector: 'app-questionnaire',
  templateUrl: './questionnaire.component.html',
  styleUrls: ['./questionnaire.component.scss']
})
export class QuestionnaireComponent implements OnInit {
  model = [];
  progress = 0;
  currentIndex = 0;
  isStarted = false;
  isEnded = false;
  isReviewMode = false;
  finishButtonText = '提交问卷，填写项目申请表';

  constructor(
    private router: Router,
    private questionnaireService: QuestionnaireService,
    private alertService: AlertService,
    private activatedRoute: ActivatedRoute
  ) {}

  ngOnInit() {
    console.log('activatedRoute.snapshot:', this.activatedRoute.snapshot);
    this.isReviewMode =
      this.activatedRoute.snapshot.params.reviewMode === 'view';

    this.questionnaireService.checkIfAlreadyAnswerd().subscribe(res => {
      let isAlreadyAnswered = res.data;
      if (isAlreadyAnswered === true && this.isReviewMode !== true) {
        // redirect to project-application page, if already answered and not in reviewMode
        this.router.navigate(['/project-application']);
      } else if (isAlreadyAnswered === true && this.isReviewMode === true) {
        // get answered submitted last time, if already answered and is in reviewMode
        this.questionnaireService
          .getAnswersSubmittedLastTime()
          .subscribe(res => {
            this.model = res.data;

            // discussed with Ou Yang, this page should make some changes below if it's in review mode.
            this.isStarted = true;
            this.finishButtonText = '填写项目申请表';
          });
      } else if (isAlreadyAnswered === false) {
        // no answers submitted before, then just get questions from backend
        this.questionnaireService.getQuestions().subscribe(res => {
          this.model = res.data;
        });
      }
    });
  }

  updateCurrentProgress() {
    this.progress = (this.currentIndex + 1) / this.model.length * 100;
    this.isEnded = this.currentIndex + 1 === this.model.length;
  }

  toPreviousStep() {
    this.currentIndex--;
    this.updateCurrentProgress();
  }

  toNextStep() {
    this.model[this.currentIndex].answerTime = Date.now();
    this.model[this.currentIndex].userName = this.model[
      this.currentIndex
    ].createUserName;

    this.currentIndex++;
    this.updateCurrentProgress();
  }

  start() {
    this.isStarted = true;
  }

  finish() {
    // just redirect to project-application page if current page is in review mode
    if (this.isReviewMode) {
      this.router.navigate(['/project-application']);
      return;
    }

    // mapping data to the data structure below, because of the requirement of the api - /answers
    let mappedData = this.model.map(x => {
      return {
        questionId: x.questionId,
        serialNumber: x.serialNumber,
        question: x.question,
        answer: x.answer,
        answerTime: x.answerTime
      };
    });

    this.questionnaireService.postAnswers(mappedData).subscribe(res => {
      this.alertService.success('问卷提交成功');
      this.router.navigate(['/project-application']);
    });
  }
}
