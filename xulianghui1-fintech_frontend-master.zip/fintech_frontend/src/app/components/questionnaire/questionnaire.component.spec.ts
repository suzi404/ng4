import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { HttpModule, ConnectionBackend } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';

import { RouterTestingModule } from '@angular/router/testing';

import { QuestionnaireComponent } from './questionnaire.component';
import { IndicatorComponent } from '../../shared/components/indicator/indicator.component';
import { IndicatorUnitComponent } from '../../shared/components/indicator-unit/indicator-unit.component';
import { QuestionnaireService } from './questionnaire.service';
import { HttpInterceptorService } from '../../shared/services/http-interceptor.service';
import { AlertService } from '../../shared/services/alert.service';

describe('QuestionnaireComponent', () => {
  let component: QuestionnaireComponent;
  let fixture: ComponentFixture<QuestionnaireComponent>;
  let questionnaireService: QuestionnaireService;
  beforeEach(
    async(() => {
      TestBed.configureTestingModule({
        imports: [FormsModule, RouterTestingModule, HttpModule],
        declarations: [
          QuestionnaireComponent,
          IndicatorComponent,
          IndicatorUnitComponent
        ],
        providers: [
          HttpInterceptorService,
          ConnectionBackend,
          QuestionnaireService,
          AlertService
        ]
      }).compileComponents();
    })
  );

  const mockedResponse = {
    code: '0',
    message: 'get project list',
    data: []
  };

  const mockedData = {};

  beforeEach(() => {
    fixture = TestBed.createComponent(QuestionnaireComponent);
    component = fixture.componentInstance;
    questionnaireService = fixture.debugElement.injector.get(
      QuestionnaireService
    );
    spyOn(questionnaireService, 'getQuestions').and.returnValue(
      Observable.of(mockedResponse)
    );
    spyOn(questionnaireService, 'checkIfAlreadyAnswerd').and.returnValue(
      Observable.of(mockedData)
    );
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
