import { TestBed, inject } from '@angular/core/testing';

import { QuestionnaireService } from './questionnaire.service';

import { HttpInterceptorService } from '../../shared/services/http-interceptor.service';
import {
  HttpModule,
  ConnectionBackend,
  RequestOptions,
} from '@angular/http';

describe('QuestionnaireService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpModule
      ],
      providers: [
        HttpInterceptorService,
        RequestOptions,
        ConnectionBackend
      ]
    });
  });

  // it('should be created', inject([QuestionnaireService], (service: QuestionnaireService) => {
  //   expect(service).toBeTruthy();
  // }));
});
