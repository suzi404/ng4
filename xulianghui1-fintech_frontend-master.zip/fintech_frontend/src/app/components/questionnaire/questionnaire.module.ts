import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { QuestionnairRoutingeModule } from './questionnaire-routing.module';
import { SharedModule } from '../../shared/shared.module';

import { QuestionnaireComponent } from './questionnaire.component';

import { QuestionnaireService } from './questionnaire.service';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    SharedModule,
    QuestionnairRoutingeModule
  ],
  declarations: [QuestionnaireComponent],
  providers: [ QuestionnaireService ]
})
export class QuestionnaireModule {}
