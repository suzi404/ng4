import { Injectable } from '@angular/core';
import { HttpInterceptorService } from '../../shared/services/http-interceptor.service';
import { apiConstant } from '../../shared/constants/api.constant';

@Injectable()
export class QuestionnaireService {
  constructor(private http: HttpInterceptorService) {}
  getQuestions() {
    return this.http
      .get(apiConstant.questions)
      .map(response => response.json());
  }

  postAnswers(body) {
    return this.http
      .post(apiConstant.answers, body)
      .map(response => response.json());
  }

  checkIfAlreadyAnswerd() {
    return this.http
      .get(apiConstant.answers + '/isexist')
      .map(res => res.json());
  }

  getAnswersSubmittedLastTime() {
    return this.http
      .get(apiConstant.answers + '/selectbyuserid')
      .map(res => res.json());
  }
}
