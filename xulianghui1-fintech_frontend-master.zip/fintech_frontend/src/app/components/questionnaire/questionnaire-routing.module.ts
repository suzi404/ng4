import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { QuestionnaireComponent } from './questionnaire.component';

@NgModule({
  imports: [
    RouterModule.forChild([
      { path: '', component: QuestionnaireComponent },
      { path: ':reviewMode', component: QuestionnaireComponent }
    ])
  ],
  exports: [RouterModule]
})
export class QuestionnairRoutingeModule {}
