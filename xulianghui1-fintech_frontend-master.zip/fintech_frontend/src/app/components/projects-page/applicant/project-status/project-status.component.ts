import { Component, OnInit, Input } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { UserSelectorComponent } from '../../../../shared/components/user-selector/user-selector.component';
import { ReassignSupervisorComponent } from '../../components/modals/reassign-supervisor/reassign-supervisor.component';
import { ProjectsService } from 'app/shared/services/projects.service';
import { codeConstant } from '../../../../shared/constants/code.constant';
import { courseTypeConstant } from '../../../../shared/constants/project.constant';
import { Course } from 'app/shared/models/course';
import { leanBooksConstant } from '../../../resources-page/constants/course.constant';
import { CourseService } from 'app/shared/services/course.service';
@Component({
  selector: 'app-project-status',
  templateUrl: './project-status.component.html',
  styleUrls: ['./project-status.component.scss']
})
export class ProjectStatusComponent implements OnInit {
  constructor(
    private modalService: NgbModal,
    private projectsService: ProjectsService,
    private route: ActivatedRoute,
    private courseService: CourseService,
    private router: Router,
  ) {}

  editStatus: boolean = false;
  applyId: string;
  project: any;
  projectName: string;
  showReassignSection = false;
  loading: boolean = true;
  courses: Course[] = [];
  books: Array<any> = leanBooksConstant;

  ngOnInit() {
    this.applyId = this.route.snapshot.params.id;
    this.projectsService.getProjectDetail(this.applyId).subscribe(res => {
      let primaryStatus = res.data.projectInfo.projectAction;
      if (primaryStatus == 113) {
        this.editStatus = true;
      }
      this.project = res.data;
      this.projectName = res.data.projectInfo.projectName;
      this.showReassignSection = primaryStatus === 112 || primaryStatus === 114;
    });
    this.getVideoList();
  }

  //点击修改跳转到修改申请页面
  editLocation(): void {
    this.router.navigate([`/project-application/${this.applyId}`]);
  }

  getVideoList(): void {
    let me = this;
    me.courseService.getCourses(courseTypeConstant.courseType).subscribe(
      res => {
        if (res.data) {
          me.courses = res.data.data;
        }
      },
      err => {},
      () => {
        me.loading = false;
      }
    );
  }

  popUpChangeSupervisorModal() {
    const modalRef = this.modalService.open(ReassignSupervisorComponent, {
      size: 'lg'
    });
    modalRef.componentInstance.applyId = this.applyId;
    modalRef.result
      .then(() => {
        // a workaround to handle 2 things after requesting successfully
        // 1. hide ReassignSection on page
        // 2. update app-project-progress-status component
        window.location.reload();
      })
      .catch(() => {});
  }

  openDetail(projectDetail) {
    this.modalService.open(projectDetail);
  }
}
