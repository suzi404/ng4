import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ConnectionBackend, HttpModule } from '@angular/http';
import { NgbModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Rx';

import { MockComponent } from 'ng2-mock-component';

import { ProjectStatusComponent } from './project-status.component';
import { ProjectsService } from 'app/shared/services/projects.service';
import { CourseService } from 'app/shared/services/course.service';

import { AlertService } from 'app/shared/services/alert.service';
import { HttpInterceptorService } from 'app/shared/services/http-interceptor.service';
import { AuthenticationService } from 'app/shared/services/authentication.service';
import { UserSelectorComponent } from 'app/shared/components/user-selector/user-selector.component';
import { SharedModule } from 'app/shared/shared.module';

import { ProjectPageTempleteComponent } from '../../components/project-page-templete/project-page-templete.component';
import { InnovationCalendarComponent } from '../../components/innovation-calendar/innovation-calendar.component';
import { ProjectProgressStatusComponent } from '../../components/project-progress-status/project-progress-status.component';

const mockProjectStatusInfo = require('mockServer/resources/projectStatus');
const mockVideoList = require('mockServer/resources/videoList');

describe('ProjectStatusComponent', () => {
  let component: ProjectStatusComponent;
  let fixture: ComponentFixture<ProjectStatusComponent>;
  let projectsService: ProjectsService;
  let courseService: CourseService;

  let mockedData = {
    data: { projectInfo: { projectAction: 1 } }
  };

  beforeEach(
    async(() => {
      TestBed.configureTestingModule({
        imports: [
          NgbModule.forRoot(),
          RouterTestingModule,
          HttpModule,
          SharedModule,
        ],
        declarations: [
          ProjectStatusComponent,
          ProjectPageTempleteComponent,
          InnovationCalendarComponent,
          ProjectProgressStatusComponent,
          MockComponent({
            selector: 'app-project-info',
            inputs: ['projectInfo']
          })
        ],
        providers: [
          NgbModal,
          ProjectsService,
          HttpInterceptorService,
          ConnectionBackend,
          AlertService,
          AuthenticationService,
          {
            provide: ActivatedRoute,
            useValue: { snapshot: { params: { id: 1 } } }
          }
        ]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectStatusComponent);
    component = fixture.componentInstance;
    projectsService = fixture.debugElement.injector.get(ProjectsService);
    spyOn(projectsService, 'getProjectDetail').and.returnValue(
      Observable.of(mockedData)
    );

    courseService = fixture.debugElement.injector.get(CourseService);
    spyOn(courseService, 'getCourses').and.returnValue(Observable.of(mockVideoList));

    spyOn(projectsService, 'fetchLatestProjectStatus').and.returnValue(Observable.of(mockProjectStatusInfo));

    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
