import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpModule, ConnectionBackend } from '@angular/http';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';

import { ProjectPageTempleteComponent } from '../../components/project-page-templete/project-page-templete.component';
import { InnovationCalendarComponent } from '../../components/innovation-calendar/innovation-calendar.component';

import { HttpInterceptorService } from '../../../../shared/services/http-interceptor.service';
import { AuthenticationService } from '../../../../shared/services/authentication.service';
import { ProjectsService } from '../../../../shared/services/projects.service';

import { ApplicantProjectListComponent } from './applicant-project-list.component';
import { ProjectItemComponent } from './project-item/project-item.component';
import { AlertService } from 'app/shared/services/alert.service';

describe('ApplicantProjectListComponent', () => {
  let component: ApplicantProjectListComponent;
  let fixture: ComponentFixture<ApplicantProjectListComponent>;
  let projectsService: ProjectsService;

  let stubProjectListResponse = {
    'code': '0',
    'message': 'get project list',
    'data': {
      'data': [
        {
          id: 1,
          name: 'FINTECH 创新项目孵化平台',
          director: '关远',
          progress: 100,
        },
      ]
    }
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
        imports: [
          HttpModule,
          RouterTestingModule,
          NgbModule.forRoot()
        ],
        declarations: [
          ProjectPageTempleteComponent,
          InnovationCalendarComponent,
          ApplicantProjectListComponent,
          ProjectItemComponent
        ],
        providers: [
          { provide: ActivatedRoute },
          HttpInterceptorService,
          AuthenticationService,
          ProjectsService,
          ConnectionBackend,
          AlertService
        ]
      })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplicantProjectListComponent);
    component = fixture.componentInstance;
    projectsService = fixture.debugElement.injector.get(ProjectsService);
    spyOn(projectsService, 'getProjectList').and.returnValue(Observable.of(stubProjectListResponse));
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should get project list', () => {
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(component.projects.length).toEqual(1);
    });
  });
});
