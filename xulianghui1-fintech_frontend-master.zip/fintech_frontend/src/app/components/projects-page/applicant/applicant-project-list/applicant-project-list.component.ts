import { Component, OnInit, ViewEncapsulation } from '@angular/core';

import _ from 'lodash';
import { ProjectsService } from '../../../../shared/services/projects.service';
import { codeConstant } from '../../../../shared/constants/code.constant';
import { Project } from '../../types/Project';

@Component({
  selector: 'app-applicant-project-list',
  templateUrl: './applicant-project-list.component.html',
  styleUrls: ['./applicant-project-list.component.scss']
})
export class ApplicantProjectListComponent implements OnInit {
  projects: Project[] = [];

  constructor(private projectsService: ProjectsService) {
  }

  ngOnInit() {
    this.initProjects();
  }

  initProjects() {
    this.projectsService.getProjectList()
      .subscribe(
        res => {
          console.debug('get project list', res);
          if (res.code === codeConstant.SUCCESS && res.data) {
            this.projects = res.data.data;
          }
        },
        error => {
          console.debug('get project list failure', error);
        }
      );
  }
}
