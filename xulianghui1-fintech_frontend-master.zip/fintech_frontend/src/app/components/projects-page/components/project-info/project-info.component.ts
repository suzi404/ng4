import { LabelType, stakeholders } from './../../../../shared/models/project-info.model';
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-project-info',
  templateUrl: './project-info.component.html',
  styleUrls: ['./project-info.component.scss']
})
export class ProjectInfoComponent implements OnInit {

  @Input() projectInfo: any;

  constructor() { }

  ngOnInit() {
  }

  get innovationLabel(): string {
    let innoStr = this.getLabel(LabelType.innovationArea);
    let str = innoStr.join('、');
    return str ? str : '暂无';
  }

  get techUsedLabel(): string {
    let techStr = this.getLabel(LabelType.techUsed);
    let str = techStr.join('、');
    return str ? str : '暂无';
  }

  private getLabel(type: LabelType): string[] {
    let strs = [];
    (<Array<any>>this.projectInfo.projectLabels).forEach(
      item => {
        if (item.labelType === type) {
          strs.push(item.labelName);
        }
      });
    return strs;
  }

  get itManager() {
    let str = this.getStakeholder(stakeholders.itManager).join('、');
    return str ? str : '暂无';
  }

  get sandboxSupporter() {
    let str = this.getStakeholder(stakeholders.sandboxSupporter).join('、');
    return str ? str : '暂无';
  }

  private getStakeholder(type: string): string[] {
    let temp = (<Array<any>>this.projectInfo.projectPersons).filter(
      item => item.role === type
    );
    let list = [];
    temp.forEach(item => list.push(item.ystName));
    return list;
  }

}
