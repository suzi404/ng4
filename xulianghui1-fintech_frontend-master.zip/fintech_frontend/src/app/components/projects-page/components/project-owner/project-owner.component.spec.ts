import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjectOwnerComponent } from './project-owner.component';

describe('ProjectOwnerComponent', () => {
  let component: ProjectOwnerComponent;
  let fixture: ComponentFixture<ProjectOwnerComponent>;
  let owner: any = {
    ystName: '赵晓',
    ystId: '518000',
    telephone: '13976439754',
    email: 'zhaoxiao@cmb.com',
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProjectOwnerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectOwnerComponent);
    component = fixture.componentInstance;
    component.owner = owner;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
