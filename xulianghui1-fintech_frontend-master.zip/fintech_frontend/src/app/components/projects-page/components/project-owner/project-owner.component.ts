import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-project-owner',
  templateUrl: './project-owner.component.html',
  styleUrls: ['./project-owner.component.scss']
})
export class ProjectOwnerComponent implements OnInit {
  @Input() owner: any;

  constructor() { }

  ngOnInit() {
  }

}
