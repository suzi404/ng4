import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjectPageTempleteComponent } from './project-page-templete.component';

describe('ProjectPageTempleteComponent', () => {
  let component: ProjectPageTempleteComponent;
  let fixture: ComponentFixture<ProjectPageTempleteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProjectPageTempleteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectPageTempleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
