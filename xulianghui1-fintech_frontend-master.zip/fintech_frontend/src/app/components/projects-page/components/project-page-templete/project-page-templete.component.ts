import { Component, OnInit, Input, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-project-page-templete',
  templateUrl: './project-page-templete.component.html',
  styleUrls: ['./project-page-templete.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ProjectPageTempleteComponent implements OnInit {

  @Input() title: string;
  @Input() align: string = 'center';

  constructor() { }

  ngOnInit() {
  }

}
