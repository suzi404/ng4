import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Ng2PageScrollModule } from 'ng2-page-scroll';
import { NgStickyModule } from 'ng-sticky';
import { MockComponent } from 'ng2-mock-component';

import { ProjectInfoWithNavComponent } from './project-info-with-nav.component';
import {ProjectInfoComponent} from '../project-info/project-info.component';
import {SharedModule} from '../../../../shared/shared.module';

describe('ProjectInfoWithNavComponent', () => {
  let component: ProjectInfoWithNavComponent;
  let fixture: ComponentFixture<ProjectInfoWithNavComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        SharedModule,
        Ng2PageScrollModule,
        NgStickyModule,
      ],
      declarations: [
        ProjectInfoWithNavComponent,
        MockComponent({
          selector: 'app-project-info',
          inputs: ['projectInfo']
        })
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectInfoWithNavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
