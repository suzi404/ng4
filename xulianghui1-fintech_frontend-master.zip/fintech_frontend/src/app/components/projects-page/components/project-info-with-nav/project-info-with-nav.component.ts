import { Component, OnInit, Input, ViewEncapsulation } from '@angular/core';
import { PageScrollConfig } from 'ng2-page-scroll';

@Component({
  selector: 'app-project-info-with-nav',
  templateUrl: './project-info-with-nav.component.html',
  styleUrls: ['./project-info-with-nav.component.scss']
})
export class ProjectInfoWithNavComponent implements OnInit {

  @Input() project: any;

  constructor() {
    PageScrollConfig.defaultScrollOffset = 200;
    PageScrollConfig.defaultDuration = 500;
  }

  ngOnInit() {
  }

}
