import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

import { ProjectsService } from '../../../../../shared/services/projects.service';
import { AlertService } from '../../../../../shared/services/alert.service';
import { PersonRole } from '../../../../../shared/models/user.model';

const roles = {
  it: 'it',
  sandbox: 'sandbox'
};

@Component({
  selector: 'app-itofficer-assign-persons',
  templateUrl: './itofficer-assign-persons.component.html',
  styleUrls: ['./itofficer-assign-persons.component.scss']
})
export class ItofficerAssignPersonsComponent implements OnInit {

  applyId: string;
  currentPersonRole = roles.it;
  persons = [];

  constructor(
    private activeModal: NgbActiveModal,
    private projectsService: ProjectsService,
    private alertService: AlertService
  ) { }

  ngOnInit() {
  }

  handleSelectITPerson(selectedList) {
    this.currentPersonRole = roles.sandbox;
    this.persons.push({
      applyId: this.applyId,
      ystId: selectedList[0].id,
      role: PersonRole.it,
    });
  }

  handleSelectSandboxPerson(selectedList) {
    this.persons.push({
      applyId: this.applyId,
      ystId: selectedList[0].id,
      role: PersonRole.sandbox,
    });

    this.projectsService
      .insertPersons(this.persons)
      .subscribe(res => {
        this.alertService.success('已为项目指定IT负责人和沙盒负责人');
        this.activeModal.close();
      });
  }
}
