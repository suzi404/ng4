import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { UserSelectorComponent } from 'app/shared/components/user-selector/user-selector.component';
import { ProjectsService } from 'app/shared/services/projects.service';
import { AlertService } from 'app/shared/services/alert.service';

@Component({
  selector: 'app-reassign-supervisor',
  templateUrl: './reassign-supervisor.component.html',
  styleUrls: ['./reassign-supervisor.component.scss']
})
export class ReassignSupervisorComponent implements OnInit {
  applyId: string;
  constructor(
    private activeModal: NgbActiveModal,
    private projectsService: ProjectsService,
    private alertService: AlertService
  ) {}

  ngOnInit() {}

  handleNext(selectedList) {
    let leaderId = selectedList[0].id;
    this.projectsService
      .postReassignSupervisor(this.applyId, leaderId)
      .subscribe(res => {
        this.alertService.success('更换审核人成功');
        this.activeModal.close();
      });
  }
}
