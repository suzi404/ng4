import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ProjectsService } from '../../../../../shared/services/projects.service';
import { AlertService } from '../../../../../shared/services/alert.service';
import { codeConstant, exceptionCodeConstant } from '../../../../../shared/constants/code.constant';

@Component({
  selector: 'app-suspend-project',
  templateUrl: './suspend-project.component.html',
  styleUrls: ['./suspend-project.component.scss']
})
export class SuspendProjectComponent implements OnInit {
  suspendMessage: string = '';
  projectApplyIds: Array<string>;

  constructor(
    public activeModal: NgbActiveModal,
    private alertService: AlertService,
    private projectsService: ProjectsService
  ) { }

  ngOnInit() {

  }

  suspendProjects(): void {
    let me = this;
    if (!me.projectApplyIds.length) {
      return;
    }
    me.projectsService.suspendProjects(me.projectApplyIds, me.suspendMessage)
      .subscribe(
        res => {
          me.alertService.success('暂停项目成功！');
          me.suspendMessage = '';
          me.activeModal.close();
        },
        err => {
          if (err.code === exceptionCodeConstant.suspend_half_success) {
            this.alertService.error(`部分项目暂停失败: [${err.data.toString()}]`);
            this.suspendMessage = '';
            this.activeModal.close();
          } else {
            me.alertService.error('暂停项目失败，请重试');
          }
        }
      );
  }

}
