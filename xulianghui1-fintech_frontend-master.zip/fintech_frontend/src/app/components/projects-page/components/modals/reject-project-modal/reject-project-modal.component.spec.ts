import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { HttpModule, ConnectionBackend } from '@angular/http';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';

import { AuthenticationService } from '../../../../../shared/services/authentication.service';
import { HttpInterceptorService } from '../../../../../shared/services/http-interceptor.service';
import { AlertService } from '../../../../../shared/services/alert.service';
import { ProjectsService } from '../../../../../shared/services/projects.service';

import { RejectProjectModalComponent } from './reject-project-modal.component';

describe('RejectProjectModalComponent', () => {
  let component: RejectProjectModalComponent;
  let fixture: ComponentFixture<RejectProjectModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
        imports: [
          FormsModule,
          HttpModule,
        ],
        providers: [
          { provide: ActivatedRoute },
          NgbActiveModal,
          AuthenticationService,
          HttpInterceptorService,
          ConnectionBackend,
          AlertService,
          ProjectsService,
        ],
        declarations: [ RejectProjectModalComponent ]
      })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RejectProjectModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
