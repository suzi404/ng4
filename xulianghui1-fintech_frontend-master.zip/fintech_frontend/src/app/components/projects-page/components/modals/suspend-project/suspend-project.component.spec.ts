import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { HttpModule, ConnectionBackend } from '@angular/http';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';

import { SuspendProjectComponent } from './suspend-project.component';
import { Project } from '../../../types/Project';

import { AuthenticationService } from '../../../../../shared/services/authentication.service';
import { HttpInterceptorService } from '../../../../../shared/services/http-interceptor.service';
import { AlertService } from '../../../../../shared/services/alert.service';
import { ProjectsService } from '../../../../../shared/services/projects.service';

describe('SuspendProjectComponent', () => {
  let component: SuspendProjectComponent;
  let fixture: ComponentFixture<SuspendProjectComponent>;
  let projectsService: ProjectsService;

  let stubSuspendProjectsSuccessResponse = { 'code': '0', 'message': '项目暂停成功' };
  let stubProjects: Array<Project> = [
    {
      'applyId': 'aaaa',
      'projectName': '金融科技创新平台改进',
      'ystName': '姓名',
      'ystOrgName': '部门',
    },
    {
      'applyId': 'bbbb',
      'projectName': '金融科技创新平台改进',
      'ystName': '姓名',
      'ystOrgName': '部门',
    }
  ];

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        HttpModule,
      ],
      providers: [
        { provide: ActivatedRoute },
        NgbActiveModal,
        AuthenticationService,
        HttpInterceptorService,
        ConnectionBackend,
        AlertService,
        ProjectsService,
      ],
      declarations: [ SuspendProjectComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SuspendProjectComponent);
    component = fixture.componentInstance;
    component.projectApplyIds = [stubProjects[0]['applyId'], stubProjects[1]['applyId']];
    projectsService = fixture.debugElement.injector.get(ProjectsService);
    spyOn(projectsService, 'suspendProjects').and.returnValue(Observable.of(stubSuspendProjectsSuccessResponse));
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should suspend projects success', () => {
    component.suspendMessage = 'abc';
    component.suspendProjects();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(component.suspendMessage).toBeFalsy();
    });
  });

  it('should suspend projects failure', () => {
    component.suspendMessage = '';
    const submitButton = fixture.debugElement.nativeElement.querySelector('button[type=submit]');
    component.suspendProjects();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(submitButton.textContent).toContain('暂停');
    });
  });

  it('should submit suspend projects success', () => {
    component.suspendMessage = 'abc';
    const submitButton = fixture.debugElement.nativeElement.querySelector('button[type=submit]');
    submitButton.click();
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(component.suspendMessage).toBeFalsy();
    });
  });

});
