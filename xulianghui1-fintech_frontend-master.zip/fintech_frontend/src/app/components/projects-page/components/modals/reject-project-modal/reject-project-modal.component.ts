import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ProjectsService } from '../../../../../shared/services/projects.service';
import { AlertService } from '../../../../../shared/services/alert.service';
import { codeConstant, exceptionCodeConstant } from '../../../../../shared/constants/code.constant';

@Component({
  selector: 'app-reject-project-modal',
  templateUrl: './reject-project-modal.component.html',
  styleUrls: ['./reject-project-modal.component.scss']
})
export class RejectProjectModalComponent implements OnInit {

  message: string = '';
  projectApplyIds: Array<string>;

  constructor(
    public activeModal: NgbActiveModal,
    private alertService: AlertService,
    private projectsService: ProjectsService
  ) { }

  ngOnInit() {

  }

  rejectProjects(): void {
    if (!this.projectApplyIds.length) {
      return;
    }

    this.projectsService.rejectProjects(this.projectApplyIds, this.message)
      .subscribe(
        res => {
          this.alertService.success('驳回项目成功！');
          this.message = '';
          this.activeModal.close();
        },
        err => {
          if (err.code === exceptionCodeConstant.reject_half_success) {
            this.alertService.error(`部分项目执行失败: [${err.data.toString()}]`);
            this.message = '';
            this.activeModal.close();
          } else {
            this.alertService.error('驳回项目失败，请重试');
          }
        }
      );
  }}
