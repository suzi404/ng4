import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Jsonp, ConnectionBackend, HttpModule } from '@angular/http';
import { Observable } from 'rxjs/Rx';

import { ReassignSupervisorComponent } from './reassign-supervisor.component';

import { UserSelectorComponent } from 'app/shared/components/user-selector/user-selector.component';
import { ProjectsService } from 'app/shared/services/projects.service';
import { AlertService } from 'app/shared/services/alert.service';
import { HttpInterceptorService } from 'app/shared/services/http-interceptor.service';
import { AuthenticationService } from 'app/shared/services/authentication.service';
import { SharedModule } from 'app/shared/shared.module';
import { UserSelectorService } from 'app/shared/services/user-selector.service';

describe('ReassignSupervisorComponent', () => {
  let component: ReassignSupervisorComponent;
  let fixture: ComponentFixture<ReassignSupervisorComponent>;
  let userSelectorService: UserSelectorService;

  const topRemoteResponse = [
    {
      id: '100001',
      text: '招商银行/100001',
      state: 'open',
      attributes: 'CANSELECT=Y',
      iconCls: null,
      children: [
        {
          id: '100003',
          text: '总行/100003',
          state: 'closed',
          attributes:
            'TEXT=总行/100003:ORGID=100003:GPID=0100000000:NAME=总行:GPNM=总行:PATH=总行:EMAIL=@cmbchina.com',
          iconCls: 'tree-folder',
          children: []
        },
        {
          id: '100314',
          text: '北京分行/100314',
          state: 'closed',
          attributes:
            'TEXT=北京分行/100314:ORGID=100314:GPID=0201000000:NAME=北京分行:GPNM=北京分行:PATH=北京分行:EMAIL=@cmbchina.com',
          iconCls: 'tree-folder',
          children: []
        }
      ]
    }
  ];

  beforeEach(
    async(() => {
      TestBed.configureTestingModule({
        imports: [HttpModule, SharedModule],
        declarations: [ReassignSupervisorComponent],
        providers: [
          UserSelectorComponent,
          ProjectsService,
          AlertService,
          NgbActiveModal,
          HttpInterceptorService,
          ConnectionBackend,
          AuthenticationService,
          UserSelectorService,
          Jsonp,
          { provide: ActivatedRoute, useValue: { params: { id: 1 } } }
        ]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(ReassignSupervisorComponent);
    component = fixture.componentInstance;
    userSelectorService = fixture.debugElement.injector.get(
      UserSelectorService
    );
    spyOn(userSelectorService, 'getInstitutionUser').and.returnValue(
      Observable.of(topRemoteResponse)
    );
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
