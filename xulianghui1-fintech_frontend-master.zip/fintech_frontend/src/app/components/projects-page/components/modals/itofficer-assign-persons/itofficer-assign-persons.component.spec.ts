import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MockComponent } from 'ng2-mock-component';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { HttpModule, ConnectionBackend } from '@angular/http';

import { ItofficerAssignPersonsComponent } from './itofficer-assign-persons.component';
import { ProjectsService } from '../../../../../shared/services/projects.service';
import {HttpInterceptorService} from '../../../../../shared/services/http-interceptor.service';
import {AlertService} from '../../../../../shared/services/alert.service';
import {AuthenticationService} from '../../../../../shared/services/authentication.service';

describe('ItofficerAssignPersonsComponent', () => {
  let component: ItofficerAssignPersonsComponent;
  let fixture: ComponentFixture<ItofficerAssignPersonsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpModule,
      ],
      declarations: [
        ItofficerAssignPersonsComponent,
        MockComponent({
          selector: 'app-user-selector',
          inputs: ['submitText', 'mutilSelect']
        }),
      ],
      providers: [
        NgbActiveModal,
        AuthenticationService,
        ProjectsService,
        HttpInterceptorService,
        AlertService,
        ConnectionBackend,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ItofficerAssignPersonsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
