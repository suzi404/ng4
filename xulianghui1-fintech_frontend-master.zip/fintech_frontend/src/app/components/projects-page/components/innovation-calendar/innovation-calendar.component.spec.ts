import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InnovationCalendarComponent } from './innovation-calendar.component';

describe('InnovationCalendarComponent', () => {
  let component: InnovationCalendarComponent;
  let fixture: ComponentFixture<InnovationCalendarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InnovationCalendarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InnovationCalendarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
