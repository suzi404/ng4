import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-innovation-calendar',
  templateUrl: './innovation-calendar.component.html',
  styleUrls: ['./innovation-calendar.component.scss']
})
export class InnovationCalendarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
