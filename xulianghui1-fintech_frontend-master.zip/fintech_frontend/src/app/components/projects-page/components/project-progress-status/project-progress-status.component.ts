import { Component, OnInit, Input } from '@angular/core';
import { NgbPopoverConfig } from '@ng-bootstrap/ng-bootstrap';

import {totalStages} from './project-progress-status.constant';
import {stagesPerStep} from './project-progress-status.constant';
import {totalSteps} from './project-progress-status.constant';
import {STATUS_DESC_FOR_MANAGER} from './project-progress-status.constant';
import {STATUS_DESC_FOR_APPLICANT} from './project-progress-status.constant';
import {UserRole} from '../../../../shared/models/user.model';
import {ProjectsService} from '../../../../shared/services/projects.service';

@Component({
  selector: 'app-project-progress-status',
  templateUrl: './project-progress-status.component.html',
  styleUrls: [ './project-progress-status.component.scss' ],
  providers: [ NgbPopoverConfig ]
})

export class ProjectProgressStatusComponent implements OnInit {

  @Input() role: UserRole = UserRole.Applicant;  //default to be Applicant
  @Input() applyId: string;

  statusInfo: any = {};
  loading: boolean = true;

  constructor(config: NgbPopoverConfig,
    private projectsService: ProjectsService) {
    config.placement = 'bottom';
    config.container = 'body';
    config.triggers = 'hover';
  }

  ngOnInit() {
    this.getProjectStatusByApplyId(this.applyId);
  }

  getProjectStatusByApplyId(applyId) {
    this.loading = true;
    this.projectsService.fetchLatestProjectStatus(applyId)
      .finally(() => this.loading = false)
      .subscribe(
        res => {
          this.statusInfo = res.data;
        }
      );
  }

  get progress() {
    /*
     一共4个节点，3个steps，每个step占比1/3
     对于某个具体的step，里面包含的stage数目不同。假设step1（申报项目）包含3个stage，step2（价值假说）包含4个stage。
     若当前处于step2的第二个stage（共4个stages），在本step中的占比为1/4, 在全局中的占比为(1/3)*(1/4)，
     最终的结果,需要再加上step1的占比，结果为:（1/3）+(1/4)(1/3)
    * */
    const status = this.statusInfo.projectAction;
    if (!status) { return 0; }

    const matches = this.statusInfo.projectAction.toString().split('');
    const code = Number(matches[ 0 ]);
    const subCode = Number(matches[ 1 ]);

    const progressWithStep = (1 / totalSteps) * (subCode / stagesPerStep[ `step_${code}` ]);

    return 100 * (this.getAccumulateProgress(code) + progressWithStep);
  }

  getAccumulateProgress(code) {
    return (code - 1) / totalSteps;
  }

  get description() {
    const action = this.statusInfo.projectAction;
    if (!action) { return ''; }
    switch (this.role) {
      case UserRole.Manager:
        return STATUS_DESC_FOR_MANAGER[action] || '';
      case UserRole.Applicant:
        const rawText = (STATUS_DESC_FOR_APPLICANT[action] || '').replace('XXXX', `: ${this.statusInfo.actionData}`);
        let desc = rawText;
        if (rawText.indexOf('(') > -1) {
          const matches = /(.*)\((.*)\)/.exec(rawText);
          desc = `${matches[1]}<div>(${matches[2]})</div>`.replace('XXXX', `: ${this.statusInfo.actionData}`);
        }
        return desc;
      default:
        return '';
    }
  }

  get actionData() {
    let actionData = this.statusInfo.actionData;
    return actionData ? JSON.parse(actionData).comment : '';
  }
}
