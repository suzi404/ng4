import {PROJECT_STATUSES} from '../../../../shared/constants/project.constant';

export const totalSteps: number = Object.keys(PROJECT_STATUSES).length - 1;

const stageNumberOfStep1: number = Object.keys(PROJECT_STATUSES.project_submission).length;
const stageNumberOfStep2: number = Object.keys(PROJECT_STATUSES.value_hypothesis).length;
const stageNumberOfStep3: number = Object.keys(PROJECT_STATUSES.ground_plan).length;

export const stagesPerStep = {
  step_1: stageNumberOfStep1,
  step_2: stageNumberOfStep2,
  step_3: stageNumberOfStep3,
};

export const totalStages: number = stageNumberOfStep1 + stageNumberOfStep2 + stageNumberOfStep3;


export const STATUS_DESC_FOR_MANAGER = {
  111: '内部审核中',
  112: '内部审核中',
  113: '内部审核中',
  114: '内部审核中',
  119: '内部审核中',

  121: '申请待审核',
  122: '申请待审核',
  129: '申请待审核',

  131: '申请已通过',
  139: '申请已通过',

  211: '工作坊',
  212: '工作坊',
  213: '工作坊',
  219: '工作坊',

  221: '材料已提交',
  229: '材料已提交',

  231: '审核已通过',
  232: '审核已通过',
  239: '审核已通过',

  249: 'MVP会议评审',
};


export const STATUS_DESC_FOR_APPLICANT = {
  111: '内部审核中',
  112: '内部审核中(更换审核人)',
  113: '申请驳回',
  114: '内部审核中(要求更换审核人)',
  119: '项目已暂停',


  121: '待流信办审核',
  122: '待流信办审核',
  129: '项目已暂停',

  131: '申请已通过(等待工作坊邀请)',
  132: '申请已通过(等待工作坊邀请)',
  139: '项目已暂停',

  211: '参加工作坊(2017年07年02日－2017年07年04日)',
  212: '提交初审评审会议材料(剩余时间：16天44时5分0秒)',
  213: '提交初审评审会议材料(剩余时间：0天0时0分0秒)',
  219: '项目已暂停',

  221: '提交初审评审会议材料(流信办审核中)',
  222: '提交初审评审会议材料(流信办审核中)',
  229: '项目已暂停',

  231: '审核通过(等待初审会议通知)',
  232: '审核通过(请于2017年07年02日参加初审会议评审)',
  239: '项目已暂停',

  249: '项目已暂停',
};
