import { TestBed, inject } from '@angular/core/testing';
import {totalSteps} from './project-progress-status.constant';
import {totalStages} from './project-progress-status.constant';


describe('>> project-progress-status.constant.spec', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
    });
  });

  it('should be created', () => {
    expect(totalSteps).toBe(3);
    expect(totalStages).toBe(7);
  });
});
