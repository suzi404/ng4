import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpModule, ConnectionBackend } from '@angular/http';
import { Observable } from 'rxjs/Rx';

import { ProjectProgressStatusComponent } from './project-progress-status.component';
import {ProjectsService} from '../../../../shared/services/projects.service';
import {HttpInterceptorService} from '../../../../shared/services/http-interceptor.service';
import {AlertService} from '../../../../shared/services/alert.service';
import {AuthenticationService} from '../../../../shared/services/authentication.service';
import {UserRole} from '../../../../shared/models/user.model';
import {LoadingComponent} from '../../../../shared/components/loading/loading.component';
import {NoDataComponent} from '../../../../shared/components/no-data/no-data.component';

const mockProjectStatusInfo = require('mockServer/resources/projectStatus');

describe('ProjectProgressStatusComponent', () => {
  let component: ProjectProgressStatusComponent;
  let fixture: ComponentFixture<ProjectProgressStatusComponent>;
  let projectsService: ProjectsService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpModule,
        NgbModule.forRoot(),
      ],
      declarations: [
        ProjectProgressStatusComponent,
        LoadingComponent,
        NoDataComponent,
      ],
      providers: [
        AlertService,
        AuthenticationService,
        HttpInterceptorService,
        ProjectsService,
        ConnectionBackend,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectProgressStatusComponent);
    component = fixture.componentInstance;
    projectsService = fixture.debugElement.injector.get(ProjectsService);
    spyOn(projectsService, 'fetchLatestProjectStatus').and.returnValue(Observable.of(mockProjectStatusInfo));
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  describe('>> test progress', () => {

    it('should get 11.11 given status of 112', () => {
      component.statusInfo.projectAction = 112;
      expect(component.progress).toBeCloseTo(11.11);
    });

    it('should get 33.33 given status of 139', () => {
      component.statusInfo.projectAction = 139;
      expect(component.progress).toBeCloseTo(33.33);
    });

    it('should get 44.44 given status of 219', () => {
      component.statusInfo.projectAction = 219;
      expect(component.progress).toBeCloseTo(44.44);
    });
  });

  describe('>>> test description', () => {
    describe('>> manager role', () => {
      beforeEach(() => {
        component.role = UserRole.Manager;
      });

      it('should get "内部审核中" given status 111', () => {
        component.statusInfo.projectAction = 111;
        expect(component.description).toBe('内部审核中');
      });

      it('should get "申请待审核" given status 121', () => {
        component.statusInfo.projectAction = 121;
        expect(component.description).toBe('申请待审核');
      });

      it('should get "申请已通过" given status 131', () => {
        component.statusInfo.projectAction = 131;
        expect(component.description).toBe('申请已通过');
      });

      it('should get "工作坊" given status 211', () => {
        component.statusInfo.projectAction = 211;
        expect(component.description).toBe('工作坊');
      });

      it('should get "材料已提交" given status 221', () => {
        component.statusInfo.projectAction = 221;
        expect(component.description).toBe('材料已提交');
      });

      it('should get "审核已通过" given status 231', () => {
        component.statusInfo.projectAction = 231;
        expect(component.description).toBe('审核已通过');
      });

      it('should get "MVP会议评审" given status 249', () => {
        component.statusInfo.projectAction = 249;
        expect(component.description).toBe('MVP会议评审');
      });
    });

    describe('>> applicant role', () => {
      beforeEach(() => {
        component.role = UserRole.Applicant;
      });

      it('should get "内部审核中(更换审核人)" given status 112', () => {
        component.statusInfo.projectAction = 112;
        expect(component.description).toBe('内部审核中<div>(更换审核人)</div>');
      });

      it('should get "待流信办审核" given status 121', () => {
        component.statusInfo.projectAction = 121;
        expect(component.description).toBe('待流信办审核');
      });

      it('should get "申请已通过（等待工作坊邀请）" given status 131', () => {
        component.statusInfo.projectAction = 131;
        expect(component.description).toBe('申请已通过<div>(等待工作坊邀请)</div>');
      });

      it('should get "提交初审评审会议材料（流信办审核中）" given status 221', () => {
        component.statusInfo.projectAction = 221;
        expect(component.description).toBe('提交初审评审会议材料<div>(流信办审核中)</div>');
      });

      it('should get "审核通过（等待初审会议通知）" given status 231', () => {
        component.statusInfo.projectAction = 231;
        expect(component.description).toBe('审核通过<div>(等待初审会议通知)</div>');
      });

    });
  });
});
