import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';
import { Ng2PageScrollModule } from 'ng2-page-scroll';
import { NgStickyModule } from 'ng-sticky';

import { SharedModule } from '../../shared/shared.module';

import { ProjectsPageRoutingModule } from './projects-page-routing.module';
import { ProjectPageTempleteComponent } from './components/project-page-templete/project-page-templete.component';
import { InnovationCalendarComponent } from './components/innovation-calendar/innovation-calendar.component';

import { ApplicantProjectListComponent } from './applicant/applicant-project-list/applicant-project-list.component';
import { ProjectItemComponent } from './applicant/applicant-project-list/project-item/project-item.component';

import { ManagerComponent } from './manager/manager.component';
import { ManagerProjectListComponent } from './manager/manager-project-list/manager-project-list.component';

import { ProjectsService } from '../../shared/services/projects.service';
import { ManagerProjectDetailComponent } from './manager/manager-project-detail/manager-project-detail.component';
import { ProjectOwnerComponent } from './components/project-owner/project-owner.component';
import { ProjectProgressStatusComponent } from './components/project-progress-status/project-progress-status.component';

import { SuspendProjectComponent } from './components/modals/suspend-project/suspend-project.component';
import { ProjectInfoComponent } from './components/project-info/project-info.component';
import { RejectProjectModalComponent } from './components/modals/reject-project-modal/reject-project-modal.component';
import { ProjectInfoWithNavComponent } from './components/project-info-with-nav/project-info-with-nav.component';
import { ProjectStatusComponent } from './applicant/project-status/project-status.component';

import { UserSelectorComponent } from '../../shared/components/user-selector/user-selector.component';
import { ReassignSupervisorComponent } from './components/modals/reassign-supervisor/reassign-supervisor.component';
import { ProjectMaterialReviewComponent } from './manager/manager-project-detail/project-material-review/project-material-review.component';
import { ItofficerProjectListComponent } from './itofficer/itofficer-project-list/itofficer-project-list.component';
import { OperationalTableComponent } from './manager/manager-project-list/operational-table/operational-table.component';
import { ItofficerAssignPersonsComponent } from './components/modals/itofficer-assign-persons/itofficer-assign-persons.component';

@NgModule({
  imports: [
    CommonModule,
    ProjectsPageRoutingModule,
    NgbModule.forRoot(),
    SharedModule,
    FormsModule,
    Ng2PageScrollModule,
    NgStickyModule,
  ],
  declarations: [
    ApplicantProjectListComponent,
    ProjectItemComponent,
    ManagerProjectListComponent,
    ManagerComponent,
    ProjectPageTempleteComponent,
    InnovationCalendarComponent,
    ManagerProjectDetailComponent,
    ProjectOwnerComponent,
    ProjectProgressStatusComponent,
    SuspendProjectComponent,
    ProjectInfoComponent,
    RejectProjectModalComponent,
    ProjectInfoWithNavComponent,
    ProjectStatusComponent,
    ReassignSupervisorComponent,
    ProjectMaterialReviewComponent,
    ItofficerProjectListComponent,
    OperationalTableComponent,
    ItofficerAssignPersonsComponent
  ],
  entryComponents: [
    SuspendProjectComponent,
    RejectProjectModalComponent,
    ReassignSupervisorComponent,
    ItofficerAssignPersonsComponent,
  ],
  exports: [
    ProjectInfoComponent,
    ProjectInfoWithNavComponent,
  ],
  providers: [ProjectsService]
})
export class ProjectsPageModule {}
