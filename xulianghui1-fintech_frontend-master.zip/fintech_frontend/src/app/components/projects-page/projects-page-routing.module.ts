import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ApplicantProjectListComponent } from './applicant/applicant-project-list/applicant-project-list.component';
import { ManagerComponent } from './manager/manager.component';
import { ManagerProjectDetailComponent } from './manager/manager-project-detail/manager-project-detail.component';
import { ProjectStatusComponent } from './applicant/project-status/project-status.component';
import { ItofficerProjectListComponent } from './itofficer/itofficer-project-list/itofficer-project-list.component';

const routes: Routes = [
  {
    path: 'managed',
    children: [
      { path: '', component: ManagerComponent },
      { path: ':applyId', component: ManagerProjectDetailComponent }
    ]
  },
  {
    path: 'applied',
    children: [
      { path: '', component: ApplicantProjectListComponent },
      { path: 'status/:id', component: ProjectStatusComponent }
    ]
  },
  {
    path: 'assigned',
    children: [
      { path: '', component: ItofficerProjectListComponent },
    ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProjectsPageRoutingModule {}
