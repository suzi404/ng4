export class Project {
  selected?: boolean;
  applyId: string;
  projectName: string;
  ystName: string;
  ystOrgName: string;
}
