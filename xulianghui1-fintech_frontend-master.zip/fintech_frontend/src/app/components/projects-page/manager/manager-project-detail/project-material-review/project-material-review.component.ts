import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {ProjectsService} from '../../../../../shared/services/projects.service';

@Component({
  selector: 'app-project-material-review',
  templateUrl: './project-material-review.component.html',
  styleUrls: ['./project-material-review.component.scss']
})
export class ProjectMaterialReviewComponent implements OnInit {

  @Input() applyId: string;
  @Output() switchTab = new EventEmitter<any>();

  loading = true;

  applyMaterialDto= {};
  worthMaterialDto= {
    projectFiles: {}
  };

  constructor(
    private projectsService: ProjectsService
  ) { }

  ngOnInit() {
    this.getProjectMaterials();
  }

  getProjectMaterials() {
    this.loading = true;
    this.projectsService.fetchProjectMaterials(this.applyId)
      .finally(() => this.loading = false)
      .subscribe(
        res => {
          this.applyMaterialDto = res.data.applyMaterialDto;
          this.worthMaterialDto = res.data.worthMaterialDto;
        },
        error => console.debug('get project materials failure', error)
      );
  }

  viewProjectDetail() {
    this.switchTab.emit('tab-project-detail');
  }

}
