import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpModule, ConnectionBackend } from '@angular/http';
import { Observable } from 'rxjs/Rx';

import { ProjectMaterialReviewComponent } from './project-material-review.component';
import {ProjectsService} from '../../../../../shared/services/projects.service';
import {HttpInterceptorService} from '../../../../../shared/services/http-interceptor.service';
import {AlertService} from '../../../../../shared/services/alert.service';
import {AuthenticationService} from '../../../../../shared/services/authentication.service';
import {LoadingComponent} from '../../../../../shared/components/loading/loading.component';
import {NoDataComponent} from '../../../../../shared/components/no-data/no-data.component';

const mockProjectMaterials = require('mockServer/resources/projectMaterials');

describe('ProjectMaterialReviewComponent', () => {
  let component: ProjectMaterialReviewComponent;
  let fixture: ComponentFixture<ProjectMaterialReviewComponent>;
  let projectsService: ProjectsService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpModule,
      ],
      declarations: [
        ProjectMaterialReviewComponent,
        LoadingComponent,
        NoDataComponent,
      ],
      providers: [
        HttpInterceptorService,
        AuthenticationService,
        AlertService,
        ProjectsService,
        ConnectionBackend,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectMaterialReviewComponent);
    projectsService = fixture.debugElement.injector.get(ProjectsService);
    component = fixture.componentInstance;
    spyOn(projectsService, 'fetchProjectMaterials').and.returnValue(Observable.of(mockProjectMaterials));
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
