import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpModule, ConnectionBackend } from '@angular/http';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Rx';
import { Ng2PageScrollModule } from 'ng2-page-scroll';
import { NgStickyModule } from 'ng-sticky';
import { MockComponent } from 'ng2-mock-component';

import {SharedModule} from '../../../../shared/shared.module';
import { ManagerProjectDetailComponent } from './manager-project-detail.component';
import {ProjectPageTempleteComponent} from '../../components/project-page-templete/project-page-templete.component';

import {ProjectsService} from '../../../../shared/services/projects.service';
import {HttpInterceptorService} from '../../../../shared/services/http-interceptor.service';
import {AlertService} from '../../../../shared/services/alert.service';
import {UserService} from '../../../../shared/services/user.service';

const mockProjectDetailInfo = require('mockServer/resources/projectDetail');

const getActions = (component, compiled, fixture, status) => {
  component.project.status = status;
  fixture.detectChanges();
  const text = compiled.querySelector('.dropdown-menu').textContent.trim();
  return (text.length === 0) ? [] : text.split(/\s+/);
};

describe('ManagerProjectDetailComponent', () => {
  let component: ManagerProjectDetailComponent;
  let fixture: ComponentFixture<ManagerProjectDetailComponent>;
  let projectsService: ProjectsService;
  let compiled: HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        HttpModule,
        NgbModule.forRoot(),
        SharedModule,
        Ng2PageScrollModule,
        NgStickyModule,
      ],
      declarations: [
        ManagerProjectDetailComponent,
        ProjectPageTempleteComponent,
        MockComponent({
          selector: 'app-project-owner',
          inputs: ['owner']
        }),
        MockComponent({
          selector: 'app-project-progress-status',
          inputs: ['applyId', 'role']
        }),
        MockComponent({
          selector: 'app-project-material-review',
          inputs: ['applyId']
        }),
        MockComponent({
          selector: 'app-project-info-with-nav',
          inputs: ['project']
        }),
      ],
      providers: [
        HttpInterceptorService,
        ConnectionBackend,
        UserService,
        ProjectsService,
        AlertService,
        {
          provide: ActivatedRoute,
          useValue: {
            params: Observable.of({applyId: 123})
          }
        }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagerProjectDetailComponent);
    component = fixture.componentInstance;
    compiled = fixture.debugElement.nativeElement;
    projectsService = fixture.debugElement.injector.get(ProjectsService);
    spyOn(projectsService, 'getProjectDetail').and.returnValue(Observable.of(mockProjectDetailInfo));
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should has 暂停项目 and 更换审核人 action if projectAction is 111', () => {
    let matches = getActions(component, compiled, fixture, 111);
    expect(matches.length).toBe(2);
    expect(matches[0]).toBe('更换审核人');
    expect(matches[1]).toBe('暂停项目');
  });

  it('should has 暂停项目 action if projectAction is 112', () => {
    let matches = getActions(component, compiled, fixture, 112);
    expect(matches.length).toBe(1);
    expect(matches[0]).toBe('暂停项目');
  });

  it('should has 暂停项目 action if projectAction is 113', () => {
    let matches = getActions(component, compiled, fixture, 113);
    expect(matches.length).toBe(1);
    expect(matches[0]).toBe('暂停项目');
  });

  it('should has 暂停项目 action if projectAction is 114', () => {
    let matches = getActions(component, compiled, fixture, 114);
    expect(matches.length).toBe(1);
    expect(matches[0]).toBe('暂停项目');
  });

  it('should has 暂停项目 action if projectAction is 119', () => {
    let matches = getActions(component, compiled, fixture, 119);
    expect(matches.length).toBe(0);
  });

  it('should has 暂停项目 action if projectAction is 121', () => {
    let matches = getActions(component, compiled, fixture, 121);
    expect(matches.length).toBe(4);
    expect(matches[0]).toBe('更换审核人');
    expect(matches[1]).toBe('暂停项目');
    expect(matches[2]).toBe('通过审核');
    expect(matches[3]).toBe('驳回审核');
  });

  it('should has 暂停项目 action if projectAction is 129', () => {
    let matches = getActions(component, compiled, fixture, 129);
    expect(matches.length).toBe(0);
  });

  it('should has 暂停项目 action if projectAction is 131', () => {
    let matches = getActions(component, compiled, fixture, 131);
    expect(matches.length).toBe(2);
    expect(matches[0]).toBe('暂停项目');
    expect(matches[1]).toBe('发送工作坊邀请');
  });

  it('should has 暂停项目 action if projectAction is 139', () => {
    let matches = getActions(component, compiled, fixture, 139);
    expect(matches.length).toBe(0);
  });
});
