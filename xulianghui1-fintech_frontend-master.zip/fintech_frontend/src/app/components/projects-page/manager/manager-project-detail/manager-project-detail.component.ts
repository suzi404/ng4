import { Component, OnInit, Input } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Observable } from 'rxjs/Rx';
import { NgbTabChangeEvent } from '@ng-bootstrap/ng-bootstrap';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { ProjectsService } from '../../../../shared/services/projects.service';
import { codeConstant } from '../../../../shared/constants/code.constant';
import {AlertService} from '../../../../shared/services/alert.service';
import {SuspendProjectComponent} from '../../components/modals/suspend-project/suspend-project.component';
import {RejectProjectModalComponent} from '../../components/modals/reject-project-modal/reject-project-modal.component';
import {PROJECT_STATUSES} from '../../../../shared/constants/project.constant';
import {UserRole} from '../../../../shared/models/user.model';

@Component({
  selector: 'app-manager-project-detail',
  templateUrl: './manager-project-detail.component.html',
  styleUrls: [ './manager-project-detail.component.scss' ]
})
export class ManagerProjectDetailComponent implements OnInit {
  @Input() project: any;

  applyId: string;
  owner: any;

  loading: boolean = true;
  currentTab: string = 'tab-project-detail';

  projectStatuses = PROJECT_STATUSES;
  userRole: UserRole = UserRole.Manager;

  constructor(private route: ActivatedRoute,
    private router: Router,
    private alertService: AlertService,
    private modalService: NgbModal,
    private projectsService: ProjectsService) {
  }

  ngOnInit() {
    this.changeAssessor = this.changeAssessor.bind(this);
    this.approve = this.approve.bind(this);
    this.sendWorkshopInvitation = this.sendWorkshopInvitation.bind(this);

    this.route.params.subscribe(params => {
      this.applyId = params[ 'applyId' ].toString();
      this.getProjectByApplyId(this.applyId);
    });
  }

  getProjectByApplyId(applyId) {
    this.loading = true;
    this.projectsService.getProjectDetail(this.applyId)
      .finally(() => this.loading = false)
      .subscribe(
        res => {
          if (res.code === codeConstant.SUCCESS && res.data) {
            this.project = res.data;
            this.project.status = this.project.projectInfo.projectAction;
            this.owner = this.getProjectOwner(this.project);
          }
        },
        error => console.debug('get project detail failure', error)
      );
  }

  handleTabChange($event: NgbTabChangeEvent) {
    this.currentTab = $event.nextId;
  }

  handleSwitchTab(tab) {
    this.currentTab = tab;
  }

  getProjectOwner(project: any): any {
    let person = project.projectPersons.filter((item) => {
      return item.ystId === project.projectInfo.ystId;
    })[ 0 ];

    return {
      ystName: person.ystName,
      ystId: person.ystId,
      telephone: person.telephone,
      email: person.email,
    };
  }

  canSuspend() {
    return this.project.status % 10 !== 9;
  }

  changeAssessor(): void {
    this.projectsService.changeAssessors([this.applyId])
      .subscribe(
        res => {
          console.debug('change assessors success', res);
          if (res.code === codeConstant.SUCCESS) {
            this.alertService.success('操作成功！');
            this.fetchUpdatedProject();
          } else {
            this.alertService.error('操作失败，请重试');
          }
        },
        err => {
          console.debug('change assessors failure', err);
          this.alertService.error('操作失败，请重试');
        }
      );
  }

  openSuspendProjectModal() {
    const modalRef = this.modalService.open(SuspendProjectComponent);
    modalRef.componentInstance.projectApplyIds = [this.applyId];
    modalRef.result
      .then(() => {
        this.fetchUpdatedProject();
      })
      .catch(() => {});
  }

  openRejectProjectModal() {
    const modalRef = this.modalService.open(RejectProjectModalComponent);
    modalRef.componentInstance.projectApplyIds = [this.applyId];
    modalRef.result
      .then(() => {
        this.fetchUpdatedProject();
      })
      .catch(() => {});
  }

  approve() {
    this.alertService.success('approved'); //TODO: need api support
    this.fetchUpdatedProject();
  }

  sendWorkshopInvitation() {
    this.alertService.success('sended workshop invitation');   //TODO: need api support
    this.fetchUpdatedProject();
  }

  fetchUpdatedProject() {
    console.log('fetching latest project detail info...');
    this.getProjectByApplyId(this.applyId);
  }
}
