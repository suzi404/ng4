import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpModule, ConnectionBackend } from '@angular/http';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { MockComponent } from 'ng2-mock-component';
import 'rxjs/add/observable/of';

import { ProjectPageTempleteComponent } from '../components/project-page-templete/project-page-templete.component';
import { InnovationCalendarComponent } from '../components/innovation-calendar/innovation-calendar.component';

import { ManagerComponent } from './manager.component';
import { ManagerProjectListComponent } from './manager-project-list/manager-project-list.component';

import { NoDataComponent } from '../../../shared/components/no-data/no-data.component';
import { LoadingComponent } from '../../../shared/components/loading/loading.component';
import { HasPermissionDirective } from '../../../shared/directives/has-permission.directive';
import { NeedConfirmDirective } from '../../../shared/directives/need-confirm.directive';

import { ProjectsService } from '../../../shared/services/projects.service';
import { HttpInterceptorService } from '../../../shared/services/http-interceptor.service';
import { AuthenticationService } from '../../../shared/services/authentication.service';
import { AlertService } from '../../../shared/services/alert.service';
import { UserService } from '../../../shared/services/user.service';

describe('ManagerComponent', () => {
  let component: ManagerComponent;
  let fixture: ComponentFixture<ManagerComponent>;
  let projectsService: ProjectsService;
  let stubProjectListSuccessResponse = {
    code: '0',
    message: '查询成功',
    data: {
      pageIndex: 0,
      pageSize: 10,
      total: 1,
      data: [
        {
          projectName: '金融科技创新平台改进',
          ystId: '098581',
          ystName: '顾玉华',
          projectId: '1111111111'
        }
      ]
    }
  };

  beforeEach(
    async(() => {
      TestBed.configureTestingModule({
        imports: [HttpModule, NgbModule.forRoot(), FormsModule],
        declarations: [
          ProjectPageTempleteComponent,
          InnovationCalendarComponent,
          ManagerComponent,
          NoDataComponent,
          LoadingComponent,
          HasPermissionDirective,
          NeedConfirmDirective,
          MockComponent({
            selector: 'app-manager-project-list',
            inputs: ['title']
          })
        ],
        providers: [
          { provide: ActivatedRoute },
          HttpInterceptorService,
          ConnectionBackend,
          ProjectsService,
          AuthenticationService,
          ConnectionBackend,
          AlertService,
          UserService
        ]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagerComponent);
    component = fixture.componentInstance;
    projectsService = fixture.debugElement.injector.get(ProjectsService);
    // TODO: why should I spyOn projectService not only in manager-project-list but also in manager component?
    spyOn(projectsService, 'getProjectList').and.returnValue(
      Observable.of(stubProjectListSuccessResponse)
    );
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
