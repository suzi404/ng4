import { Component, OnInit } from '@angular/core';
import { ProjectsService } from '../../../../shared/services/projects.service';
import { codeConstant } from '../../../../shared/constants/code.constant';
import {
  projectTypeConstant,
  projectStatusConstant
} from '../../../../shared/constants/project.constant';
import { Project } from '../../types/Project';
import { AlertService } from '../../../../shared/services/alert.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { SuspendProjectComponent } from '../../components/modals/suspend-project/suspend-project.component';
import { OperationalTableComponent } from './operational-table/operational-table.component';

@Component({
  selector: 'app-manager-project-list',
  templateUrl: './manager-project-list.component.html',
  styleUrls: ['./manager-project-list.component.scss']
})
export class ManagerProjectListComponent implements OnInit {
  projects: Project[] = [];
  loading: boolean = true;
  readyForCheck: string = projectStatusConstant.readyForCheck;
  internalChecking: string = projectStatusConstant.internalChecking;
  approved: string = projectStatusConstant.approved;

  constructor(
    private projectsService: ProjectsService,
    private alertService: AlertService,
    private modalService: NgbModal
  ) {}

  ngOnInit() {
    // this.initProjects();
    // this.changeAssessor = this.changeAssessor.bind(this);
    // this.changeSelectedAssessors = this.changeSelectedAssessors.bind(this);
  }

  initProjects(): void {
    let me = this;
    me.projectsService
      .getProjectList(
        projectTypeConstant.managed,
        projectStatusConstant.internalChecking
      )
      .subscribe(
        res => {
          if (res.code === codeConstant.SUCCESS && res.data) {
            me.projects = res.data.data;
          }
        },
        err => {},
        () => {
          me.loading = false;
        }
      );
  }

  selectAllRows(e): void {
    let isSelectAllChecked: boolean = e.target.checked;
    this.projects.map(project => {
      project.selected = isSelectAllChecked;
    });
  }

  changeAssessor(projectApplyId): void {
    this.changeAssessors([projectApplyId]);
  }

  changeAssessors(projectApplyIds): void {
    let me = this;
    if (!projectApplyIds.length) {
      return;
    }

    me.projectsService.changeAssessors(projectApplyIds).subscribe(
      res => {
        if (res.code === codeConstant.SUCCESS) {
          me.alertService.success('操作成功！');
          me.initProjects();
        } else {
          me.alertService.error('操作失败，请重试');
        }
      },
      err => {
        me.alertService.error('操作失败，请重试');
      }
    );
  }

  changeSelectedAssessors(): void {
    this.changeAssessors(this.selectedProjectIds());
  }

  selectedProjectIds(): Array<string> {
    return this.projects
      .filter(project => {
        return project.selected === true;
      })
      .map(project => {
        return project.applyId;
      });
  }

  markProject(project): void {
    let me = this;
    project.mark = !project.mark;
    let mark: string = project.mark ? '1' : '0';
    me.projectsService.markProject(project.applyId, mark).subscribe(
      res => {
        if (res.code === codeConstant.SUCCESS) {
          me.alertService.success('切换项目标记成功！');
        } else {
          me.alertService.error('切换项目标记失败，请重试');
        }
      },
      err => {
        me.alertService.error('切换项目标记失败，请重试');
      }
    );
  }

  removeProjects(projectApplyIds): void {
    let me = this;
    me.projects = me.projects.filter(project => {
      return projectApplyIds.indexOf(project.applyId) < 0;
    });
  }

  openSuspendProjectModal(projectApplyId?) {
    let me = this;
    if (!projectApplyId && me.selectedProjectIds().length < 1) {
      return;
    }

    const modalRef = me.modalService.open(SuspendProjectComponent);
    let selectedProjectApplyIds = projectApplyId
      ? [projectApplyId]
      : me.selectedProjectIds();
    modalRef.componentInstance.projectApplyIds = selectedProjectApplyIds;
    modalRef.result
      .then(() => {
        me.removeProjects(selectedProjectApplyIds);
      })
      .catch(() => {});
  }

  hasProjectAction(project, codes): boolean {
    return codes.find(code => {
      return project.projectAction === code;
    });
  }
}
