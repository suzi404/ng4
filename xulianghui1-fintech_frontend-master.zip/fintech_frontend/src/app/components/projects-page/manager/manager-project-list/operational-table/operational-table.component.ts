import { Component, OnInit, Input } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { isArray } from 'lodash';
import { ActivatedRoute } from '@angular/router';

import { UserService } from 'app/shared/services/user.service';
import { ProjectsService } from 'app/shared/services/projects.service';
import { AlertService } from 'app/shared/services/alert.service';
import { SuspendProjectComponent } from '../../../components/modals/suspend-project/suspend-project.component';
import {
  projectTypeConstant,
  projectStatusConstant
} from 'app/shared/constants/project.constant';

import { exceptionCodeConstant } from 'shared/constants/code.constant';

import { RejectProjectModalComponent } from '../../../components/modals/reject-project-modal/reject-project-modal.component';
import { ConfirmModalComponent } from 'shared/components/confirm-modal/confirm-modal.component'


@Component({
  selector: 'app-operational-table',
  templateUrl: './operational-table.component.html',
  styleUrls: ['./operational-table.component.scss']
})
export class OperationalTableComponent implements OnInit {
  @Input() projects: any[] = [];
  @Input() operationAlign: string = 'left';
  @Input() avaiableActions: any[] = [];
  @Input() projectStatus: any = projectStatusConstant.internalChecking;
  loading: boolean = true;
  showApprovedDate: boolean = false;

  constructor(
    private userService: UserService,
    private projectsService: ProjectsService,
    private modalService: NgbModal,
    private alertService: AlertService
  ) {}

  ngOnInit() {
    this.loadProjects();
    this.adjustTableStyles();
    this.changeAssessor = this.changeAssessor.bind(this);
    this.changeSelectedAssessors = this.changeSelectedAssessors.bind(this);
  }

  adjustTableStyles(): void {
    switch(this.projectStatus) {
      case projectStatusConstant.approved:
        this.showApprovedDate = true;
        break;
    }
  }

  loadProjects(): void {
    this.loading = true;
    this.projectsService
      .getProjectList(projectTypeConstant.managed, this.projectStatus)
      .subscribe(
        res => {
          this.projects = res.data.data;
        },
        err => {},
        () => {
          this.loading = false;
        }
      );
  }

  selectAllRows(e): void {
    let isSelectAllChecked = e.target.checked;
    this.projects.forEach(project => {
      project.selected = isSelectAllChecked;
    });
  }

  get selectedProjectIds() {
    return this.projects
      .filter(project => {
        return project.selected === true;
      })
      .map(project => {
        return project.applyId;
      });
  }

  // the situation of projectAction:
  // suspend-action doesn't show in 119,129,139
  // change-action doesn't show in 112, 114
  // reject-action doesn't show in 113
  isProjectActionNotInExcludedStatus(projectAction, codes): boolean {
    return !codes.some(x => x === projectAction);
  }

  markProject(project): void {
    project.mark = !project.mark;
    let mark = project.mark ? '1' : '0';
    this.projectsService.markProject(project.applyId, mark).subscribe(
      res => {
        this.alertService.success('切换项目标记成功！');
      },
      err => {
        this.alertService.error('切换项目标记失败，请重试');
        // roll back mark value.
        project.mark = !project.mark;
      }
    );
  }

  openSuspendProjectModal(projectApplyIds) {
    let appliedIds = isArray(projectApplyIds)
      ? projectApplyIds
      : [projectApplyIds];
    if (appliedIds.length === 0) {
      return;
    }

    const modalRef = this.modalService.open(SuspendProjectComponent);
    modalRef.componentInstance.projectApplyIds = appliedIds;
    modalRef.result
      .then(() => {
        console.log('==== selectedProjectApplyIds:', appliedIds);
        this.loadProjects();
      })
      .catch(() => {});
  }

  openRejectProjectModal(projectApplyIds) {
    let appliedIds = isArray(projectApplyIds)
      ? projectApplyIds
      : [projectApplyIds];
    if (appliedIds.length === 0) {
      return;
    }

    const modalRef = this.modalService.open(RejectProjectModalComponent);
    modalRef.componentInstance.projectApplyIds = appliedIds;
    modalRef.result
      .then(() => {
        this.loadProjects();
      });
  }

  openApproveProjectModal(projectApplyIds){
    let appliedIds = isArray(projectApplyIds)? projectApplyIds: [ projectApplyIds ];
    if(appliedIds.length === 0){
      return;
    }

    const modalRef = this.modalService.open(ConfirmModalComponent);
    modalRef.result.then(()=>{
      this.projectsService.approveProjects(appliedIds).subscribe(res=>{
        this.alertService.success('操作成功');
        this.loadProjects();
      }, err =>{
        if (err.code === exceptionCodeConstant.approve_half_success) {
          this.alertService.error(`部分项目执行失败: [${err.data.toString()}]`);
        } else {
          this.alertService.error('通过项目执行失败，请重试');
        }
      });
    }).catch(err => {
      console.log('-=err:', err);
    });
  }

  // there are 3 steps validation:
  // 1: is action name passed in html file, which will be saved as avaiableActions.
  // 2: is projectInfo passed in and the property "projectAction" is not included in related action-situation.
  // 3: is current user granted with permission code for each action accordingly.
  needToShowApproveAction(projectInfo?) {
    return (
      this.avaiableActions.some(x => x === 'approve') &&
      (!projectInfo ||
        this.isProjectActionNotInExcludedStatus(projectInfo.projectAction, [])) &&
      (this.projectStatus === projectStatusConstant.readyForCheck &&
        this.userService.hasOneDefined(['600112']))
    );
  }

  // same as above
  // reject-action doesn't show when projectAction is 113
  needToShowRejectAction(projectInfo?) {
    return (
      this.avaiableActions.some(x => x === 'reject') &&
      (!projectInfo ||
        this.isProjectActionNotInExcludedStatus(projectInfo.projectAction, [113])) &&
      (this.projectStatus === projectStatusConstant.readyForCheck &&
        this.userService.hasOneDefined(['600113']))
    );
  }

  // same as above
  // suspend-action doesn't show when projectAction is 119, 129, 139
  needToShowSuspendAction(projectInfo?) {
    return (
      this.avaiableActions.some(x => x === 'suspend') &&
      (!projectInfo ||
        this.isProjectActionNotInExcludedStatus(projectInfo.projectAction, [
          119,
          129,
          139
        ])) &&
      ((this.projectStatus === projectStatusConstant.internalChecking &&
        this.userService.hasOneDefined(['CAN_SUSPEND_PROJECT'])) ||
        (this.projectStatus === projectStatusConstant.readyForCheck &&
          this.userService.hasOneDefined(['600111'])) ||
          (this.projectStatus === projectStatusConstant.approved))
    );
  }

  // same as above
  // change-action doesn't show when projectAction is 112, 114
  needToShowChangeAction(projectInfo?) {
    return (
      this.avaiableActions.some(x => x === 'change') &&
      (!projectInfo ||
        this.isProjectActionNotInExcludedStatus(projectInfo.projectAction, [112, 114])) &&
      ((this.projectStatus === projectStatusConstant.internalChecking &&
        this.userService.hasOneDefined(['600103'])) ||
        (this.projectStatus === projectStatusConstant.readyForCheck &&
          this.userService.hasOneDefined(['600114'])))
    );
  }

  // same as above
  // notify-workshop-action doesn't show when projectAction is 131
  needToShowNotifyWorkshopAction(projectInfo?) {
    return (
      this.avaiableActions.some(x => x === 'notify-workshop') &&
      (!projectInfo ||
        this.isProjectActionNotInExcludedStatus(projectInfo.projectAction, [131])) &&
      ((this.projectStatus === projectStatusConstant.approved &&
        this.userService.hasOneDefined(['600122'])))
    );
  }

  changeAssessor(projectApplyId): void {
    this.changeAssessors([projectApplyId]);
  }

  changeAssessors(projectApplyIds): void {
    let me = this;
    if (!projectApplyIds.length) {
      return;
    }

    me.projectsService.changeAssessors(projectApplyIds).subscribe(
      res => {
        me.alertService.success('操作成功！');
        me.loadProjects();
      },
      err => {
        if (err.code === exceptionCodeConstant.change_assessor_partial_success) {
          me.alertService.error(`部分项目操作失败: [${err.data.toString()}]`);
          me.loadProjects();
        } else {
          me.alertService.error('操作失败，请重试');
        }
      }
    );
  }

  changeSelectedAssessors(): void {
    this.changeAssessors(this.selectedProjectIds);
  }
}
