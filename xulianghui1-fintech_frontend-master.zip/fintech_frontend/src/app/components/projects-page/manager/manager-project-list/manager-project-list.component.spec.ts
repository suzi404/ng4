import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpModule, ConnectionBackend } from '@angular/http';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { MockComponent } from 'ng2-mock-component';
import 'rxjs/add/observable/of';

import { ManagerProjectListComponent } from './manager-project-list.component';
import { Project } from '../../types/Project';

import { NoDataComponent } from '../../../../shared/components/no-data/no-data.component';
import { LoadingComponent } from '../../../../shared/components/loading/loading.component';
import { OperationalTableComponent } from './operational-table/operational-table.component';
import { HasPermissionDirective } from '../../../../shared/directives/has-permission.directive';
import { NeedConfirmDirective } from '../../../../shared/directives/need-confirm.directive';

import { ProjectsService } from '../../../../shared/services/projects.service';
import { AuthenticationService } from '../../../../shared/services/authentication.service';
import { HttpInterceptorService } from '../../../../shared/services/http-interceptor.service';
import { AlertService } from '../../../../shared/services/alert.service';
import { UserService } from '../../../../shared/services/user.service';

describe('ManagerProjectListComponent', () => {
  let component: ManagerProjectListComponent;
  let fixture: ComponentFixture<ManagerProjectListComponent>;
  let projectsService: ProjectsService;

  let stubChangeAssessorsSuccessResponse = { code: '0', message: '更换审批人成功' };
  let stubProjects: Array<Project> = [
    {
      applyId: 'aaaa',
      projectName: '金融科技创新平台改进',
      ystName: '姓名',
      ystOrgName: '部门'
    },
    {
      applyId: 'bbbb',
      projectName: '金融科技创新平台改进',
      ystName: '姓名',
      ystOrgName: '部门'
    }
  ];
  let stubProjectListSuccessResponse = {
    code: '0',
    message: '查询成功',
    data: {
      pageIndex: 0,
      pageSize: 10,
      total: 2,
      data: stubProjects
    }
  };

  beforeEach(
    async(() => {
      TestBed.configureTestingModule({
        imports: [HttpModule, NgbModule.forRoot(), FormsModule],
        declarations: [
          MockComponent({
            selector: 'app-operational-table',
            inputs: ['avaiableActions', 'projectStatus', 'operationAlign']
          }),
          ManagerProjectListComponent,
          NoDataComponent,
          LoadingComponent,
          HasPermissionDirective,
          NeedConfirmDirective
        ],
        providers: [
          { provide: ActivatedRoute },
          HttpInterceptorService,
          ProjectsService,
          AuthenticationService,
          ConnectionBackend,
          AlertService,
          UserService
        ]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagerProjectListComponent);
    component = fixture.componentInstance;
    projectsService = fixture.debugElement.injector.get(ProjectsService);
    spyOn(projectsService, 'getProjectList').and.returnValue(
      Observable.of(stubProjectListSuccessResponse)
    );
    spyOn(projectsService, 'changeAssessors').and.returnValue(
      Observable.of(stubChangeAssessorsSuccessResponse)
    );
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  // it('should get project list', () => {
  //   fixture.whenStable().then(() => {
  //     fixture.detectChanges();
  //     expect(component.projects.length).toEqual(stubProjects.length);
  //   });
  // });
  //
  // it('should select all rows', () => {
  //   const selectAllElement = fixture.debugElement.nativeElement.querySelector('.table-cell-selectAll');
  //   selectAllElement.checked = false;
  //   selectAllElement.click();
  //   fixture.detectChanges();
  //   expect(component.projects[0].selected).toBeTruthy();
  // });
  //
  // it('should change projects assessors', () => {
  //   component.changeAssessors([stubProjects[0]['applyId'], stubProjects[1]['applyId']]);
  //   fixture.whenStable().then(() => {
  //     fixture.detectChanges();
  //     expect(component.projects.length).toEqual(stubProjects.length);
  //   });
  // });
  //
  // it('should change selected projects assessors', () => {
  //   component.projects[0].selected = true;
  //   component.projects[1].selected = false;
  //   component.changeSelectedAssessors();
  //   fixture.whenStable().then(() => {
  //     fixture.detectChanges();
  //     expect(component.projects.length).toEqual(stubProjects.length);
  //   });
  // });
});
