import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { MockComponent } from 'ng2-mock-component';
import { HttpModule, ConnectionBackend } from '@angular/http';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { Observable } from 'rxjs/Observable';

import { OperationalTableComponent } from './operational-table.component';
import { HasPermissionDirective } from 'shared/directives/has-permission.directive';
import { NeedConfirmDirective } from 'shared/directives/need-confirm.directive';

import { UserService } from 'app/shared/services/user.service';
import { ProjectsService } from 'app/shared/services/projects.service';
import { AlertService } from 'app/shared/services/alert.service';
import { AuthenticationService } from 'app/shared/services/authentication.service';
import { HttpInterceptorService } from 'app/shared/services/http-interceptor.service';

import {
  projectTypeConstant,
  projectStatusConstant
} from 'app/shared/constants/project.constant';

describe('OperationalTableComponent', () => {
  let component: OperationalTableComponent;
  let fixture: ComponentFixture<OperationalTableComponent>;
  let projectsService: ProjectsService;

  let stubChangeAssessorsSuccessResponse = { code: '0', message: '更换审批人成功' };
  let stubProjects = [
    {
      applyId: 'aaaa',
      projectName: '金融科技创新平台改进',
      ystName: '姓名',
      ystOrgName: '部门'
    },
    {
      applyId: 'bbbb',
      projectName: '金融科技创新平台改进',
      ystName: '姓名',
      ystOrgName: '部门'
    }
  ];
  let stubProjectListSuccessResponse = {
    code: '0',
    message: '查询成功',
    data: {
      pageIndex: 0,
      pageSize: 10,
      total: 2,
      data: stubProjects
    }
  };

  beforeEach(
    async(() => {
      TestBed.configureTestingModule({
        imports: [HttpModule, NgbModule.forRoot(), RouterTestingModule],
        declarations: [
          OperationalTableComponent,
          HasPermissionDirective,
          NeedConfirmDirective,
          MockComponent({
            selector: 'app-no-data'
          }),
          MockComponent({
            selector: 'app-loading'
          })
        ],
        providers: [
          UserService,
          AlertService,
          ProjectsService,
          HttpInterceptorService,
          ConnectionBackend,
          AuthenticationService
        ]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(OperationalTableComponent);
    component = fixture.componentInstance;
    projectsService = fixture.debugElement.injector.get(ProjectsService);
    spyOn(projectsService, 'getProjectList').and.returnValue(
      Observable.of(stubProjectListSuccessResponse)
    );
    spyOn(projectsService, 'changeAssessors').and.returnValue(
      Observable.of(stubChangeAssessorsSuccessResponse)
    );
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should adjust table styles', () => {
    expect(component.showApprovedDate).toBeFalsy();
    component.projectStatus = projectStatusConstant.approved;
    component.adjustTableStyles();
    fixture.detectChanges();
    expect(component.showApprovedDate).toBeTruthy();
  });
});
