import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpModule, ConnectionBackend } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import { MockComponent } from 'ng2-mock-component';

import { ItofficerProjectListComponent } from './itofficer-project-list.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ProjectPageTempleteComponent } from '../../components/project-page-templete/project-page-templete.component';

import { HttpInterceptorService } from '../../../../shared/services/http-interceptor.service';
import { AlertService } from '../../../../shared/services/alert.service';
import { AuthenticationService } from '../../../../shared/services/authentication.service';
import { ProjectsService } from '../../../../shared/services/projects.service';
import { UserService } from '../../../../shared/services/user.service';

import { HasPermissionDirective } from '../../../../shared/directives/has-permission.directive';

const mockProjectList = require('mockServer/resources/projectList');

describe('ItofficerProjectListComponent', () => {
  let component: ItofficerProjectListComponent;
  let fixture: ComponentFixture<ItofficerProjectListComponent>;
  let projectsService: ProjectsService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpModule,
        NgbModule.forRoot(),
      ],
      declarations: [
        ProjectPageTempleteComponent,
        ItofficerProjectListComponent,
        HasPermissionDirective,
        MockComponent({
          selector: 'app-no-data'
        }),
        MockComponent({
          selector: 'app-loading'
        })
      ],
      providers: [
        ConnectionBackend,
        HttpInterceptorService,
        AuthenticationService,
        ProjectsService,
        AlertService,
        UserService,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ItofficerProjectListComponent);
    component = fixture.componentInstance;

    projectsService = fixture.debugElement.injector.get(ProjectsService);
    spyOn(projectsService, 'getProjectList').and.returnValue(Observable.of(mockProjectList));

    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should get unassigned project list', () => {
    fixture.whenStable().then(() => {
      let projectsCount = mockProjectList.data.data.length;
      expect(component.tabContents[0].projects.length).toEqual(projectsCount);
    });
  });

  it('should show assign persons button when initial tab is active', () => {
    const rowOperationElement = fixture.debugElement.nativeElement.querySelector('.row-operations');
    expect(rowOperationElement.textContent).toContain('指派IT负责人和沙盒支持人员');
  });

  it('should get assigned project list', () => {
    let activeTabIndex = 1;
    expect(component.tabContents[activeTabIndex].projects.length).toEqual(0);
    component.getProjects(component.tabContents[activeTabIndex].projectAction, activeTabIndex);
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(component.tabContents[activeTabIndex].projects.length).toEqual(mockProjectList.data.data.length);
    });
  });

  it('should get project list when tab changed', () => {
    let activeTabIndex = 1;
    expect(component.tabContents[activeTabIndex].projects.length).toEqual(0);
    component.tabChange(
      { 'nextId': activeTabIndex }
    );
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(component.tabContents[activeTabIndex].projects.length).toEqual(mockProjectList.data.data.length);
    });
  });
});
