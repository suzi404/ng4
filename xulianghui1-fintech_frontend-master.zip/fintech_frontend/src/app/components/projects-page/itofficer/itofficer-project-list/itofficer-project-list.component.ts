import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { ProjectsService } from '../../../../shared/services/projects.service';
import { codeConstant } from '../../../../shared/constants/code.constant';
import { projectTypeConstant, projectStatusConstant, PROJECT_STATUSES } from '../../../../shared/constants/project.constant';
import { Project } from '../../types/Project';
import { AlertService } from '../../../../shared/services/alert.service';
import {ItofficerAssignPersonsComponent} from '../../components/modals/itofficer-assign-persons/itofficer-assign-persons.component';

@Component({
  selector: 'app-itofficer-project-list',
  templateUrl: './itofficer-project-list.component.html',
  styleUrls: ['./itofficer-project-list.component.scss'],
})
export class ItofficerProjectListComponent implements OnInit {
  loading: boolean = true;
  tabContents: Array<any> = [
    {
      'title': '未指派',
      'projectAction': PROJECT_STATUSES.project_submission.approved.initial.toString(),
      'projects': []
    },
    {
      'title': '已指派',
      'projectAction': PROJECT_STATUSES.project_submission.approved.assigned.toString(),
      'projects': []
    },
  ];

  constructor(
    private projectsService: ProjectsService,
    private alertService: AlertService,
    private modalService: NgbModal
  ) { }

  ngOnInit() {
    this.getProjects(this.tabContents[0]['projectAction'], 0);
  }

  getProjects(projectAction, tabIndex): void {
    let me = this;
    me.projectsService.getProjectList(
      projectTypeConstant.managed,
      projectStatusConstant.approved,
      projectAction
    ).subscribe(
        res => {
          if (res.data) {
            me.tabContents[tabIndex].projects = res.data.data;
          }
        },
        err => {},
        () => {
          this.loading = false;
        }
      );
  }

  tabChange($event): void {
    let me = this;
    let activeTabIndex = $event.nextId;
    me.getProjects(me.tabContents[activeTabIndex]['projectAction'], activeTabIndex);
  }

  // TODO Need to remove duplicated markProjects function in the app
  markProject(project): void {
    let me = this;
    project.mark = !project.mark;
    let mark: string = project.mark ? '1' : '0';
    me.projectsService.markProject(project.applyId, mark)
      .subscribe(
        res => {
          me.alertService.success('切换项目标记成功！');
        },
        err => {
          me.alertService.error('切换项目标记失败，请重试');
        }
      );
  }

  openAssginPersonsModal(applyId) {
    const modalRef = this.modalService.open(ItofficerAssignPersonsComponent, { size: 'lg' });
    modalRef.componentInstance.applyId = applyId;
  }

}
