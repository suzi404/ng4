import { TestBed, async } from '@angular/core/testing';
import { HttpModule } from '@angular/http';
import { FormsModule } from '@angular/forms';
import { NgStickyModule } from 'ng-sticky';
import { APP_BASE_HREF } from '@angular/common';

import { AppRoutingModule } from './app-routing.module';
import { SharedModule } from './shared/shared.module';
import { HomeModule } from './components/home/home.module';
import { ProjectsPageModule } from './components/projects-page/projects-page.module';
import { QuestionnaireModule } from './components/questionnaire/questionnaire.module';
import { ProjectApplicationModule } from './components/project-application/project-application.module';
import { ResourcesPageModule } from './components/resources-page/resources-page.module';

import { AppComponent } from './app.component';
import { NoContentComponent } from './components/no-content/no-content.component';
import { FakeLoginComponent } from './components/fake-login/fake-login.component';
import { LoginComponent } from './components/login/login.component';

import { AlertService } from './shared/services/alert.service';
import { UserService } from './shared/services/user.service';

describe('AppComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        AppComponent,
        FakeLoginComponent,
        NoContentComponent,
        LoginComponent,
      ],
      imports: [
        AppRoutingModule,
        FormsModule,
        NgStickyModule,
        HttpModule,
        SharedModule.forRoot(),
        ProjectsPageModule,
        ProjectApplicationModule,
        ResourcesPageModule,
      ],
      providers: [
        AlertService,
        UserService,
        { provide: APP_BASE_HREF, useValue: '/' },
      ]
    }).compileComponents();
  }));

  it('should create the app', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  }));

  it(`should have as title 'app'`, async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app.title).toEqual('app');
  }));

  it('should render title in a h1 tag', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('.global-header_logo').textContent).toContain('金融科技创新孵化平台');
  }));
});
