const jsonServer = require('json-server');
const questionsRes = require('./resources/questions');
const labels = require('./resources/labels');
const userInfo = require('./resources/userInfo');
const projectStatus = require('./resources/projectStatus');
const projectList = require('./resources/projectList');
const projectList_12 = require('./resources/projectList_12');
const projectDetail = require('./resources/projectDetail');
const userPermissions = require('./resources/userPermissions');
const projectMaterials = require('./resources/projectMaterials');
const videoList = require('./resources/videoList');
const answers = require('./resources/answers')

//actions
const rejectResponse = require('./resources/project/reject');
const approveResponse = require('./resources/project/approve');

const server = jsonServer.create();
const middlewares = jsonServer.defaults();
server.use(middlewares);
server.use(jsonServer.bodyParser);

/**================== user =======================**/
server.use('/admin/user/fakeLogin/:id', (req, res) => {
  res.jsonp({
    code: '0',
    message: '',
    data: {
      jwt: {
        access_token: true
      },
      userName: '测试账号'
    }
  });
});

server.use('/admin/user/ystInfo', (req, res) => {
  res.jsonp(userInfo);
});

server.use('/admin/user/permissions', (req, res) => {
  res.jsonp(userPermissions);
});

/**================== projects =======================**/

server.use('/business/projects/:id', (req, res) => {
  res.jsonp(projectDetail);
});

server.use('/business/projects?listType=1&status=12', (req, res) => {
  res.jsonp(projectList_12);
});

server.use('/business/projects', (req, res) => {
  res.jsonp(projectList);
});

server.use('/business/projects/leader/update', (req, res) => {
  if (req.method === 'POST') {
    res.jsonp({
      code: '0',
      message: '',
      data: true
    });
  }
})

server.use('/business/answers/selectbyuserid', (req, res)=>{
  res.jsonp({
    code: '0',
    message: '',
    data: answers
  })
})

server.use('/business/answers/isexist', (req, res) => {
  res.jsonp({
    code: '0',
    message: '查询成功',
    data: true
  });
});

/**================== project operations =======================**/
server.use('/business/task/prjApplyManagerReject', (req, res) => {
  if (req.method === 'POST') {
    res.jsonp(rejectResponse);
  }
});

server.use('/business/task/prjApplyManagerPass', (req, res) => {
  if (req.method === 'POST') {
    res.jsonp(approveResponse);
  }
});

/**================== persons =======================**/
server.use('/business/persons/insert', (req, res) => {
  if (req.method === 'POST') {
    res.jsonp({
      code: '0',
      message: '',
      data: true
    });
  }
});

/**================== actions =======================**/
server.use('/business/actions/:applyId/top', (req, res) => {
  res.jsonp(projectStatus);
});

server.use('/business/actions/:applyId/allmaterial', (req, res) => {
  setTimeout(() => {
    res.jsonp(projectMaterials);
  }, 3000)
});

/**================== questions =======================**/
server.use('/business/questions', (req, res) => {
  res.jsonp(questionsRes);
});

/**================== anwsers =======================**/
server.use('/business/answers', (req, res) =>{
    if (req.method === 'POST') {
      res.jsonp({
        code: '0',
        message: '问卷提交成功',
        data: true
      })
    }
})

/**================== fintechWorkflow =======================**/
server.use('/business/fintechWorkflow/start', (req, res) => {
  if (req.method === 'POST') {
    res.jsonp({
      code: '0',
      message: '',
      data: true
    });
  }
});

/**================== labels =======================**/
server.use('/business/labels', (req, res) => {
  res.jsonp(labels);
});

/**================== courses =======================**/
server.use('/business/courses', (req, res) => {
  res.jsonp(videoList);
});

server.listen(4600, () => {
  console.log('JSON server in running on http://localhost:4600');
});
