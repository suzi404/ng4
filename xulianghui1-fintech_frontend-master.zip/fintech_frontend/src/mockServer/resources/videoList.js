module.exports = {
  code: '0',
  message: '',
  data: {
    pageIndex: 0,
    pageSize: 2147483647,
    total: 9,
    data: [
      {
        curriculumId: 1,
        curriculumName: 'HTML+CSS基础课程',
        curriculumDescribe: '简介：本课程从最基本的概念开始讲起，步步深入，带领大家学习HTML、CSS样式基础知识，了解各种常用标签的意义以及基本用法，后半部分教程主要讲解CSS样式代码添加，为后面的案例课程打下基础。',
        curriculumType: 1,
        url: 'http://www.imooc.com/learn/9',
        ystId: 374775,
        ystName: '潘志辉',
        uploadTime: 1500428780000
      },
      {
        curriculumId: 2,
        curriculumName: 'HTML+CSS基础课程',
        curriculumDescribe: '简介：本课程从最基本的概念开始讲起，步步深入，带领大家学习HTML、CSS样式基础知识，了解各种常用标签的意义以及基本用法，后半部分教程主要讲解CSS样式代码添加，为后面的案例课程打下基础。',
        curriculumType: 1,
        url: 'http://www.imooc.com/learn/9',
        ystId: 374775,
        ystName: '潘志辉',
        uploadTime: 1500428780000
      },
      {
        curriculumId: 3,
        curriculumName: 'HTML+CSS基础课程',
        curriculumDescribe: '简介：本课程从最基本的概念开始讲起，步步深入，带领大家学习HTML、CSS样式基础知识，了解各种常用标签的意义以及基本用法，后半部分教程主要讲解CSS样式代码添加，为后面的案例课程打下基础。',
        curriculumType: 1,
        url: 'http://www.imooc.com/learn/9',
        ystId: 374775,
        ystName: '潘志辉',
        uploadTime: 1500428780000
      },
      {
        curriculumId: 4,
        curriculumName: 'HTML+CSS基础课程',
        curriculumDescribe: '简介：本课程从最基本的概念开始讲起，步步深入，带领大家学习HTML、CSS样式基础知识，了解各种常用标签的意义以及基本用法，后半部分教程主要讲解CSS样式代码添加，为后面的案例课程打下基础。',
        curriculumType: 1,
        url: 'http://www.imooc.com/learn/9',
        ystId: 374775,
        ystName: '潘志辉',
        uploadTime: 1500428780000
      },
      {
        curriculumId: 5,
        curriculumName: 'HTML+CSS基础课程',
        curriculumDescribe: '简介：本课程从最基本的概念开始讲起，步步深入，带领大家学习HTML、CSS样式基础知识，了解各种常用标签的意义以及基本用法，后半部分教程主要讲解CSS样式代码添加，为后面的案例课程打下基础。',
        curriculumType: 1,
        url: 'http://www.imooc.com/learn/9',
        ystId: 374775,
        ystName: '潘志辉',
        uploadTime: 1500428780000
      },
      {
        curriculumId: 6,
        curriculumName: 'HTML+CSS基础课程',
        curriculumDescribe: '简介：本课程从最基本的概念开始讲起，步步深入，带领大家学习HTML、CSS样式基础知识，了解各种常用标签的意义以及基本用法，后半部分教程主要讲解CSS样式代码添加，为后面的案例课程打下基础。',
        curriculumType: 1,
        url: 'http://www.imooc.com/learn/9',
        ystId: 374775,
        ystName: '潘志辉',
        uploadTime: 1500428780000
      },
      {
        curriculumId: 7,
        curriculumName: 'HTML+CSS基础课程',
        curriculumDescribe: '简介：本课程从最基本的概念开始讲起，步步深入，带领大家学习HTML、CSS样式基础知识，了解各种常用标签的意义以及基本用法，后半部分教程主要讲解CSS样式代码添加，为后面的案例课程打下基础。',
        curriculumType: 1,
        url: 'http://www.imooc.com/learn/9',
        ystId: 374775,
        ystName: '潘志辉',
        uploadTime: 1500428780000
      },
      {
        curriculumId: 8,
        curriculumName: 'HTML+CSS基础课程',
        curriculumDescribe: '简介：本课程从最基本的概念开始讲起，步步深入，带领大家学习HTML、CSS样式基础知识，了解各种常用标签的意义以及基本用法，后半部分教程主要讲解CSS样式代码添加，为后面的案例课程打下基础。',
        curriculumType: 1,
        url: 'http://www.imooc.com/learn/9',
        ystId: 374775,
        ystName: '潘志辉',
        uploadTime: 1500428780000
      },
      {
        curriculumId: 9,
        curriculumName: 'HTML+CSS基础课程',
        curriculumDescribe: '简介：本课程从最基本的概念开始讲起，步步深入，带领大家学习HTML、CSS样式基础知识，了解各种常用标签的意义以及基本用法，后半部分教程主要讲解CSS样式代码添加，为后面的案例课程打下基础。',
        curriculumType: 1,
        url: 'http://www.imooc.com/learn/9',
        ystId: 374775,
        ystName: '潘志辉',
        uploadTime: 1500428780000
      }
    ]
  }
}