module.exports = {
  code: '0',
  message: '',
  data: {
    userId: '098581',
    sapId: '00011198',
    userName: '顾玉华',
    status: 'A',
    type: '0',
    gender: 'M',
    email: 'guyuhua@yst.cmbchina.cn',
    mobile: '234221',
    officeTel: '0755-88888888',
    position: '微机开发岗',
    modPos: '设计岗moddd',
    useSapPos: 'Y',
    hailNo: 701341880,
    hailStatus: '0',
    rspId: '',
    rspName: '',
    orgId: 113842,
    groupId: '010004538C',
    userOrd: 999,
    orgInfo: {
      orgId: 113842,
      groupId: '010004538C',
      groupName: '渠道管理设计室',
      parentOrgId: 100151,
      isAvailable: 'Y',
      pathId: '100003/100143/113403/100151/113842',
      pathName: '总行/信息技术部/研发中心/渠道业务开发团队/渠道管理设计室',
      type: 'Z',
      isLeaf: 'Y',
      orgOrd: 10
    }
  }
};
