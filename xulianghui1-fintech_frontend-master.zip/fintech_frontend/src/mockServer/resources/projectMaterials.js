module.exports = {
  "code": "0",
  "message": "查询成功",
  "data": {
    "applyMaterialDto": {
      "name": "申请项目",
      "beginTime": 1501720564000
    },
    "worthMaterialDto": {
      "name": "价值假说",
      "beginTime": 1502262588000,
      "projectStatus": "212",
      "projectFiles": {
        "fileId": "a2b38197-5c31-493e-a3c8-49bd6333aad2",
        "recordId": "f6e3aaaf-1964-4748-8fe0-ebe887c766cc",
        "applyId": "fe54edfd-4abn-49c8-a2cd-d298884e33d4",
        "fileName": "2-TDMS需求收集统计表审批_ST渠道（解析版）.xlsx",
        "versions": "1.0.0",
        "fileSource": "立项汇报材料",
        "fileSourceId": "FILE_SETUP",
        "ystId": "000088",
        "ystName": "贺小兵",
        "uploadTime": 1502262790000,
        "fileType": null,
        "isPlace": "N",
        "taskId": null
      }
    }
  }
}
