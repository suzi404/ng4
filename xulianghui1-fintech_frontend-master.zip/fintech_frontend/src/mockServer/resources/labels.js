module.exports = {
    "code": "0",
    "message": "获取所有标签",
    "data": [
        {
            "labelId": "1",
            "labelName": "产品",
            "labelType": 1,
            "createTime": 1501135898000,
            "createUserId": "098581",
            "createUserName": "顾玉华"
        },
        {
            "labelId": "10",
            "labelName": "计算机视觉",
            "labelType": 2,
            "createTime": 1501751717000,
            "createUserId": "374605",
            "createUserName": "姚亚"
        },
        {
            "labelId": "11",
            "labelName": "自然语言处理",
            "labelType": 2,
            "createTime": 1501751732000,
            "createUserId": "374605",
            "createUserName": "姚亚"
        },
        {
            "labelId": "12",
            "labelName": "运营",
            "labelType": 1,
            "createTime": 1501751762000,
            "createUserId": "374605",
            "createUserName": "姚亚"
        },
        {
            "labelId": "2",
            "labelName": "风险",
            "labelType": 1,
            "createTime": 1501751542000,
            "createUserId": "374605",
            "createUserName": "姚亚"
        },
        {
            "labelId": "3",
            "labelName": "客户服务",
            "labelType": 1,
            "createTime": 1501751568000,
            "createUserId": "374605",
            "createUserName": "姚亚"
        },
        {
            "labelId": "4",
            "labelName": "客户经营",
            "labelType": 1,
            "createTime": 1501751583000,
            "createUserId": "374605",
            "createUserName": "姚亚"
        },
        {
            "labelId": "5",
            "labelName": "云平台",
            "labelType": 2,
            "createTime": 1501751600000,
            "createUserId": "374605",
            "createUserName": "姚亚"
        },
        {
            "labelId": "6",
            "labelName": "大数据",
            "labelType": 2,
            "createTime": 1501751617000,
            "createUserId": "374605",
            "createUserName": "姚亚"
        },
        {
            "labelId": "7",
            "labelName": "机器学习",
            "labelType": 2,
            "createTime": 1501751668000,
            "createUserId": "374605",
            "createUserName": "姚亚"
        },
        {
            "labelId": "8",
            "labelName": "知识图谱",
            "labelType": 2,
            "createTime": 1501751685000,
            "createUserId": "374605",
            "createUserName": "姚亚"
        },
        {
            "labelId": "9",
            "labelName": "推荐系统",
            "labelType": 2,
            "createTime": 1501751701000,
            "createUserId": "374605",
            "createUserName": "姚亚"
        }
    ]
}
