module.exports = {
  "code": "0",
  "message": "查询成功",
  "data": {
  "recordId": "5b246e45-f497-4527-b652-00de5f4d230d",
    "applyId": "6bf3e59f-cd29-4b64-8ae3-54fc728a62fc",
    "actionName": "内部审核中\r\n(更换审核人)",
    "projectStatus": 12,
    "projectAction": 129,
    "status": 0,
    "isOffline": "N",
    "userType": 1,
    "createTime": 1502098175000,
    "planBegTime": 1500652800000,
    "planEndTime": 1502294400000,
    "realBegTime": 1501493363000,
    "realEndTime": 1502098168000,
    "actionData": '{"comment":"暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停暂停"}',
    "actionAddress": "申请",
    "userId": null,
    "userName": null
}
}
