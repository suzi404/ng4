module.exports = {
  code: '0',
  message: '查询成功',
  data: {
    pageIndex: 0,
    pageSize: 10,
    total: 3,
    data: [
      {
        applyId: '75245eb1-fad9-4ab2-bca1-95eefb3a64fa',
        projectName: '金融科技创新平台改进 121',
        projectIntro:
          '为加快实施创新驱动发展战略，依托金融科技（Fintech），不断打造富有市场初创性及领先力的创新项目，持续提升我行经营效益及竞争实力，董事会特授权设立金融科技创新项目基金。基金来源从上一年度税前利润提取，每年实施限额管理，并专向应用于金融科技创新项目。',
        ystId: '098581',
        ystName: '顾玉华',
        ystOrgId: '000000',
        ystOrgName: '电话银行二室',
        ystJob: '应用开发岗',
        applyTime: 1500433168000,
        projectStatus: 0,
        projectId: '1111111111',
        demandId: null,
        costCenterCode: null,
        costCenterName: null,
        projectMember: '周柯柯；郑乾通',
        mark: null,
        projectAction: 121
      },
      {
        applyId: '75245eb1-fad9-4ab2-bca1-95eefb3a64fb',
        projectName: '金融科技创新平台改进 122',
        projectIntro:
          '为加快实施创新驱动发展战略，依托金融科技（Fintech），不断打造富有市场初创性及领先力的创新项目，持续提升我行经营效益及竞争实力，董事会特授权设立金融科技创新项目基金。基金来源从上一年度税前利润提取，每年实施限额管理，并专向应用于金融科技创新项目。',
        ystId: '098581',
        ystName: '顾玉华',
        ystOrgId: '000000',
        ystOrgName: '电话银行二室',
        ystJob: '应用开发岗',
        applyTime: 1500433168000,
        projectStatus: 0,
        projectId: '1111111111',
        demandId: null,
        costCenterCode: null,
        costCenterName: null,
        projectMember: '周柯柯；郑乾通',
        mark: null,
        projectAction: 122
      },
      {
        applyId: '79c38d73-e90c-4c4b-9e2d-6c1bf26b226c',
        projectName: '金融科技创新平台改进 129',
        projectIntro:
          '为加快实施创新驱动发展战略，依托金融科技（Fintech），不断打造富有市场初创性及领先力的创新项目，持续提升我行经营效益及竞争实力，董事会特授权设立金融科技创新项目基金。基金来源从上一年度税前利润提取，每年实施限额管理，并专向应用于金融科技创新项目。',
        ystId: '098581',
        ystName: '顾玉华',
        ystOrgId: '000000',
        ystOrgName: '电话银行二室',
        ystJob: '应用开发岗',
        applyTime: 1500433168000,
        projectStatus: 0,
        projectId: '1111111111',
        demandId: null,
        costCenterCode: null,
        costCenterName: null,
        projectMember: '周柯柯；郑乾通',
        mark: null,
        projectAction: 129
      }
    ]
  }
};
