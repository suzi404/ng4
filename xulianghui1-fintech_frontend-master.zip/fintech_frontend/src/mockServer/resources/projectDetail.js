module.exports = {
  code: '0',
  message: '查询成功',
  data: {
    projectInfo: {
      applyId: '83a191df-8375-436c-948f-46ff3510db26',
      projectName: '自助交党费',
      projectIntro: '当大家都开心地交党费，祝党的事业蒸蒸日上',
      ystId: '098581',
      ystName: '顾玉华',
      ystOrgId: '01110',
      ystOrgName: 'zonghang',
      ystJob: 'manong',
      applyTime: 1501068047000,
      "projectStatus": 12,
      "projectAction": 121,
      projectId: null,
      demandId: null,
      costCenterCode: null,
      costCenterName: null,
      projectMember: null,
      mark: null,
      leaderYstName: '顾玉华',
    },
    projectLabels: [
      {
        id: 'c89412b5-5ac4-4470-b23b-9f107cefbe2b',
        applyId: '83a191df-8375-436c-948f-46ff3510db26',
        labelId: '111',
        labelName: '运营',
        labelType: 1
      }
    ],
    projectPersons: [
      {
        id: '6e052aac-0f68-47e1-9a0c-655b52565519',
        applyId: '83a191df-8375-436c-948f-46ff3510db26',
        ystId: '098581',
        ystName: '顾玉华',
        ystDepName: '渠道管理设计室',
        role: '',
        responsibility: '',
        telephone: '0755-88888888',
        mobilephone: '234221',
        email: 'guyuhua@yst.cmbchina.cn',
        iscmb: 'Y',
        isedit: 'N'
      }
    ],
    productAnalysisList: [
      {
        productId: '349190e3-f064-4242-a10d-56292b3cc4bf',
        applyId: '83a191df-8375-436c-948f-46ff3510db26',
        serialNumber: 1112222,
        productName: '小目标产品',
        productOrientation: 'fangbianqunzhong',
        targetUser: '老年人',
        uniqueValue: 'shengqian',
        productDisadvantage: '质量不好',
        easyUsing: '很趁手',
        dataCase: null
      }
    ],
    projectResearch: {
      applyId: '83a191df-8375-436c-948f-46ff3510db26',
      marketEnv: '红海',
      marketSize: '10个小目标',
      industryStatus: '很不错',
      userGroup: '老年用户',
      userBehaviour: '用户行为不可知',
      userPainPoint: '省钱',
      uniqueValue: '还是省钱'
    }
  }
};
