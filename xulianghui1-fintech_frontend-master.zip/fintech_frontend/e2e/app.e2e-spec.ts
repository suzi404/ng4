import { FintechDesktopPage } from './app.po';

describe('fintech-desktop App', () => {
  let page: FintechDesktopPage;

  beforeEach(() => {
    page = new FintechDesktopPage();
  });

  it('should display banner title', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('FINTECH');
  });
});
