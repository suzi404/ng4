#!/bin/bash

# 此脚本用来将外网代码库同步到内网代码库，每5分钟同步一次。（通过戚涛的已申请了权限的电脑）
# 注意1：该脚本需要运行在戚涛的电脑上。
# 注意2：修改此脚本要慎重，因为更新后需要手动重启此脚本才能生效，所以需要戚涛帮忙。

# 最新commit的编号
lastCommit=`git rev-parse HEAD`
while [ 1 ]
do
    echo 'while start...';
		git pull;

		# 获取pull命令后，最新commit编号
		currCommit=`git rev-parse HEAD`;

		# 比较两个编号，如果不同，则表示外网的代码有更新
		if [ $lastCommit != $currCommit ]
		then
			lastCommit=`git rev-parse HEAD`;
			echo 'start push mirror...';

			# 将代码以镜像的形式push到内网地址，让内外网保持同步
			# 其中地址以 http://[username]:[password]@url的形式，避免频繁输入。
			# 如以后需要，账号密码可替换。
			git push --mirror http://ST80737:lianghui890...@code.itc.cmbchina.cn/CmbOA/lc33-12_fintech-pc.git;
      git push --tags http://ST80737:lianghui890...@code.itc.cmbchina.cn/CmbOA/lc33-12_fintech-pc.git;
		fi

		# 延迟 5分钟
    sleep 300
done
