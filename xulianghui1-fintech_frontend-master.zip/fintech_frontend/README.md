# Fintech Desktop


## Introduction

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.2.1.

## Requirements

- Node (8.1.4+)
- Angular CLI (1.2.1)

## Install

Run `npm install` to get local development dependencies.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Start web Server and Mock Server
1. run 'npm start'.
2. open up another terminal,run 'npm run mock'.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|module`.

More options:

`ng generate service shared/services/project.service`

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `-prod` flag for a production build.

More options:

`ng build --prod --aot --env=staging` for staging

`ng build --prod --aot --env=prod` for production


## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

### Test Coverage

Run `ng test --code-coverage` and then check `coverage/index.html`.

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).
Before running the tests make sure you are serving the app via `ng serve`.

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).

## Coding Standards
1. Coding Styles
We use EditorConfig to help define and maintain consistent coding styles between different editors and IDEs.
The styles are defined in `.editorconfig` file.
To use EditorConfig, you may or may not need to install a plugin depend on your IDE.

Further help on Editor Config, check out the [EditorConfig](http://editorconfig.org/).

2. Static Check
Run `ng lint`, the check will based on the configuration from `tslint.json` file.

## Syncing Code Repo
run 'sh sync_code_repo.sh' to sync code, only on QiTao's computer
